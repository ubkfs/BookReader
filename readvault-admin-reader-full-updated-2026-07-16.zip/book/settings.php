<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
book_require_login();

$db = book_db();
$uid = book_user_id();
$user = book_current_user() ?? [];

$locales = [
    'en' => 'English', 'es' => 'Spanish', 'fr' => 'French', 'de' => 'German',
    'it' => 'Italian', 'pt' => 'Portuguese', 'ar' => 'Arabic', 'hi' => 'Hindi',
    'bn' => 'Bengali', 'zh' => 'Chinese', 'ja' => 'Japanese', 'ko' => 'Korean',
    'tr' => 'Turkish', 'ru' => 'Russian',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    book_verify_csrf();

    if (isset($_POST['save_profile'])) {
        $name = trim((string)($_POST['name'] ?? ''));
        $country = strtoupper(trim((string)($_POST['country_code'] ?? '')));
        $locale = strtolower(trim((string)($_POST['locale'] ?? 'en')));
        $timezone = trim((string)($_POST['timezone'] ?? 'UTC'));

        if ($name === '' || mb_strlen($name) > 150) {
            book_flash('error', 'Enter a valid display name.');
        } elseif ($country !== '' && !preg_match('/^[A-Z]{2}$/', $country)) {
            book_flash('error', 'Country code must contain two letters, such as US, IN, or GB.');
        } elseif (!array_key_exists($locale, $locales)) {
            book_flash('error', 'Choose a supported interface language.');
        } elseif (!in_array($timezone, DateTimeZone::listIdentifiers(), true)) {
            book_flash('error', 'Choose a valid IANA timezone.');
        } else {
            $db->prepare('UPDATE book_users SET name=?,country_code=?,locale=?,timezone=? WHERE id=?')
                ->execute([$name, $country !== '' ? $country : null, $locale, $timezone, $uid]);
            book_log('profile.updated', 'user', $uid, ['country_code' => $country ?: null, 'locale' => $locale]);
            book_flash('ok', 'Profile and regional settings updated.');
        }
    }

    if (isset($_POST['save_api_key'])) {
        $provider = strtolower(trim((string)($_POST['provider'] ?? '')));
        $key = trim((string)($_POST['api_key'] ?? ''));
        if (!in_array($provider, ['gemini', 'openai', 'deepseek', 'openrouter'], true) || $key === '') {
            book_flash('error', 'Choose a supported provider and enter an API key.');
        } else {
            $stmt = $db->prepare('INSERT INTO book_api_keys (user_id,provider,encrypted_key,is_active) VALUES (?,?,?,1) ON DUPLICATE KEY UPDATE encrypted_key=VALUES(encrypted_key),is_active=1,updated_at=NOW()');
            $stmt->execute([$uid, $provider, book_encrypt($key)]);
            book_log('api_key.saved', 'book_api_key', null, ['provider' => $provider]);
            book_flash('ok', 'API key saved with application-level encryption.');
        }
    }

    if (isset($_POST['save_translation'])) {
        $endpoint = trim((string)($_POST['libre_endpoint'] ?? ''));
        $apiKey = trim((string)($_POST['libre_api_key'] ?? ''));
        $validEndpoint = $endpoint === '' || (filter_var($endpoint, FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($endpoint, PHP_URL_SCHEME)), ['http', 'https'], true));

        if (!$validEndpoint) {
            book_flash('error', 'Enter a valid HTTP or HTTPS LibreTranslate endpoint.');
        } else {
            $stmt = $db->prepare('INSERT INTO book_settings (user_id,setting_key,setting_value,scope) VALUES (?,?,?,"user") ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=NOW()');
            $stmt->execute([$uid, 'libretranslate_endpoint', $endpoint]);
            if ($apiKey !== '') {
                $stmt->execute([$uid, 'libretranslate_api_key', 'enc:' . book_encrypt($apiKey)]);
            }
            book_log('translation.settings.updated', 'user', $uid, ['custom_endpoint' => $endpoint !== '']);
            book_flash('ok', 'Translation settings saved. The API key is encrypted.');
        }
    }

    header('Location: ' . book_url('settings.php'));
    exit;
}

$keyStmt = $db->prepare('SELECT provider,is_active,updated_at FROM book_api_keys WHERE user_id=? ORDER BY provider');
$keyStmt->execute([$uid]);
$keys = $keyStmt->fetchAll(PDO::FETCH_ASSOC);

$settingsStmt = $db->prepare('SELECT setting_key,setting_value FROM book_settings WHERE user_id=? AND setting_key IN ("libretranslate_endpoint","libretranslate_api_key")');
$settingsStmt->execute([$uid]);
$translationSettings = [];
foreach ($settingsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $translationSettings[$row['setting_key']] = $row['setting_value'];
}
$endpoint = (string)($translationSettings['libretranslate_endpoint'] ?? 'https://libretranslate.com/translate');
$hasTranslationKey = !empty($translationSettings['libretranslate_api_key']);
$timezones = DateTimeZone::listIdentifiers();

book_render_header('Settings', 'book-settings');
?>
<main class="book-app" id="main-content">
  <div class="book-shell">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <section class="book-content">
      <div class="book-topbar">
        <div class="book-title"><h1>Settings</h1><p>Manage profile, regional pricing, language, timezone, and optional external services.</p></div>
      </div>
      <?php if ($message = book_flash('ok')): ?><div class="book-alert ok" style="margin-bottom:18px"><?= book_e($message) ?></div><?php endif; ?>
      <?php if ($message = book_flash('error')): ?><div class="book-alert danger" style="margin-bottom:18px"><?= book_e($message) ?></div><?php endif; ?>

      <div class="book-grid">
        <form method="post" class="book-card book-span-12 book-form">
          <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
          <h3>Profile and region</h3>
          <p class="book-muted">Your country is used to choose an administrator-configured local plan price where available.</p>
          <div class="book-mini-grid">
            <div><label class="book-label" for="profile-name">Display name</label><input id="profile-name" class="book-input" name="name" maxlength="150" required value="<?= book_e((string)($user['name'] ?? '')) ?>"></div>
            <div><label class="book-label" for="country-code">Country code</label><input id="country-code" class="book-input" name="country_code" maxlength="2" pattern="[A-Za-z]{2}" placeholder="US" value="<?= book_e((string)($user['country_code'] ?? '')) ?>"></div>
            <div><label class="book-label" for="locale">Interface language</label><select id="locale" class="book-select" name="locale"><?php foreach ($locales as $code => $label): ?><option value="<?= book_e($code) ?>" <?= ($user['locale'] ?? 'en') === $code ? 'selected' : '' ?>><?= book_e($label) ?></option><?php endforeach; ?></select></div>
            <div><label class="book-label" for="timezone">Timezone</label><select id="timezone" class="book-select" name="timezone"><?php foreach ($timezones as $zone): ?><option value="<?= book_e($zone) ?>" <?= ($user['timezone'] ?? 'UTC') === $zone ? 'selected' : '' ?>><?= book_e($zone) ?></option><?php endforeach; ?></select></div>
          </div>
          <button class="book-btn" name="save_profile" value="1">Save profile</button>
        </form>

        <div class="book-card book-span-6">
          <h3>User-owned AI API key</h3>
          <p class="book-muted">AI integrations are optional. Keys are encrypted before storage and are never displayed again.</p>
          <form method="post" class="book-form">
            <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
            <label class="book-label" for="provider">Provider</label>
            <select id="provider" class="book-select" name="provider"><option value="gemini">Gemini</option><option value="openai">OpenAI</option><option value="deepseek">DeepSeek</option><option value="openrouter">OpenRouter</option></select>
            <label class="book-label" for="api-key">API key</label>
            <input id="api-key" class="book-input" type="password" name="api_key" autocomplete="new-password" placeholder="Paste API key" required>
            <button class="book-btn" name="save_api_key" value="1">Save key</button>
          </form>
          <h4>Saved providers</h4>
          <?php foreach ($keys as $key): ?><span class="book-chip <?= $key['is_active'] ? 'ok' : '' ?>"><?= book_e((string)$key['provider']) ?> saved</span><?php endforeach; ?>
          <?php if (!$keys): ?><p class="book-muted">No keys saved.</p><?php endif; ?>
        </div>

        <div class="book-card book-span-6">
          <h3>Translation API</h3>
          <p class="book-muted">The reader supports English, Spanish, French, German, Italian, Portuguese, Arabic, Hindi, Bengali, Chinese, Japanese, Korean, Turkish, and Russian. Configure your own LibreTranslate service for predictable availability.</p>
          <form method="post" class="book-form">
            <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
            <label class="book-label" for="libre-endpoint">LibreTranslate endpoint</label>
            <input id="libre-endpoint" class="book-input" name="libre_endpoint" value="<?= book_e($endpoint) ?>" placeholder="https://your-libretranslate.example/translate">
            <label class="book-label" for="libre-key">LibreTranslate API key, optional</label>
            <input id="libre-key" class="book-input" type="password" name="libre_api_key" autocomplete="new-password" placeholder="<?= $hasTranslationKey ? 'Encrypted key already saved; enter a new value to replace it' : 'Optional API key' ?>">
            <button class="book-btn" name="save_translation" value="1">Save translation settings</button>
          </form>
        </div>
      </div>
    </section>
  </div>
</main>
<?php book_render_footer(); ?>
