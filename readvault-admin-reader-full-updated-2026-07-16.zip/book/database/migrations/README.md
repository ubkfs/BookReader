# Migrations

`001_baseline.sql` is the complete idempotent baseline for a new independent installation. `database/schema.sql` mirrors the same baseline and is used by the web installer.

For an existing installation, back up the database and execute unapplied numbered migrations in order. ReadVault 2.3.0 adds `002_admin_operations.sql`, which installs the email-template uniqueness rule, operational indexes, default transactional templates, and the initial permission matrix.

Each deployment should insert the applied filename into `book_schema_migrations`. Do not edit a migration after it has been applied to production.
