-- ReadVault 2.3.0: operational administration, templates and lookup indexes.
-- Run once on an existing ReadVault database after backing it up.
SET NAMES utf8mb4;
SET time_zone = '+00:00';

SET @schema_name = DATABASE();


SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@schema_name AND table_name='book_users' AND column_name='role_id'),
  'SELECT 1',
  'ALTER TABLE book_users ADD COLUMN role_id BIGINT UNSIGNED NULL AFTER role'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=@schema_name AND table_name='book_users' AND index_name='idx_users_permission_role'),
  'SELECT 1',
  'ALTER TABLE book_users ADD INDEX idx_users_permission_role (role_id)'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=@schema_name AND table_name='book_email_templates' AND index_name='uq_email_template_locale'),
  'SELECT 1',
  'ALTER TABLE book_email_templates ADD UNIQUE KEY uq_email_template_locale (template_key,locale)'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=@schema_name AND table_name='book_support_ticket_messages' AND index_name='idx_ticket_messages_thread'),
  'SELECT 1',
  'ALTER TABLE book_support_ticket_messages ADD INDEX idx_ticket_messages_thread (ticket_id,created_at)'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=@schema_name AND table_name='book_backups' AND index_name='idx_backups_status_date'),
  'SELECT 1',
  'ALTER TABLE book_backups ADD INDEX idx_backups_status_date (status,created_at)'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

SET @ddl = IF(
  EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=@schema_name AND table_name='book_family_profiles' AND index_name='idx_family_linked_user'),
  'SELECT 1',
  'ALTER TABLE book_family_profiles ADD INDEX idx_family_linked_user (linked_user_id)'
);
PREPARE rv_stmt FROM @ddl; EXECUTE rv_stmt; DEALLOCATE PREPARE rv_stmt;

INSERT INTO book_email_templates(template_key,locale,subject,html_body,text_body,variables_json,is_active) VALUES
('verify_email','en','Verify your ReadVault email','<h1>Verify your email</h1><p>Hello {{name}},</p><p>Activate your ReadVault account using the secure link below.</p><p><a href="{{verification_url}}">Verify email address</a></p><p>This link expires at {{expires_at}}.</p>','Hello {{name}}, verify your email: {{verification_url}}','["name","verification_url","expires_at"]',1),
('password_reset','en','Reset your ReadVault password','<h1>Reset your password</h1><p>Hello {{name}},</p><p>A password reset was requested for your account.</p><p><a href="{{reset_url}}">Reset password</a></p><p>The link expires at {{expires_at}}. Ignore this email if you did not request it.</p>','Hello {{name}}, reset your password: {{reset_url}}','["name","reset_url","expires_at"]',1),
('subscription_expiry','en','Your ReadVault subscription is ending soon','<p>Hello {{name}},</p><p>Your {{plan_name}} subscription ends on {{ends_at}}.</p><p><a href="{{plans_url}}">Review plans</a></p>','Hello {{name}}, your {{plan_name}} subscription ends on {{ends_at}}. Renew at {{plans_url}}','["name","plan_name","ends_at","plans_url"]',1),
('support_reply','en','Update on ticket {{ticket_number}}','<p>Hello {{name}},</p><p>ReadVault support replied to <strong>{{subject}}</strong>.</p><blockquote>{{message}}</blockquote><p><a href="{{ticket_url}}">Open your ticket</a></p>','Support replied to {{ticket_number}}: {{message}} {{ticket_url}}','["name","ticket_number","subject","message","ticket_url"]',1),
('welcome','en','Welcome to ReadVault','<h1>Welcome, {{name}}</h1><p>Your ReadVault account is ready. Upload a book or explore the catalog.</p><p><a href="{{dashboard_url}}">Open ReadVault</a></p>','Welcome {{name}}. Open ReadVault: {{dashboard_url}}','["name","dashboard_url"]',1)
ON DUPLICATE KEY UPDATE subject=VALUES(subject),html_body=VALUES(html_body),text_body=VALUES(text_body),variables_json=VALUES(variables_json),is_active=VALUES(is_active);

INSERT INTO book_permissions(code,module,description)
SELECT CONCAT(m.module_code,'.view'),m.module_code,CONCAT('View ',m.module_name)
FROM (
  SELECT 'users' module_code,'users' module_name UNION ALL SELECT 'books','books' UNION ALL SELECT 'categories','categories' UNION ALL
  SELECT 'publishers','publishers' UNION ALL SELECT 'authors','authors' UNION ALL SELECT 'genres','genres' UNION ALL SELECT 'collections','collections' UNION ALL
  SELECT 'payments','payments' UNION ALL SELECT 'subscriptions','subscriptions' UNION ALL SELECT 'coupons','coupons' UNION ALL SELECT 'trials','trials' UNION ALL
  SELECT 'reviews','reviews' UNION ALL SELECT 'reports','reports' UNION ALL SELECT 'analytics','analytics' UNION ALL SELECT 'seo','SEO records' UNION ALL
  SELECT 'blogs','blog posts' UNION ALL SELECT 'advertisements','advertisements' UNION ALL SELECT 'support','support tickets' UNION ALL
  SELECT 'notifications','notifications' UNION ALL SELECT 'downloads','downloads' UNION ALL SELECT 'invoices','invoices' UNION ALL SELECT 'taxes','tax rates' UNION ALL
  SELECT 'api','API clients' UNION ALL SELECT 'translation','translations' UNION ALL SELECT 'email-templates','email templates' UNION ALL SELECT 'push','push subscriptions' UNION ALL
  SELECT 'roles','roles and permissions' UNION ALL SELECT 'activity','activity logs' UNION ALL SELECT 'storage','storage' UNION ALL SELECT 'backup','backups' UNION ALL
  SELECT 'health','system health' UNION ALL SELECT 'family','family accounts' UNION ALL SELECT 'challenges','challenges' UNION ALL SELECT 'referrals','referrals' UNION ALL SELECT 'gifts','gift subscriptions'
) m
ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description);

INSERT INTO book_permissions(code,module,description)
SELECT CONCAT(m.module_code,'.manage'),m.module_code,CONCAT('Create, edit and delete ',m.module_name)
FROM (
  SELECT 'users' module_code,'users' module_name UNION ALL SELECT 'books','books' UNION ALL SELECT 'categories','categories' UNION ALL
  SELECT 'publishers','publishers' UNION ALL SELECT 'authors','authors' UNION ALL SELECT 'genres','genres' UNION ALL SELECT 'collections','collections' UNION ALL
  SELECT 'payments','payments' UNION ALL SELECT 'subscriptions','subscriptions' UNION ALL SELECT 'coupons','coupons' UNION ALL SELECT 'trials','trials' UNION ALL
  SELECT 'reviews','reviews' UNION ALL SELECT 'seo','SEO records' UNION ALL SELECT 'blogs','blog posts' UNION ALL SELECT 'advertisements','advertisements' UNION ALL
  SELECT 'support','support tickets' UNION ALL SELECT 'notifications','notifications' UNION ALL SELECT 'downloads','downloads' UNION ALL SELECT 'invoices','invoices' UNION ALL
  SELECT 'taxes','tax rates' UNION ALL SELECT 'api','API clients' UNION ALL SELECT 'translation','translations' UNION ALL SELECT 'email-templates','email templates' UNION ALL
  SELECT 'push','push subscriptions' UNION ALL SELECT 'roles','roles and permissions' UNION ALL SELECT 'storage','storage' UNION ALL SELECT 'backup','backups' UNION ALL
  SELECT 'family','family accounts' UNION ALL SELECT 'challenges','challenges' UNION ALL SELECT 'referrals','referrals' UNION ALL SELECT 'gifts','gift subscriptions'
) m
ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description);


-- Complete module permission catalogue for role-based access control.
INSERT INTO book_permissions(code,module,description) VALUES
('users.view','users','View users'),
('users.manage','users','Create and edit users'),
('users.delete','users','Delete users'),
('books.view','books','View books'),
('books.manage','books','Create and edit books'),
('books.delete','books','Delete books'),
('categories.view','categories','View categories'),
('categories.manage','categories','Create and edit categories'),
('categories.delete','categories','Delete categories'),
('publishers.view','publishers','View publishers'),
('publishers.manage','publishers','Create and edit publishers'),
('publishers.delete','publishers','Delete publishers'),
('authors.view','authors','View authors'),
('authors.manage','authors','Create and edit authors'),
('authors.delete','authors','Delete authors'),
('genres.view','genres','View genres'),
('genres.manage','genres','Create and edit genres'),
('genres.delete','genres','Delete genres'),
('collections.view','collections','View collections'),
('collections.manage','collections','Create and edit collections'),
('collections.delete','collections','Delete collections'),
('payments.view','payments','View payments'),
('payments.manage','payments','Create and edit payments'),
('payments.delete','payments','Delete payments'),
('subscriptions.view','subscriptions','View subscriptions'),
('subscriptions.manage','subscriptions','Create and edit subscriptions'),
('subscriptions.delete','subscriptions','Delete subscriptions'),
('coupons.view','coupons','View coupons'),
('coupons.manage','coupons','Create and edit coupons'),
('coupons.delete','coupons','Delete coupons'),
('trials.view','trials','View trials'),
('trials.manage','trials','Create and edit trials'),
('trials.delete','trials','Delete trials'),
('reviews.view','reviews','View reviews'),
('reviews.manage','reviews','Create and edit reviews'),
('reviews.delete','reviews','Delete reviews'),
('reports.view','reports','View reports'),
('reports.manage','reports','Create and edit reports'),
('reports.delete','reports','Delete reports'),
('analytics.view','analytics','View analytics'),
('analytics.manage','analytics','Create and edit analytics'),
('analytics.delete','analytics','Delete analytics'),
('seo.view','seo','View seo'),
('seo.manage','seo','Create and edit seo'),
('seo.delete','seo','Delete seo'),
('blogs.view','blogs','View blogs'),
('blogs.manage','blogs','Create and edit blogs'),
('blogs.delete','blogs','Delete blogs'),
('advertisements.view','advertisements','View advertisements'),
('advertisements.manage','advertisements','Create and edit advertisements'),
('advertisements.delete','advertisements','Delete advertisements'),
('support.view','support','View support'),
('support.manage','support','Create and edit support'),
('support.delete','support','Delete support'),
('notifications.view','notifications','View notifications'),
('notifications.manage','notifications','Create and edit notifications'),
('notifications.delete','notifications','Delete notifications'),
('reading-statistics.view','reading-statistics','View reading statistics'),
('reading-statistics.manage','reading-statistics','Create and edit reading statistics'),
('reading-statistics.delete','reading-statistics','Delete reading statistics'),
('downloads.view','downloads','View downloads'),
('downloads.manage','downloads','Create and edit downloads'),
('downloads.delete','downloads','Delete downloads'),
('invoices.view','invoices','View invoices'),
('invoices.manage','invoices','Create and edit invoices'),
('invoices.delete','invoices','Delete invoices'),
('taxes.view','taxes','View taxes'),
('taxes.manage','taxes','Create and edit taxes'),
('taxes.delete','taxes','Delete taxes'),
('api.view','api','View api'),
('api.manage','api','Create and edit api'),
('api.delete','api','Delete api'),
('translation.view','translation','View translation'),
('translation.manage','translation','Create and edit translation'),
('translation.delete','translation','Delete translation'),
('email-templates.view','email-templates','View email templates'),
('email-templates.manage','email-templates','Create and edit email templates'),
('email-templates.delete','email-templates','Delete email templates'),
('push.view','push','View push'),
('push.manage','push','Create and edit push'),
('push.delete','push','Delete push'),
('roles.view','roles','View roles'),
('roles.manage','roles','Create and edit roles'),
('roles.delete','roles','Delete roles'),
('activity.view','activity','View activity'),
('activity.manage','activity','Create and edit activity'),
('activity.delete','activity','Delete activity'),
('storage.view','storage','View storage'),
('storage.manage','storage','Create and edit storage'),
('storage.delete','storage','Delete storage'),
('backup.view','backup','View backup'),
('backup.manage','backup','Create and edit backup'),
('backup.delete','backup','Delete backup'),
('health.view','health','View health'),
('health.manage','health','Create and edit health'),
('health.delete','health','Delete health'),
('family.view','family','View family'),
('family.manage','family','Create and edit family'),
('family.delete','family','Delete family'),
('challenges.view','challenges','View challenges'),
('challenges.manage','challenges','Create and edit challenges'),
('challenges.delete','challenges','Delete challenges'),
('referrals.view','referrals','View referrals'),
('referrals.manage','referrals','Create and edit referrals'),
('referrals.delete','referrals','Delete referrals'),
('gifts.view','gifts','View gifts'),
('gifts.manage','gifts','Create and edit gifts'),
('gifts.delete','gifts','Delete gifts'),
('settings.view','settings','View settings'),
('settings.manage','settings','Create and edit settings'),
('settings.delete','settings','Delete settings'),
('feature-flags.view','feature-flags','View feature flags'),
('feature-flags.manage','feature-flags','Create and edit feature flags'),
('feature-flags.delete','feature-flags','Delete feature flags')
ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description);

INSERT IGNORE INTO book_role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM book_roles r CROSS JOIN book_permissions p WHERE r.code IN ('admin','super_admin');

INSERT IGNORE INTO book_role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM book_roles r JOIN book_permissions p ON p.code IN ('support.view','support.manage','users.view') WHERE r.code='support';

INSERT INTO book_schema_migrations(migration) VALUES('002_admin_operations.sql')
ON DUPLICATE KEY UPDATE applied_at=applied_at;
