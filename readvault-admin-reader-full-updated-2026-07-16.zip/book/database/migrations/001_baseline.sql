-- ReadVault Independent SaaS Database Schema
-- PHP 8.3+ / MySQL 8+
-- All application tables are namespaced with the book_ prefix.
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS book_schema_migrations (
  migration VARCHAR(190) PRIMARY KEY,
  applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('reader','author','publisher','support','admin','super_admin') NOT NULL DEFAULT 'reader',
  role_id BIGINT UNSIGNED NULL,
  status ENUM('active','suspended','pending','deleted') NOT NULL DEFAULT 'active',
  email_verified_at DATETIME NULL,
  locale VARCHAR(15) NOT NULL DEFAULT 'en',
  timezone VARCHAR(80) NOT NULL DEFAULT 'UTC',
  country_code CHAR(2) NULL,
  avatar_path VARCHAR(255) NULL,
  last_login_at DATETIME NULL,
  last_login_ip VARCHAR(45) NULL,
  trial_used_at DATETIME NULL,
  referral_code VARCHAR(32) NULL UNIQUE,
  referred_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  INDEX idx_users_status_role (status,role),
  INDEX idx_users_permission_role (role_id),
  INDEX idx_users_country (country_code),
  CONSTRAINT fk_users_referrer FOREIGN KEY (referred_by) REFERENCES book_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS book_email_verification_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_email_verify_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_email_verify_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_password_reset_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_password_reset_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_password_reset_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_remember_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  selector CHAR(16) NOT NULL UNIQUE,
  validator_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_remember_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_remember_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_user_devices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  fingerprint CHAR(64) NOT NULL,
  device_name VARCHAR(150) NULL,
  device_type ENUM('desktop','mobile','tablet','pwa','other') DEFAULT 'other',
  ip_address VARCHAR(45) NULL,
  user_agent TEXT NULL,
  push_enabled TINYINT(1) NOT NULL DEFAULT 0,
  last_seen_at DATETIME NULL,
  revoked_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_user_devices_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_user_device (user_id,fingerprint),
  INDEX idx_devices_active (user_id,revoked_at,last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_login_history (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  email VARCHAR(190) NOT NULL,
  success TINYINT(1) NOT NULL,
  failure_reason VARCHAR(100) NULL,
  ip_address VARCHAR(45) NULL,
  user_agent TEXT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_login_history_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_login_history_user_date (user_id,created_at),
  INDEX idx_login_history_ip_date (ip_address,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_roles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NULL,
  is_system TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_permissions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(120) NOT NULL UNIQUE,
  module VARCHAR(80) NOT NULL,
  description VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_role_permissions (
  role_id BIGINT UNSIGNED NOT NULL,
  permission_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id,permission_id),
  CONSTRAINT fk_role_permissions_role FOREIGN KEY (role_id) REFERENCES book_roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_role_permissions_permission FOREIGN KEY (permission_id) REFERENCES book_permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_subscription_plans (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  description TEXT NULL,
  duration_days INT UNSIGNED NULL,
  trial_days INT UNSIGNED NOT NULL DEFAULT 0,
  book_limit INT UNSIGNED NOT NULL DEFAULT 10,
  offline_limit INT UNSIGNED NOT NULL DEFAULT 0,
  family_profiles INT UNSIGNED NOT NULL DEFAULT 1,
  grace_period_days INT UNSIGNED NOT NULL DEFAULT 0,
  features_json JSON NULL,
  is_lifetime TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_plan_prices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id BIGINT UNSIGNED NOT NULL,
  country_code CHAR(2) NULL,
  currency CHAR(3) NOT NULL,
  amount_minor BIGINT UNSIGNED NOT NULL,
  compare_at_minor BIGINT UNSIGNED NULL,
  tax_inclusive TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  CONSTRAINT fk_plan_price_plan FOREIGN KEY (plan_id) REFERENCES book_subscription_plans(id) ON DELETE CASCADE,
  UNIQUE KEY uq_plan_country_currency (plan_id,country_code,currency)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  status ENUM('trialing','active','grace','past_due','expired','cancelled','paused') NOT NULL DEFAULT 'active',
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NULL,
  trial_ends_at DATETIME NULL,
  grace_ends_at DATETIME NULL,
  cancelled_at DATETIME NULL,
  auto_renew TINYINT(1) NOT NULL DEFAULT 0,
  payment_provider VARCHAR(40) NULL,
  provider_customer_id VARCHAR(190) NULL,
  provider_subscription_id VARCHAR(190) NULL,
  next_plan_id BIGINT UNSIGNED NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_subscription_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_subscription_plan FOREIGN KEY (plan_id) REFERENCES book_subscription_plans(id),
  CONSTRAINT fk_subscription_next_plan FOREIGN KEY (next_plan_id) REFERENCES book_subscription_plans(id) ON DELETE SET NULL,
  INDEX idx_subscription_entitlement (user_id,status,ends_at,grace_ends_at),
  INDEX idx_subscription_provider (payment_provider,provider_subscription_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_subscription_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  subscription_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  event_type VARCHAR(80) NOT NULL,
  old_plan_id BIGINT UNSIGNED NULL,
  new_plan_id BIGINT UNSIGNED NULL,
  metadata JSON NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sub_event_subscription FOREIGN KEY (subscription_id) REFERENCES book_subscriptions(id) ON DELETE CASCADE,
  CONSTRAINT fk_sub_event_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_sub_events_user_date (user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_coupons (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(64) NOT NULL UNIQUE,
  discount_type ENUM('percent','fixed','trial_days') NOT NULL,
  discount_value DECIMAL(12,2) NOT NULL,
  currency CHAR(3) NULL,
  max_redemptions INT UNSIGNED NULL,
  per_user_limit INT UNSIGNED NOT NULL DEFAULT 1,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  plan_ids_json JSON NULL,
  country_codes_json JSON NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_coupon_redemptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  coupon_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  order_id BIGINT UNSIGNED NULL,
  redeemed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_coupon_redemption_coupon FOREIGN KEY (coupon_id) REFERENCES book_coupons(id) ON DELETE CASCADE,
  CONSTRAINT fk_coupon_redemption_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_coupon_redemption_user (coupon_id,user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_tax_rates (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  country_code CHAR(2) NOT NULL,
  region_code VARCHAR(20) NULL,
  name VARCHAR(100) NOT NULL,
  rate DECIMAL(7,4) NOT NULL,
  is_inclusive TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  UNIQUE KEY uq_tax_region (country_code,region_code,name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(40) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NULL,
  coupon_id BIGINT UNSIGNED NULL,
  status ENUM('pending','paid','failed','cancelled','refunded','partially_refunded') DEFAULT 'pending',
  currency CHAR(3) NOT NULL,
  subtotal_minor BIGINT UNSIGNED NOT NULL,
  discount_minor BIGINT UNSIGNED DEFAULT 0,
  tax_minor BIGINT UNSIGNED DEFAULT 0,
  total_minor BIGINT UNSIGNED NOT NULL,
  country_code CHAR(2) NULL,
  metadata JSON NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES book_users(id),
  CONSTRAINT fk_order_plan FOREIGN KEY (plan_id) REFERENCES book_subscription_plans(id) ON DELETE SET NULL,
  CONSTRAINT fk_order_coupon FOREIGN KEY (coupon_id) REFERENCES book_coupons(id) ON DELETE SET NULL,
  INDEX idx_orders_user_date (user_id,created_at),
  INDEX idx_orders_status (status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS book_payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(40) NOT NULL,
  provider_payment_id VARCHAR(190) NULL,
  provider_order_id VARCHAR(190) NULL,
  status ENUM('created','authorized','captured','failed','refunded','partially_refunded') DEFAULT 'created',
  amount_minor BIGINT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL,
  raw_response JSON NULL,
  paid_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_order FOREIGN KEY (order_id) REFERENCES book_orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_payment_user FOREIGN KEY (user_id) REFERENCES book_users(id),
  UNIQUE KEY uq_provider_payment (provider,provider_payment_id),
  INDEX idx_payments_status_date (status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_invoices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_number VARCHAR(50) NOT NULL UNIQUE,
  order_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  status ENUM('draft','issued','paid','void','refunded') DEFAULT 'issued',
  currency CHAR(3) NOT NULL,
  subtotal_minor BIGINT UNSIGNED NOT NULL,
  discount_minor BIGINT UNSIGNED DEFAULT 0,
  tax_minor BIGINT UNSIGNED DEFAULT 0,
  total_minor BIGINT UNSIGNED NOT NULL,
  billing_details JSON NULL,
  pdf_path VARCHAR(255) NULL,
  issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_invoice_order FOREIGN KEY (order_id) REFERENCES book_orders(id),
  CONSTRAINT fk_invoice_user FOREIGN KEY (user_id) REFERENCES book_users(id),
  INDEX idx_invoices_user_date (user_id,issued_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_family_accounts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  max_profiles INT UNSIGNED DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_family_owner FOREIGN KEY (owner_user_id) REFERENCES book_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_family_profiles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  family_account_id BIGINT UNSIGNED NOT NULL,
  linked_user_id BIGINT UNSIGNED NULL,
  name VARCHAR(100) NOT NULL,
  avatar_path VARCHAR(255) NULL,
  is_child TINYINT(1) DEFAULT 0,
  content_rating VARCHAR(30) NULL,
  pin_hash VARCHAR(255) NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_family_profile_account FOREIGN KEY (family_account_id) REFERENCES book_family_accounts(id) ON DELETE CASCADE,
  CONSTRAINT fk_family_profile_user FOREIGN KEY (linked_user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_family_linked_user (linked_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_gift_subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  purchaser_user_id BIGINT UNSIGNED NOT NULL,
  recipient_email VARCHAR(190) NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  gift_code CHAR(32) NOT NULL UNIQUE,
  message TEXT NULL,
  status ENUM('pending','sent','redeemed','expired','cancelled') DEFAULT 'pending',
  expires_at DATETIME NULL,
  redeemed_by BIGINT UNSIGNED NULL,
  redeemed_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_gift_purchaser FOREIGN KEY (purchaser_user_id) REFERENCES book_users(id),
  CONSTRAINT fk_gift_plan FOREIGN KEY (plan_id) REFERENCES book_subscription_plans(id),
  CONSTRAINT fk_gift_redeemer FOREIGN KEY (redeemed_by) REFERENCES book_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_referrals (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  referrer_user_id BIGINT UNSIGNED NOT NULL,
  referred_user_id BIGINT UNSIGNED NOT NULL UNIQUE,
  code VARCHAR(32) NOT NULL,
  status ENUM('registered','qualified','rewarded','cancelled') DEFAULT 'registered',
  qualified_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_referral_referrer FOREIGN KEY (referrer_user_id) REFERENCES book_users(id),
  CONSTRAINT fk_referral_referred FOREIGN KEY (referred_user_id) REFERENCES book_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_referral_rewards (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  referral_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  reward_type ENUM('credit','free_days','coupon') NOT NULL,
  reward_value DECIMAL(12,2) NOT NULL,
  status ENUM('pending','available','used','expired') DEFAULT 'pending',
  expires_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_referral_reward_referral FOREIGN KEY (referral_id) REFERENCES book_referrals(id) ON DELETE CASCADE,
  CONSTRAINT fk_referral_reward_user FOREIGN KEY (user_id) REFERENCES book_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_categories (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parent_id BIGINT UNSIGNED NULL,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(140) NOT NULL UNIQUE,
  description TEXT NULL,
  image_path VARCHAR(255) NULL,
  seo_title VARCHAR(190) NULL,
  seo_description VARCHAR(320) NULL,
  is_active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0,
  CONSTRAINT fk_category_parent FOREIGN KEY (parent_id) REFERENCES book_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_author_profiles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NULL,
  name VARCHAR(180) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  bio LONGTEXT NULL,
  photo_path VARCHAR(255) NULL,
  website_url VARCHAR(255) NULL,
  social_links JSON NULL,
  verification_status ENUM('unclaimed','pending','verified','rejected') DEFAULT 'unclaimed',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_author_owner FOREIGN KEY (owner_user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  FULLTEXT KEY ft_authors (name,bio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_publishers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NULL,
  name VARCHAR(180) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  description LONGTEXT NULL,
  logo_path VARCHAR(255) NULL,
  website_url VARCHAR(255) NULL,
  verification_status ENUM('unclaimed','pending','verified','rejected') DEFAULT 'unclaimed',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_publisher_owner FOREIGN KEY (owner_user_id) REFERENCES book_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_genre_catalog (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  slug VARCHAR(120) NOT NULL UNIQUE,
  description TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_collections (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  description TEXT NULL,
  cover_path VARCHAR(255) NULL,
  is_featured TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_books (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  publisher_id BIGINT UNSIGNED NULL,
  primary_author_id BIGINT UNSIGNED NULL,
  category_id BIGINT UNSIGNED NULL,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(280) NULL UNIQUE,
  subtitle VARCHAR(255) NULL,
  author VARCHAR(255) NULL,
  category VARCHAR(120) NULL,
  description LONGTEXT NULL,
  isbn10 VARCHAR(20) NULL,
  isbn13 VARCHAR(20) NULL,
  language_code VARCHAR(15) DEFAULT 'en',
  publication_date DATE NULL,
  file_type ENUM('pdf','epub') NOT NULL DEFAULT 'pdf',
  file_path VARCHAR(500) NOT NULL,
  cover_path VARCHAR(500) NULL,
  original_filename VARCHAR(255) NULL,
  file_size BIGINT UNSIGNED DEFAULT 0,
  checksum_sha256 CHAR(64) NULL,
  encryption_key_id VARCHAR(100) NULL,
  drm_mode ENUM('none','signed_stream','encrypted_stream') DEFAULT 'signed_stream',
  total_pages INT UNSIGNED DEFAULT 0,
  total_words INT UNSIGNED DEFAULT 0,
  current_page INT UNSIGNED DEFAULT 1,
  current_location VARCHAR(255) NULL,
  reading_status ENUM('not_started','reading','completed','archived') DEFAULT 'not_started',
  access_type ENUM('personal','catalog') DEFAULT 'personal',
  requires_subscription TINYINT(1) DEFAULT 0,
  is_downloadable TINYINT(1) DEFAULT 0,
  is_scanned TINYINT(1) DEFAULT 0,
  is_published TINYINT(1) DEFAULT 1,
  moderation_status ENUM('pending','approved','rejected') DEFAULT 'approved',
  price_minor BIGINT UNSIGNED NULL,
  currency CHAR(3) NULL,
  seo_title VARCHAR(190) NULL,
  seo_description VARCHAR(320) NULL,
  tags_json JSON NULL,
  uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_opened_at DATETIME NULL,
  completed_at DATETIME NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_books_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_books_publisher FOREIGN KEY (publisher_id) REFERENCES book_publishers(id) ON DELETE SET NULL,
  CONSTRAINT fk_books_author FOREIGN KEY (primary_author_id) REFERENCES book_author_profiles(id) ON DELETE SET NULL,
  CONSTRAINT fk_books_category FOREIGN KEY (category_id) REFERENCES book_categories(id) ON DELETE SET NULL,
  INDEX idx_book_books_user (user_id),
  INDEX idx_book_books_catalog (access_type,is_published,requires_subscription),
  INDEX idx_book_books_status (reading_status),
  INDEX idx_books_isbn13 (isbn13),
  FULLTEXT KEY ft_books_search (title,subtitle,author,description,isbn10,isbn13)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS book_authors (
  book_id BIGINT UNSIGNED NOT NULL,
  author_id BIGINT UNSIGNED NOT NULL,
  contribution VARCHAR(80) DEFAULT 'author',
  sort_order INT DEFAULT 0,
  PRIMARY KEY (book_id,author_id),
  CONSTRAINT fk_book_authors_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_book_authors_author FOREIGN KEY (author_id) REFERENCES book_author_profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_genres (
  book_id BIGINT UNSIGNED NOT NULL,
  genre_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (book_id,genre_id),
  CONSTRAINT fk_book_genre_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_book_genre_genre FOREIGN KEY (genre_id) REFERENCES book_genre_catalog(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_collection_books (
  collection_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  sort_order INT DEFAULT 0,
  PRIMARY KEY (collection_id,book_id),
  CONSTRAINT fk_collection_book_collection FOREIGN KEY (collection_id) REFERENCES book_collections(id) ON DELETE CASCADE,
  CONSTRAINT fk_collection_book_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_chapters (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  book_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(255) NOT NULL,
  start_page INT UNSIGNED NOT NULL DEFAULT 1,
  end_page INT UNSIGNED NULL,
  epub_href VARCHAR(500) NULL,
  epub_cfi VARCHAR(500) NULL,
  sort_order INT UNSIGNED DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_book_chapters_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  INDEX idx_book_chapters_book (book_id,sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_pages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  book_id BIGINT UNSIGNED NOT NULL,
  chapter_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED NOT NULL,
  text_content LONGTEXT NULL,
  word_count INT UNSIGNED DEFAULT 0,
  is_text_extracted TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_book_pages_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_book_pages_chapter FOREIGN KEY (chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL,
  UNIQUE KEY uq_book_page (book_id,page_number),
  FULLTEXT KEY ft_book_page_text (text_content)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_progress (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  device_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED DEFAULT 1,
  location_value VARCHAR(500) NULL,
  progress_percent DECIMAL(6,3) DEFAULT 0,
  seconds_read BIGINT UNSIGNED DEFAULT 0,
  last_read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_progress_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_progress_profile FOREIGN KEY (profile_id) REFERENCES book_family_profiles(id) ON DELETE SET NULL,
  CONSTRAINT fk_progress_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_progress_device FOREIGN KEY (device_id) REFERENCES book_user_devices(id) ON DELETE SET NULL,
  UNIQUE KEY uq_progress_user_profile_book (user_id,profile_id,book_id),
  INDEX idx_progress_continue (user_id,last_read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_highlights (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  chapter_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED NOT NULL,
  selected_text TEXT NOT NULL,
  normalized_text TEXT NULL,
  color VARCHAR(30) DEFAULT 'yellow',
  category VARCHAR(40) DEFAULT 'important',
  start_offset INT UNSIGNED NULL,
  end_offset INT UNSIGNED NULL,
  location_value VARCHAR(500) NULL,
  rects_json JSON NULL,
  note TEXT NULL,
  is_private TINYINT(1) DEFAULT 1,
  share_token CHAR(32) NULL UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_highlight_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_highlight_profile FOREIGN KEY (profile_id) REFERENCES book_family_profiles(id) ON DELETE SET NULL,
  CONSTRAINT fk_highlight_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_highlight_chapter FOREIGN KEY (chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL,
  INDEX idx_highlights_user_book (user_id,book_id,page_number),
  FULLTEXT KEY ft_book_highlight_text (selected_text,note)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_underlines (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  page_number INT UNSIGNED NOT NULL,
  selected_text TEXT NOT NULL,
  underline_style VARCHAR(20) DEFAULT 'single',
  color VARCHAR(30) DEFAULT 'yellow',
  start_offset INT UNSIGNED NULL,
  end_offset INT UNSIGNED NULL,
  location_value VARCHAR(500) NULL,
  rects_json JSON NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_underline_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_underline_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  INDEX idx_underlines_user_book (user_id,book_id,page_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_notes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  book_id BIGINT UNSIGNED NULL,
  chapter_id BIGINT UNSIGNED NULL,
  highlight_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED NULL,
  location_value VARCHAR(500) NULL,
  note_type VARCHAR(30) DEFAULT 'general',
  title VARCHAR(255) NULL,
  content LONGTEXT NOT NULL,
  drawing_json JSON NULL,
  position_json JSON NULL,
  is_pinned TINYINT(1) DEFAULT 0,
  is_private TINYINT(1) DEFAULT 1,
  share_token CHAR(32) NULL UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_note_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_note_profile FOREIGN KEY (profile_id) REFERENCES book_family_profiles(id) ON DELETE SET NULL,
  CONSTRAINT fk_note_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_note_chapter FOREIGN KEY (chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL,
  CONSTRAINT fk_note_highlight FOREIGN KEY (highlight_id) REFERENCES book_highlights(id) ON DELETE SET NULL,
  INDEX idx_notes_user_book (user_id,book_id,page_number),
  FULLTEXT KEY ft_book_notes_content (title,content)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_bookmarks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  chapter_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED NOT NULL,
  location_value VARCHAR(500) NULL,
  name VARCHAR(150) NULL,
  type VARCHAR(30) DEFAULT 'page',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bookmark_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_bookmark_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_bookmark_chapter FOREIGN KEY (chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL,
  INDEX idx_bookmarks_user_book (user_id,book_id,page_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_vocabulary (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NULL,
  chapter_id BIGINT UNSIGNED NULL,
  word VARCHAR(120) NOT NULL,
  meaning TEXT NULL,
  simple_meaning TEXT NULL,
  bengali_meaning TEXT NULL,
  hindi_meaning TEXT NULL,
  synonyms TEXT NULL,
  antonyms TEXT NULL,
  pronunciation VARCHAR(180) NULL,
  example_sentence TEXT NULL,
  part_of_speech VARCHAR(80) NULL,
  source_page INT UNSIGNED NULL,
  review_level INT UNSIGNED DEFAULT 1,
  next_review_at DATETIME NULL,
  remembered_count INT UNSIGNED DEFAULT 0,
  forgotten_count INT UNSIGNED DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_vocab_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_vocab_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE SET NULL,
  CONSTRAINT fk_vocab_chapter FOREIGN KEY (chapter_id) REFERENCES book_chapters(id) ON DELETE SET NULL,
  UNIQUE KEY uq_user_word_book (user_id,word,book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_translations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NULL,
  page_number INT UNSIGNED NULL,
  original_text TEXT NOT NULL,
  translated_text TEXT NULL,
  source_language VARCHAR(20) DEFAULT 'auto',
  target_language VARCHAR(20) NOT NULL,
  provider VARCHAR(80) DEFAULT 'configured',
  status VARCHAR(20) DEFAULT 'success',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_translation_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_translation_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_reading_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  device_id BIGINT UNSIGNED NULL,
  start_page INT UNSIGNED NOT NULL,
  end_page INT UNSIGNED NULL,
  pages_read INT UNSIGNED DEFAULT 0,
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  duration_seconds INT UNSIGNED DEFAULT 0,
  focus_seconds INT UNSIGNED DEFAULT 0,
  device_type VARCHAR(20) DEFAULT 'desktop',
  CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_session_profile FOREIGN KEY (profile_id) REFERENCES book_family_profiles(id) ON DELETE SET NULL,
  CONSTRAINT fk_session_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  CONSTRAINT fk_session_device FOREIGN KEY (device_id) REFERENCES book_user_devices(id) ON DELETE SET NULL,
  INDEX idx_book_sessions_user (user_id,started_at),
  INDEX idx_book_sessions_book (book_id,started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_reading_goals (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  goal_type VARCHAR(20) NOT NULL,
  target_type VARCHAR(20) NOT NULL,
  target_value INT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NULL,
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_goal_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_goal_profile FOREIGN KEY (profile_id) REFERENCES book_family_profiles(id) ON DELETE SET NULL,
  INDEX idx_book_goals_user (user_id,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_reading_streaks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL UNIQUE,
  current_streak INT UNSIGNED DEFAULT 0,
  longest_streak INT UNSIGNED DEFAULT 0,
  total_days_read INT UNSIGNED DEFAULT 0,
  last_read_date DATE NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_streak_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_reading_challenges (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  description TEXT NULL,
  target_type ENUM('books','pages','minutes','streak') NOT NULL,
  target_value INT UNSIGNED NOT NULL,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  badge_id BIGINT UNSIGNED NULL,
  visibility ENUM('public','private','family') DEFAULT 'public',
  is_active TINYINT(1) DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_challenge_creator FOREIGN KEY (created_by) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_challenges_active (is_active,starts_at,ends_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_challenge_participants (
  challenge_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  progress_value INT UNSIGNED DEFAULT 0,
  rank_position INT UNSIGNED NULL,
  completed_at DATETIME NULL,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (challenge_id,user_id),
  CONSTRAINT fk_challenge_participant_challenge FOREIGN KEY (challenge_id) REFERENCES book_reading_challenges(id) ON DELETE CASCADE,
  CONSTRAINT fk_challenge_participant_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_challenge_rank (challenge_id,progress_value)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_achievement_badges (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NULL,
  icon_path VARCHAR(255) NULL,
  criteria_json JSON NULL,
  points INT UNSIGNED DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS book_user_badges (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  badge_id BIGINT UNSIGNED NOT NULL,
  awarded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  metadata JSON NULL,
  CONSTRAINT fk_user_badge_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_badge_badge FOREIGN KEY (badge_id) REFERENCES book_achievement_badges(id) ON DELETE CASCADE,
  UNIQUE KEY uq_user_badge (user_id,badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_reviews (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  title VARCHAR(180) NULL,
  body TEXT NULL,
  status ENUM('pending','published','rejected') DEFAULT 'pending',
  helpful_count INT UNSIGNED DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_review_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  UNIQUE KEY uq_review_user_book (user_id,book_id),
  INDEX idx_reviews_book_status (book_id,status,rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_wishlists (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  price_alert_enabled TINYINT(1) DEFAULT 0,
  target_price_minor BIGINT UNSIGNED NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_wishlist_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_wishlist_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  UNIQUE KEY uq_wishlist_user_book (user_id,book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_downloads (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  device_id BIGINT UNSIGNED NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  download_type ENUM('offline_cache','legal_file','export') DEFAULT 'offline_cache',
  bytes_transferred BIGINT UNSIGNED DEFAULT 0,
  expires_at DATETIME NULL,
  revoked_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_download_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_download_device FOREIGN KEY (device_id) REFERENCES book_user_devices(id) ON DELETE SET NULL,
  CONSTRAINT fk_download_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  INDEX idx_downloads_user_device (user_id,device_id,revoked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_recommendations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NOT NULL,
  score DECIMAL(8,5) NOT NULL,
  reason VARCHAR(255) NULL,
  algorithm_version VARCHAR(40) NULL,
  generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NULL,
  CONSTRAINT fk_recommendation_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_recommendation_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE CASCADE,
  UNIQUE KEY uq_recommendation_user_book (user_id,book_id),
  INDEX idx_recommendation_rank (user_id,score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_search_history (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  query VARCHAR(255) NOT NULL,
  results_count INT UNSIGNED DEFAULT 0,
  country_code CHAR(2) NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_search_history_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_search_trending (query,created_at),
  INDEX idx_search_user (user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_exports (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  book_id BIGINT UNSIGNED NULL,
  export_type VARCHAR(40) NOT NULL,
  file_path VARCHAR(255) NULL,
  status VARCHAR(20) DEFAULT 'pending',
  expires_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_export_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_export_book FOREIGN KEY (book_id) REFERENCES book_books(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_user_notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  channel ENUM('in_app','email','push') DEFAULT 'in_app',
  type VARCHAR(60) DEFAULT 'info',
  title VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  action_url VARCHAR(500) NULL,
  data_json JSON NULL,
  read_at DATETIME NULL,
  sent_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  INDEX idx_notifications_unread (user_id,read_at,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_notifications LIKE book_user_notifications;

CREATE TABLE IF NOT EXISTS book_push_subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  device_id BIGINT UNSIGNED NULL,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth_key TEXT NOT NULL,
  expires_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_push_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  CONSTRAINT fk_push_device FOREIGN KEY (device_id) REFERENCES book_user_devices(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_support_tickets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_number VARCHAR(30) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  assigned_to BIGINT UNSIGNED NULL,
  subject VARCHAR(190) NOT NULL,
  category VARCHAR(80) NULL,
  priority ENUM('low','normal','high','urgent') DEFAULT 'normal',
  status ENUM('open','waiting_user','waiting_staff','resolved','closed') DEFAULT 'open',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ticket_user FOREIGN KEY (user_id) REFERENCES book_users(id),
  CONSTRAINT fk_ticket_assignee FOREIGN KEY (assigned_to) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_tickets_queue (status,priority,updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_support_ticket_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  message LONGTEXT NOT NULL,
  attachments_json JSON NULL,
  is_staff_reply TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ticket_message_ticket FOREIGN KEY (ticket_id) REFERENCES book_support_tickets(id) ON DELETE CASCADE,
  CONSTRAINT fk_ticket_message_user FOREIGN KEY (user_id) REFERENCES book_users(id),
  INDEX idx_ticket_messages_thread (ticket_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_blog_categories (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(140) NOT NULL UNIQUE,
  description TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_blog_posts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  author_user_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NULL,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(280) NOT NULL UNIQUE,
  excerpt TEXT NULL,
  content LONGTEXT NOT NULL,
  featured_image_path VARCHAR(255) NULL,
  status ENUM('draft','scheduled','published','archived') DEFAULT 'draft',
  seo_title VARCHAR(190) NULL,
  seo_description VARCHAR(320) NULL,
  canonical_url VARCHAR(500) NULL,
  schema_json JSON NULL,
  published_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_blog_author FOREIGN KEY (author_user_id) REFERENCES book_users(id),
  CONSTRAINT fk_blog_category FOREIGN KEY (category_id) REFERENCES book_blog_categories(id) ON DELETE SET NULL,
  INDEX idx_blog_publish (status,published_at),
  FULLTEXT KEY ft_blog_search (title,excerpt,content)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_blog_comments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  parent_id BIGINT UNSIGNED NULL,
  author_name VARCHAR(120) NULL,
  author_email VARCHAR(190) NULL,
  body TEXT NOT NULL,
  status ENUM('pending','approved','spam','deleted') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_blog_comment_post FOREIGN KEY (post_id) REFERENCES book_blog_posts(id) ON DELETE CASCADE,
  CONSTRAINT fk_blog_comment_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  CONSTRAINT fk_blog_comment_parent FOREIGN KEY (parent_id) REFERENCES book_blog_comments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_advertisements (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  placement VARCHAR(80) NOT NULL,
  creative_type ENUM('image','html','native') DEFAULT 'image',
  creative_content LONGTEXT NULL,
  target_url VARCHAR(500) NULL,
  country_codes_json JSON NULL,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  impressions BIGINT UNSIGNED DEFAULT 0,
  clicks BIGINT UNSIGNED DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_email_templates (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  template_key VARCHAR(100) NOT NULL,
  locale VARCHAR(15) NOT NULL DEFAULT 'en',
  subject VARCHAR(255) NOT NULL,
  html_body LONGTEXT NOT NULL,
  text_body LONGTEXT NULL,
  variables_json JSON NULL,
  is_active TINYINT(1) DEFAULT 1,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_email_template_locale (template_key,locale)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_ui_translations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  locale VARCHAR(15) NOT NULL,
  namespace VARCHAR(80) NOT NULL DEFAULT 'app',
  translation_key VARCHAR(190) NOT NULL,
  translation_value LONGTEXT NOT NULL,
  is_machine_translated TINYINT(1) DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_translation (locale,namespace,translation_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_seo_metadata (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(80) NOT NULL,
  entity_id BIGINT UNSIGNED NULL,
  route_key VARCHAR(190) NULL,
  locale VARCHAR(15) DEFAULT 'en',
  title VARCHAR(190) NULL,
  description VARCHAR(320) NULL,
  canonical_url VARCHAR(500) NULL,
  robots VARCHAR(80) DEFAULT 'index,follow',
  open_graph_json JSON NULL,
  schema_json JSON NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_seo_entity_route (entity_type,entity_id,route_key,locale)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_feature_flags (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  flag_key VARCHAR(120) NOT NULL UNIQUE,
  name VARCHAR(160) NOT NULL,
  description VARCHAR(255) NULL,
  is_enabled TINYINT(1) DEFAULT 0,
  rollout_percent TINYINT UNSIGNED DEFAULT 100,
  conditions_json JSON NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_app_settings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(160) NOT NULL UNIQUE,
  setting_value LONGTEXT NULL,
  value_type ENUM('string','integer','boolean','json','encrypted') DEFAULT 'string',
  is_public TINYINT(1) DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_settings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  setting_key VARCHAR(120) NOT NULL,
  setting_value TEXT NULL,
  scope ENUM('user','system') DEFAULT 'user',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_book_settings_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_book_setting (user_id,setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_api_keys (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(50) NOT NULL,
  encrypted_key TEXT NOT NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_book_api_key_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_book_user_provider (user_id,provider)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_api_clients (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NULL,
  name VARCHAR(160) NOT NULL,
  client_id VARCHAR(80) NOT NULL UNIQUE,
  client_secret_hash VARCHAR(255) NOT NULL,
  scopes_json JSON NULL,
  rate_limit_per_minute INT UNSIGNED DEFAULT 60,
  is_active TINYINT(1) DEFAULT 1,
  last_used_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_api_client_owner FOREIGN KEY (owner_user_id) REFERENCES book_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_webhook_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  provider VARCHAR(40) NOT NULL,
  provider_event_id VARCHAR(190) NOT NULL,
  event_type VARCHAR(120) NOT NULL,
  payload JSON NOT NULL,
  status ENUM('received','processed','failed','ignored') DEFAULT 'received',
  attempts INT UNSIGNED DEFAULT 0,
  error_message TEXT NULL,
  received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME NULL,
  UNIQUE KEY uq_webhook_provider_event (provider,provider_event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_jobs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  queue VARCHAR(80) DEFAULT 'default',
  payload JSON NOT NULL,
  attempts INT UNSIGNED DEFAULT 0,
  available_at DATETIME NOT NULL,
  reserved_at DATETIME NULL,
  failed_at DATETIME NULL,
  error_message TEXT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_jobs_ready (queue,available_at,reserved_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_backups (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  type ENUM('database','files','full') NOT NULL,
  status ENUM('pending','running','completed','failed') DEFAULT 'pending',
  file_path VARCHAR(500) NULL,
  file_size BIGINT UNSIGNED DEFAULT 0,
  checksum_sha256 CHAR(64) NULL,
  started_at DATETIME NULL,
  completed_at DATETIME NULL,
  error_message TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_backup_creator FOREIGN KEY (created_by) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_backups_status_date (status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_system_health_checks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  check_key VARCHAR(100) NOT NULL,
  status ENUM('ok','warning','critical') NOT NULL,
  response_time_ms INT UNSIGNED NULL,
  details JSON NULL,
  checked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_health_check (check_key,checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS book_activity_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id BIGINT UNSIGNED NULL,
  ip_address VARCHAR(45) NULL,
  user_agent TEXT NULL,
  metadata JSON NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES book_users(id) ON DELETE SET NULL,
  INDEX idx_book_logs_user (user_id,created_at),
  INDEX idx_book_logs_action (action,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
