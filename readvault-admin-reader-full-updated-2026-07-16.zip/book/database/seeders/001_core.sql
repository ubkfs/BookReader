INSERT INTO book_subscription_plans (code,name,description,duration_days,trial_days,book_limit,offline_limit,family_profiles,grace_period_days,features_json,is_lifetime,is_active,sort_order) VALUES
('free','Free','Start reading with personal uploads.',NULL,0,10,1,1,0,JSON_OBJECT('catalog',false,'offline',true,'notes_export',false),0,1,1),
('trial_3_day','3-Day Trial','Full premium access for three days.',3,3,100,10,1,0,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true),0,1,2),
('monthly','1 Month','Monthly premium reading.',30,0,1000,25,2,3,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true,'family',true),0,1,3),
('quarterly','3 Months','Three months of premium reading.',90,0,1000,40,3,5,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true,'family',true),0,1,4),
('half_yearly','6 Months','Six months of premium reading.',180,0,1000,75,4,7,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true,'family',true),0,1,5),
('annual','12 Months','Annual premium membership.',365,0,1000,150,5,10,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true,'family',true,'priority_support',true),0,1,6),
('lifetime','Lifetime','Lifetime premium membership.',NULL,0,1000,250,6,0,JSON_OBJECT('catalog',true,'offline',true,'focus_mode',true,'family',true,'priority_support',true),1,0,7)
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),features_json=VALUES(features_json);

UPDATE book_plan_prices pp JOIN book_subscription_plans p ON p.id=pp.plan_id
SET pp.amount_minor=CASE p.code WHEN 'free' THEN 0 WHEN 'trial_3_day' THEN 0 WHEN 'monthly' THEN 999 WHEN 'quarterly' THEN 2499 WHEN 'half_yearly' THEN 4499 WHEN 'annual' THEN 7999 WHEN 'lifetime' THEN 19999 END
WHERE pp.country_code IS NULL AND pp.currency='USD';

INSERT INTO book_plan_prices (plan_id,country_code,currency,amount_minor,compare_at_minor,tax_inclusive)
SELECT p.id,NULL,'USD',CASE p.code WHEN 'free' THEN 0 WHEN 'trial_3_day' THEN 0 WHEN 'monthly' THEN 999 WHEN 'quarterly' THEN 2499 WHEN 'half_yearly' THEN 4499 WHEN 'annual' THEN 7999 WHEN 'lifetime' THEN 19999 END,NULL,0
FROM book_subscription_plans p
WHERE NOT EXISTS (SELECT 1 FROM book_plan_prices pp WHERE pp.plan_id=p.id AND pp.country_code IS NULL AND pp.currency='USD');

INSERT INTO book_feature_flags (flag_key,name,description,is_enabled) VALUES
('family_sharing','Family sharing','Multiple profiles under one subscription.',1),
('recommendations','Personalized recommendations','Behavior-based recommendations.',1),
('challenges','Reading challenges','Public and private reading challenges.',1),
('leaderboards','Leaderboards','Challenge and reading leaderboards.',1),
('encrypted_streaming','Encrypted streaming','Signed and encrypted book delivery.',1),
('gift_subscriptions','Gift subscriptions','Purchase plans for another person.',1),
('referrals','Affiliate and referral rewards','Reward successful referrals.',1),
('author_portal','Author portal','Author self-service dashboard.',1),
('publisher_portal','Publisher portal','Publisher catalog dashboard.',1),
('offline_reading','Offline reading','IndexedDB reading cache.',1),
('voice_reading','Voice reading','Browser text-to-speech.',1),
('ambient_audio','Ambient focus audio','Generated rain, forest, ocean and white noise.',1)
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description);

INSERT INTO book_roles (code,name,is_system) VALUES
('reader','Reader',1),('author','Author',1),('publisher','Publisher',1),('support','Support',1),('admin','Administrator',1),('super_admin','Super Administrator',1)
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO book_achievement_badges (code,name,description,points,criteria_json) VALUES
('first_book','First Chapter','Open your first book.',10,JSON_OBJECT('books_opened',1)),
('seven_day_streak','Seven-Day Reader','Read for seven consecutive days.',100,JSON_OBJECT('streak',7)),
('book_finisher','Book Finisher','Complete a book.',75,JSON_OBJECT('books_completed',1)),
('note_taker','Thoughtful Reader','Save 25 notes.',50,JSON_OBJECT('notes',25))
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description);

-- Operational admin defaults (ReadVault 2.3.0)
INSERT INTO book_email_templates(template_key,locale,subject,html_body,text_body,variables_json,is_active) VALUES
('verify_email','en','Verify your ReadVault email','<h1>Verify your email</h1><p>Hello {{name}},</p><p>Activate your ReadVault account using the secure link below.</p><p><a href="{{verification_url}}">Verify email address</a></p><p>This link expires at {{expires_at}}.</p>','Hello {{name}}, verify your email: {{verification_url}}','["name","verification_url","expires_at"]',1),
('password_reset','en','Reset your ReadVault password','<h1>Reset your password</h1><p>Hello {{name}},</p><p>A password reset was requested for your account.</p><p><a href="{{reset_url}}">Reset password</a></p><p>The link expires at {{expires_at}}.</p>','Hello {{name}}, reset your password: {{reset_url}}','["name","reset_url","expires_at"]',1),
('subscription_expiry','en','Your ReadVault subscription is ending soon','<p>Hello {{name}},</p><p>Your {{plan_name}} subscription ends on {{ends_at}}.</p><p><a href="{{plans_url}}">Review plans</a></p>','Hello {{name}}, your {{plan_name}} subscription ends on {{ends_at}}. Renew at {{plans_url}}','["name","plan_name","ends_at","plans_url"]',1),
('support_reply','en','Update on ticket {{ticket_number}}','<p>Hello {{name}},</p><p>ReadVault support replied to <strong>{{subject}}</strong>.</p><blockquote>{{message}}</blockquote><p><a href="{{ticket_url}}">Open your ticket</a></p>','Support replied to {{ticket_number}}: {{message}} {{ticket_url}}','["name","ticket_number","subject","message","ticket_url"]',1),
('welcome','en','Welcome to ReadVault','<h1>Welcome, {{name}}</h1><p>Your ReadVault account is ready.</p><p><a href="{{dashboard_url}}">Open ReadVault</a></p>','Welcome {{name}}. Open ReadVault: {{dashboard_url}}','["name","dashboard_url"]',1)
ON DUPLICATE KEY UPDATE subject=VALUES(subject),html_body=VALUES(html_body),text_body=VALUES(text_body),variables_json=VALUES(variables_json),is_active=VALUES(is_active);

INSERT INTO book_permissions(code,module,description) VALUES
('users.view','users','View users'),('users.manage','users','Create, edit and deactivate users'),
('books.view','books','View books'),('books.manage','books','Manage books'),
('payments.view','payments','View payments'),('payments.manage','payments','Reconcile payment records'),
('subscriptions.view','subscriptions','View subscriptions'),('subscriptions.manage','subscriptions','Manage subscriptions'),
('coupons.view','coupons','View coupons'),('coupons.manage','coupons','Manage coupons'),
('support.view','support','View support tickets'),('support.manage','support','Reply to and manage tickets'),
('email-templates.view','email-templates','View email templates'),('email-templates.manage','email-templates','Manage and test email templates'),
('backup.view','backup','View backups'),('backup.manage','backup','Create, download and delete backups'),
('family.view','family','View family households'),('family.manage','family','Manage family households and profiles'),
('roles.view','roles','View roles and permissions'),('roles.manage','roles','Manage roles and permissions'),
('api.view','api','View API clients'),('api.manage','api','Manage API clients'),
('reports.view','reports','View operational reports'),('analytics.view','analytics','View analytics'),
('activity.view','activity','View activity logs'),('health.view','health','View system health')
ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description);


-- Complete module permission catalogue for role-based access control.
INSERT INTO book_permissions(code,module,description) VALUES
('users.view','users','View users'),
('users.manage','users','Create and edit users'),
('users.delete','users','Delete users'),
('books.view','books','View books'),
('books.manage','books','Create and edit books'),
('books.delete','books','Delete books'),
('categories.view','categories','View categories'),
('categories.manage','categories','Create and edit categories'),
('categories.delete','categories','Delete categories'),
('publishers.view','publishers','View publishers'),
('publishers.manage','publishers','Create and edit publishers'),
('publishers.delete','publishers','Delete publishers'),
('authors.view','authors','View authors'),
('authors.manage','authors','Create and edit authors'),
('authors.delete','authors','Delete authors'),
('genres.view','genres','View genres'),
('genres.manage','genres','Create and edit genres'),
('genres.delete','genres','Delete genres'),
('collections.view','collections','View collections'),
('collections.manage','collections','Create and edit collections'),
('collections.delete','collections','Delete collections'),
('payments.view','payments','View payments'),
('payments.manage','payments','Create and edit payments'),
('payments.delete','payments','Delete payments'),
('subscriptions.view','subscriptions','View subscriptions'),
('subscriptions.manage','subscriptions','Create and edit subscriptions'),
('subscriptions.delete','subscriptions','Delete subscriptions'),
('coupons.view','coupons','View coupons'),
('coupons.manage','coupons','Create and edit coupons'),
('coupons.delete','coupons','Delete coupons'),
('trials.view','trials','View trials'),
('trials.manage','trials','Create and edit trials'),
('trials.delete','trials','Delete trials'),
('reviews.view','reviews','View reviews'),
('reviews.manage','reviews','Create and edit reviews'),
('reviews.delete','reviews','Delete reviews'),
('reports.view','reports','View reports'),
('reports.manage','reports','Create and edit reports'),
('reports.delete','reports','Delete reports'),
('analytics.view','analytics','View analytics'),
('analytics.manage','analytics','Create and edit analytics'),
('analytics.delete','analytics','Delete analytics'),
('seo.view','seo','View seo'),
('seo.manage','seo','Create and edit seo'),
('seo.delete','seo','Delete seo'),
('blogs.view','blogs','View blogs'),
('blogs.manage','blogs','Create and edit blogs'),
('blogs.delete','blogs','Delete blogs'),
('advertisements.view','advertisements','View advertisements'),
('advertisements.manage','advertisements','Create and edit advertisements'),
('advertisements.delete','advertisements','Delete advertisements'),
('support.view','support','View support'),
('support.manage','support','Create and edit support'),
('support.delete','support','Delete support'),
('notifications.view','notifications','View notifications'),
('notifications.manage','notifications','Create and edit notifications'),
('notifications.delete','notifications','Delete notifications'),
('reading-statistics.view','reading-statistics','View reading statistics'),
('reading-statistics.manage','reading-statistics','Create and edit reading statistics'),
('reading-statistics.delete','reading-statistics','Delete reading statistics'),
('downloads.view','downloads','View downloads'),
('downloads.manage','downloads','Create and edit downloads'),
('downloads.delete','downloads','Delete downloads'),
('invoices.view','invoices','View invoices'),
('invoices.manage','invoices','Create and edit invoices'),
('invoices.delete','invoices','Delete invoices'),
('taxes.view','taxes','View taxes'),
('taxes.manage','taxes','Create and edit taxes'),
('taxes.delete','taxes','Delete taxes'),
('api.view','api','View api'),
('api.manage','api','Create and edit api'),
('api.delete','api','Delete api'),
('translation.view','translation','View translation'),
('translation.manage','translation','Create and edit translation'),
('translation.delete','translation','Delete translation'),
('email-templates.view','email-templates','View email templates'),
('email-templates.manage','email-templates','Create and edit email templates'),
('email-templates.delete','email-templates','Delete email templates'),
('push.view','push','View push'),
('push.manage','push','Create and edit push'),
('push.delete','push','Delete push'),
('roles.view','roles','View roles'),
('roles.manage','roles','Create and edit roles'),
('roles.delete','roles','Delete roles'),
('activity.view','activity','View activity'),
('activity.manage','activity','Create and edit activity'),
('activity.delete','activity','Delete activity'),
('storage.view','storage','View storage'),
('storage.manage','storage','Create and edit storage'),
('storage.delete','storage','Delete storage'),
('backup.view','backup','View backup'),
('backup.manage','backup','Create and edit backup'),
('backup.delete','backup','Delete backup'),
('health.view','health','View health'),
('health.manage','health','Create and edit health'),
('health.delete','health','Delete health'),
('family.view','family','View family'),
('family.manage','family','Create and edit family'),
('family.delete','family','Delete family'),
('challenges.view','challenges','View challenges'),
('challenges.manage','challenges','Create and edit challenges'),
('challenges.delete','challenges','Delete challenges'),
('referrals.view','referrals','View referrals'),
('referrals.manage','referrals','Create and edit referrals'),
('referrals.delete','referrals','Delete referrals'),
('gifts.view','gifts','View gifts'),
('gifts.manage','gifts','Create and edit gifts'),
('gifts.delete','gifts','Delete gifts'),
('settings.view','settings','View settings'),
('settings.manage','settings','Create and edit settings'),
('settings.delete','settings','Delete settings'),
('feature-flags.view','feature-flags','View feature flags'),
('feature-flags.manage','feature-flags','Create and edit feature flags'),
('feature-flags.delete','feature-flags','Delete feature flags')
ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description);

INSERT IGNORE INTO book_role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM book_roles r CROSS JOIN book_permissions p WHERE r.code IN ('admin','super_admin');
INSERT IGNORE INTO book_role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM book_roles r JOIN book_permissions p ON p.code IN ('support.view','support.manage','users.view') WHERE r.code='support';
