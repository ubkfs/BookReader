<?php
require_once __DIR__ . '/includes/bootstrap.php'; book_require_login();
$db = book_db();
$uid = book_user_id();
$stmt = $db->prepare('SELECT v.*, b.title book_title FROM book_vocabulary v LEFT JOIN book_books b ON v.book_id=b.id WHERE v.user_id=? ORDER BY COALESCE(v.next_review_at, v.created_at) ASC LIMIT 300');
$stmt->execute([$uid]);
$words = $stmt->fetchAll(PDO::FETCH_ASSOC);
$due = array_values(array_filter($words, fn($w)=>empty($w['next_review_at']) || strtotime($w['next_review_at']) <= time()));
function book_vocab_best_meaning(array $w): string { return (string)($w['meaning'] ?: ($w['simple_meaning'] ?: ($w['hindi_meaning'] ?: $w['bengali_meaning']))); }
book_render_header('Vocabulary Builder','book-vocabulary');
?>
<main class="book-app"><div class="book-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>Vocabulary Builder</h1><p>Save, edit, delete and revise difficult words.</p></div><div class="book-actions"><button class="book-btn" id="addWordBtn">Add Word</button><a class="book-btn secondary" href="<?= book_url('api/export.php?type=csv_vocabulary') ?>">Export CSV</a></div></div>
<div class="book-grid"><div class="book-card book-span-4"><h3>Total Words</h3><strong style="font-size:42px"><?= count($words) ?></strong></div><div class="book-card book-span-4"><h3>Due for Review</h3><strong style="font-size:42px"><?= count($due) ?></strong></div><div class="book-card book-span-4"><h3>Quiz</h3><button class="book-btn" id="startQuiz">Start Quiz</button></div></div>
<div class="book-card" style="margin-top:18px"><h3>Flashcard</h3><div class="book-flashcard" id="flashcard"><?= $due ? book_e($due[0]['word']) : 'No words due' ?></div><div class="book-actions" style="margin-top:12px"><button class="book-btn success" id="remembered">Remembered</button><button class="book-btn danger" id="forgot">Forgot</button></div></div>
<div class="book-card" style="margin-top:18px"><h3>Saved Words</h3><div class="book-table-wrap"><table class="book-table"><thead><tr><th>Word</th><th>Meaning</th><th>Source</th><th>Review</th><th>Actions</th></tr></thead><tbody><?php foreach($words as $w): ?><tr data-word='<?= book_e(json_encode($w, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>'><td><strong><?= book_e($w['word']) ?></strong><br><small><?= book_e($w['part_of_speech']) ?></small></td><td><?php $bm = book_vocab_best_meaning($w); ?><?= book_e(mb_strlen($bm,'UTF-8')>180 ? mb_substr($bm,0,180,'UTF-8').'...' : $bm) ?></td><td><?= book_e($w['book_title']) ?> <?= $w['source_page']?'Page '.(int)$w['source_page']:'' ?></td><td>Level <?= (int)$w['review_level'] ?><br><small><?= book_e($w['next_review_at']) ?></small></td><td><div class="book-inline-actions"><button class="book-icon-btn edit-word">Edit</button><button class="book-icon-btn danger delete-word" data-id="<?= (int)$w['id'] ?>">Delete</button></div></td></tr><?php endforeach; if(!$words): ?><tr><td colspan="5" class="book-muted">No words saved yet.</td></tr><?php endif; ?></tbody></table></div></div>
</section></div></main>

<div id="wordModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999999;align-items:center;justify-content:center;padding:20px">
  <div class="book-card" style="max-width:720px;width:100%;max-height:90vh;overflow:auto">
    <h3 id="wordModalTitle">Add Word</h3>
    <form id="wordForm" class="book-form">
      <input type="hidden" name="id" id="wordId">
      <label class="book-label">Word</label><input class="book-input" name="word" id="wordText" required>
      <label class="book-label">Meaning</label><textarea class="book-textarea" name="meaning" id="wordMeaning"></textarea>
      <label class="book-label">Simple Meaning</label><textarea class="book-textarea" name="simple_meaning" id="wordSimple"></textarea>
      <div class="book-mini-grid"><input class="book-input" name="hindi_meaning" id="wordHindi" placeholder="Hindi meaning"><input class="book-input" name="bengali_meaning" id="wordBengali" placeholder="Bengali meaning"></div>
      <div class="book-mini-grid"><input class="book-input" name="part_of_speech" id="wordPos" placeholder="Part of speech"><input class="book-input" name="pronunciation" id="wordPron" placeholder="Pronunciation"></div>
      <div class="book-mini-grid"><input class="book-input" name="synonyms" id="wordSyn" placeholder="Synonyms"><input class="book-input" name="antonyms" id="wordAnt" placeholder="Antonyms"></div>
      <textarea class="book-textarea" name="example_sentence" id="wordExample" placeholder="Example sentence"></textarea>
      <div class="book-actions"><button class="book-btn" type="submit">Save</button><button class="book-btn secondary" type="button" id="closeWordModal">Cancel</button></div>
    </form>
  </div>
</div>

<script>
const due=<?= json_encode($due, JSON_UNESCAPED_UNICODE) ?>;let idx=0,showBack=false;const card=document.getElementById('flashcard');
function render(){ if(!due.length){card.textContent='No words due';return;} const w=due[idx%due.length];card.textContent=showBack?(w.meaning||w.simple_meaning||w.hindi_meaning||w.bengali_meaning||'No meaning saved'):w.word;}
card.addEventListener('click',()=>{showBack=!showBack;render();});
document.getElementById('remembered').onclick=()=>review('remembered');document.getElementById('forgot').onclick=()=>review('forgotten');
async function review(result){if(!due.length)return;const w=due[idx%due.length];await bookApi('api/vocabulary.php?action=review',{id:w.id,result});idx++;showBack=false;render();}
document.getElementById('startQuiz').onclick=async()=>{const r=await fetch('<?= book_url('api/vocabulary.php?action=quiz') ?>').then(r=>r.json());if(!r.questions?.length){alert('Add more words first.');return;}let score=0;for(const q of r.questions){const meta=(q.meta&&q.meta.length)?'\n\nWord details saved for revision:\n'+q.meta.join('\n'):'';const ans=prompt(q.question+meta+'\n\n'+q.options.map((o,i)=>String.fromCharCode(65+i)+'. '+o).join('\n'));if(ans&&q.options[(ans.toUpperCase().charCodeAt(0)-65)]===q.answer)score++;}alert('Score: '+score+'/'+r.questions.length);};

const modal=document.getElementById('wordModal');
function openWordModal(w={}){modal.style.display='flex';document.getElementById('wordModalTitle').textContent=w.id?'Edit Word':'Add Word';document.getElementById('wordId').value=w.id||'';document.getElementById('wordText').value=w.word||'';document.getElementById('wordMeaning').value=w.meaning||'';document.getElementById('wordSimple').value=w.simple_meaning||'';document.getElementById('wordHindi').value=w.hindi_meaning||'';document.getElementById('wordBengali').value=w.bengali_meaning||'';document.getElementById('wordPos').value=w.part_of_speech||'';document.getElementById('wordPron').value=w.pronunciation||'';document.getElementById('wordSyn').value=w.synonyms||'';document.getElementById('wordAnt').value=w.antonyms||'';document.getElementById('wordExample').value=w.example_sentence||'';}
document.getElementById('addWordBtn').onclick=()=>openWordModal();document.getElementById('closeWordModal').onclick=()=>modal.style.display='none';
document.querySelectorAll('.edit-word').forEach(btn=>btn.onclick=()=>openWordModal(JSON.parse(btn.closest('tr').dataset.word)));
document.querySelectorAll('.delete-word').forEach(btn=>btn.onclick=async()=>{if(!confirm('Delete this word?'))return;const r=await bookApi('api/vocabulary.php?action=delete',{id:btn.dataset.id});if(r.success)location.reload();else alert(r.message||'Failed');});
document.getElementById('wordForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target);const id=fd.get('id');const r=await bookApi('api/vocabulary.php?action='+(id?'update':'save'),fd);if(r.success)location.reload();else alert(r.message||'Failed');};
</script>
<?php book_render_footer(); ?>
