<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$sub = book_subscription();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    book_verify_csrf();
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'cancel' && $sub) {
        $db->prepare('UPDATE book_subscriptions SET auto_renew=0,cancelled_at=NOW(),status=IF(ends_at IS NULL,"cancelled",status) WHERE id=? AND user_id=?')->execute([$sub['id'], $uid]);
        book_log('subscription.cancel_requested', 'subscription', (int)$sub['id']);
        book_flash('ok', 'Auto-renewal has been disabled. Access remains available until the entitlement ends.');
    } elseif ($action === 'toggle_renew' && $sub) {
        $renew = isset($_POST['auto_renew']) ? 1 : 0;
        $db->prepare('UPDATE book_subscriptions SET auto_renew=? WHERE id=? AND user_id=?')->execute([$renew, $sub['id'], $uid]);
        book_flash('ok', 'Renewal preference updated.');
    }
    header('Location: ' . book_url('account/index.php'));
    exit;
}

$stmt = $db->prepare('SELECT * FROM book_invoices WHERE user_id=? ORDER BY issued_at DESC LIMIT 8');
$stmt->execute([$uid]);
$invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $db->prepare('SELECT d.*,b.title FROM book_downloads d JOIN book_books b ON b.id=d.book_id WHERE d.user_id=? ORDER BY d.created_at DESC LIMIT 8');
$stmt->execute([$uid]);
$downloads = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $db->prepare('SELECT b.name,b.description,b.points,ub.awarded_at FROM book_user_badges ub JOIN book_achievement_badges b ON b.id=ub.badge_id WHERE ub.user_id=? ORDER BY ub.awarded_at DESC');
$stmt->execute([$uid]);
$badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $db->prepare('SELECT COUNT(*) FROM book_user_devices WHERE user_id=? AND revoked_at IS NULL');
$stmt->execute([$uid]);
$activeDevices = (int)$stmt->fetchColumn();

book_render_header('Account Center', 'account');
?>
<main class="book-app" id="main-content"><div class="book-shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<section class="book-content">
  <div class="book-topbar"><div class="book-title"><h1>Account center</h1><p>Manage your subscription, invoices, offline downloads, devices, badges, and account security.</p></div><a class="book-btn secondary" href="<?= book_url('settings.php') ?>">Profile settings</a></div>
  <?php if ($message = book_flash('ok')): ?><div class="book-alert ok"><?= book_e($message) ?></div><?php endif; ?>
  <div class="book-grid" style="margin-top:18px">
    <div class="book-card book-span-6">
      <span class="book-chip ok"><?= book_e((string)($sub['status'] ?? 'free')) ?></span>
      <h2><?= book_e((string)($sub['name'] ?? 'Free plan')) ?></h2>
      <p class="book-muted"><?php if (!empty($sub['ends_at'])): ?>Access ends <?= book_e(date('M j, Y', strtotime((string)$sub['ends_at']))) ?><?php else: ?>No fixed expiry<?php endif; ?><?= !empty($sub['grace_ends_at']) ? ' · Grace until ' . book_e(date('M j, Y', strtotime((string)$sub['grace_ends_at']))) : '' ?></p>
      <ul class="feature-list"><li><?= (int)($sub['book_limit'] ?? 10) ?> personal books</li><li><?= (int)($sub['offline_limit'] ?? 1) ?> offline books</li><li><?= (int)($sub['family_profiles'] ?? 1) ?> family profiles</li><li><?= $activeDevices ?> active devices</li></ul>
      <div class="book-actions"><a class="book-btn" href="<?= book_url('subscription/plans.php') ?>">Change plan</a>
      <?php if ($sub): ?><form method="post"><input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>"><input type="hidden" name="action" value="toggle_renew"><label class="book-btn secondary"><input type="checkbox" name="auto_renew" <?= $sub['auto_renew'] ? 'checked' : '' ?> onchange="this.form.submit()"> Auto renew</label></form><form method="post" onsubmit="return confirm('Disable renewal for this subscription?')"><input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>"><input type="hidden" name="action" value="cancel"><button class="book-btn danger">Cancel renewal</button></form><?php endif; ?></div>
    </div>
    <div class="book-card book-span-6"><h3>Achievements</h3><?php foreach ($badges as $badge): ?><div class="book-kv-item"><strong>🏅 <?= book_e((string)$badge['name']) ?></strong><span class="float-end book-muted"><?= (int)$badge['points'] ?> pts</span><small class="book-muted d-block"><?= book_e((string)$badge['description']) ?></small></div><?php endforeach; ?><?php if (!$badges): ?><p class="book-muted">Complete reading activities to earn badges.</p><a class="book-btn small secondary" href="<?= book_url('challenges.php') ?>">View challenges</a><?php endif; ?></div>
    <div class="book-card book-span-7"><h3>Recent invoices</h3><div class="book-table-wrap"><table class="book-table"><thead><tr><th>Invoice</th><th>Status</th><th>Total</th><th>Date</th><th></th></tr></thead><tbody><?php foreach ($invoices as $invoice): ?><tr><td><?= book_e((string)$invoice['invoice_number']) ?></td><td><?= book_e((string)$invoice['status']) ?></td><td><?= book_e(book_format_money((int)$invoice['total_minor'], (string)$invoice['currency'])) ?></td><td><?= book_e((string)$invoice['issued_at']) ?></td><td><a class="book-btn small secondary" href="<?= book_url('account/invoice.php?id=' . (int)$invoice['id']) ?>">View</a></td></tr><?php endforeach; ?><?php if (!$invoices): ?><tr><td colspan="5" class="book-muted">No invoices yet.</td></tr><?php endif; ?></tbody></table></div></div>
    <div class="book-card book-span-5"><h3>Offline downloads</h3><?php foreach ($downloads as $download): ?><div class="book-kv-item"><strong><?= book_e((string)$download['title']) ?></strong><span class="book-chip <?= $download['revoked_at'] ? 'danger' : 'ok' ?>"><?= $download['revoked_at'] ? 'Revoked' : 'Active' ?></span><small class="book-muted d-block"><?= book_e((string)$download['created_at']) ?></small></div><?php endforeach; ?><?php if (!$downloads): ?><p class="book-muted">No offline books saved.</p><?php endif; ?></div>
  </div>
</section></div></main>
<?php book_render_footer(); ?>
