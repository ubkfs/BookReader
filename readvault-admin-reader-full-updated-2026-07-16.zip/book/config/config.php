<?php
declare(strict_types=1);

/**
 * Independent ReadVault SaaS configuration.
 * This file never imports anything from teknouf.com.
 */

$root = dirname(__DIR__);
$envFile = $root . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        $value = trim($value, "\"'");
        if (getenv($key) === false) putenv($key . '=' . $value);
    }
}

$env = static function (string $key, mixed $default = null): mixed {
    $value = getenv($key);
    if ($value === false || $value === '') return $default;
    return match (strtolower((string)$value)) {
        'true' => true,
        'false' => false,
        'null' => null,
        default => $value,
    };
};

$appUrl = rtrim((string)$env('APP_URL', 'https://services.teknouf.com/book'), '/');
$appPath = (string)(parse_url($appUrl, PHP_URL_PATH) ?: '/');
$sessionPath = rtrim($appPath, '/') ?: '/';
$tablePrefix = (string)$env('DB_TABLE_PREFIX', 'book_');
if ($tablePrefix !== 'book_') {
    throw new RuntimeException('DB_TABLE_PREFIX must remain book_ for this build.');
}

$config = [
    'app' => [
        'name' => (string)$env('APP_NAME', 'ReadVault'),
        'env' => (string)$env('APP_ENV', 'production'),
        'debug' => (bool)$env('APP_DEBUG', false),
        'url' => $appUrl,
        'admin_url' => rtrim((string)$env('ADMIN_URL', $appUrl . '/admin'), '/'),
        'timezone' => (string)$env('APP_TIMEZONE', 'UTC'),
        'key' => (string)$env('APP_KEY', 'change-this-app-key-before-production'),
        'jwt_secret' => (string)$env('JWT_SECRET', 'change-this-jwt-secret-before-production'),
        'signed_url_secret' => (string)$env('SIGNED_URL_SECRET', 'change-this-signed-url-secret-before-production'),
        'locale' => (string)$env('APP_LOCALE', 'en'),
        'fallback_locale' => 'en',
    ],
    'database' => [
        'host' => (string)$env('DB_HOST', '127.0.0.1'),
        'port' => (int)$env('DB_PORT', 3306),
        'name' => (string)$env('DB_DATABASE', 'readvault_saas'),
        'username' => (string)$env('DB_USERNAME', 'root'),
        'password' => (string)$env('DB_PASSWORD', ''),
        'table_prefix' => $tablePrefix,
        'charset' => 'utf8mb4',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ],
    ],
    'paths' => [
        'root' => $root,
        'uploads' => $root . '/storage/private/uploads',
        'books' => $root . '/storage/private/books',
        'covers' => $root . '/storage/private/covers',
        'exports' => $root . '/storage/exports',
        'cache' => $root . '/storage/cache',
        'logs' => $root . '/storage/logs',
        'backups' => $root . '/storage/backups',
    ],
    'session' => [
        'name' => (string)$env('SESSION_NAME', 'readvault_session'),
        'lifetime' => (int)$env('SESSION_LIFETIME', 120),
        'secure' => (bool)$env('SESSION_SECURE', true),
        'http_only' => true,
        'same_site' => (string)$env('SESSION_SAMESITE', 'Lax'),
        'path' => $sessionPath,
        'regenerate_interval' => 900,
    ],
    'mail' => [
        'driver' => (string)$env('MAIL_DRIVER', 'mail'),
        'host' => (string)$env('MAIL_HOST', ''),
        'port' => (int)$env('MAIL_PORT', 587),
        'username' => (string)$env('MAIL_USERNAME', ''),
        'password' => (string)$env('MAIL_PASSWORD', ''),
        'encryption' => (string)$env('MAIL_ENCRYPTION', 'tls'),
        'from_address' => (string)$env('MAIL_FROM_ADDRESS', 'noreply@services.teknouf.com'),
        'from_name' => (string)$env('MAIL_FROM_NAME', 'ReadVault'),
    ],
    'cache' => [
        'driver' => (string)$env('CACHE_DRIVER', 'file'),
        'ttl' => (int)$env('CACHE_TTL', 300),
    ],
    'uploads' => [
        'max_mb' => (int)$env('MAX_UPLOAD_MB', 200),
        'allowed_extensions' => ['pdf', 'epub'],
        'allowed_mimes' => ['application/pdf', 'application/epub+zip', 'application/zip', 'application/octet-stream'],
    ],
    'payments' => [
        'currency' => (string)$env('DEFAULT_CURRENCY', 'USD'),
        'stripe' => [
            'public_key' => (string)$env('STRIPE_PUBLIC_KEY', ''),
            'secret_key' => (string)$env('STRIPE_SECRET_KEY', ''),
            'webhook_secret' => (string)$env('STRIPE_WEBHOOK_SECRET', ''),
        ],
        'razorpay' => [
            'key_id' => (string)$env('RAZORPAY_KEY_ID', ''),
            'key_secret' => (string)$env('RAZORPAY_KEY_SECRET', ''),
            'webhook_secret' => (string)$env('RAZORPAY_WEBHOOK_SECRET', ''),
        ],
        'paypal' => ['enabled' => false],
        'apple_pay' => ['enabled' => false],
        'google_pay' => ['enabled' => false],
    ],
    'oauth' => [
        'google' => ['client_id' => (string)$env('GOOGLE_CLIENT_ID', ''), 'client_secret' => (string)$env('GOOGLE_CLIENT_SECRET', '')],
        'apple' => ['client_id' => (string)$env('APPLE_CLIENT_ID', ''), 'team_id' => (string)$env('APPLE_TEAM_ID', '')],
        'facebook' => ['client_id' => (string)$env('FACEBOOK_CLIENT_ID', ''), 'client_secret' => (string)$env('FACEBOOK_CLIENT_SECRET', '')],
    ],
    'apis' => [
        'translation_url' => (string)$env('TRANSLATION_API_URL', ''),
        'translation_key' => (string)$env('TRANSLATION_API_KEY', ''),
        'openai_key' => (string)$env('OPENAI_API_KEY', ''),
        'gemini_key' => (string)$env('GEMINI_API_KEY', ''),
        'push_public_key' => (string)$env('VAPID_PUBLIC_KEY', ''),
        'push_private_key' => (string)$env('VAPID_PRIVATE_KEY', ''),
    ],
    'security' => [
        'csp' => true,
        'rate_limit_per_minute' => 120,
        'login_attempts' => 5,
        'login_lock_minutes' => 15,
        'signed_url_ttl' => (int)$env('SIGNED_URL_TTL', 14400),
        'remember_days' => 30,
        'cron_secret' => (string)$env('CRON_SECRET', ''),
        'trust_proxy' => (bool)$env('TRUST_PROXY', false),
        'watermark_reader' => (bool)$env('READER_WATERMARK', true),
    ],
    'features' => [
        'family_sharing' => true,
        'recommendations' => true,
        'challenges' => true,
        'leaderboards' => true,
        'encrypted_streaming' => true,
        'gift_subscriptions' => true,
        'referrals' => true,
        'author_portal' => true,
        'publisher_portal' => true,
        'offline_reading' => true,
        'voice_reading' => true,
        'ambient_audio' => true,
    ],
];

if (!defined('BOOK_CONFIG')) define('BOOK_CONFIG', $config);
if (!defined('BOOK_MODULE_DIR')) define('BOOK_MODULE_DIR', $root);
if (!defined('BOOK_BASE_URL')) define('BOOK_BASE_URL', $config['app']['url']);
if (!defined('BOOK_ADMIN_URL')) define('BOOK_ADMIN_URL', $config['app']['admin_url']);
if (!defined('BOOK_STORAGE_DIR')) define('BOOK_STORAGE_DIR', $config['paths']['books']);
if (!defined('BOOK_EXPORT_DIR')) define('BOOK_EXPORT_DIR', $config['paths']['exports']);
if (!defined('BOOK_SECRET')) define('BOOK_SECRET', $config['app']['key']);
if (!defined('BOOK_TABLE_PREFIX')) define('BOOK_TABLE_PREFIX', $config['database']['table_prefix']);

date_default_timezone_set($config['app']['timezone']);
return $config;
