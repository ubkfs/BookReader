<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
book_require_admin('backup.view');
$db=book_db();$backupDir=BOOK_CONFIG['paths']['backups'];if(!is_dir($backupDir))@mkdir($backupDir,0750,true);

function rv_sql_quote(PDO $db,mixed $value): string {if($value===null)return'NULL';if(is_bool($value))return$value?'1':'0';return$db->quote((string)$value);}
function rv_database_dump(PDO $db,string $target): void {
 $fh=fopen($target,'wb');if(!$fh)throw new RuntimeException('Unable to create database backup file.');
 fwrite($fh,"-- ReadVault database backup\n-- Generated ".date(DATE_ATOM)."\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
 $tables=$db->query("SHOW TABLES LIKE 'book\\_%'")->fetchAll(PDO::FETCH_COLUMN);
 foreach($tables as $table){
  if(!preg_match('/^book_[a-z0-9_]+$/i',(string)$table))continue;
  $create=$db->query('SHOW CREATE TABLE `'.$table.'`')->fetch(PDO::FETCH_NUM);
  fwrite($fh,"DROP TABLE IF EXISTS `{$table}`;\n".($create[1]??'').";\n\n");
  $st=$db->query('SELECT * FROM `'.$table.'`');$batch=[];
  while($row=$st->fetch(PDO::FETCH_ASSOC)){
   $batch[]='('.implode(',',array_map(static fn($v)=>rv_sql_quote($db,$v),array_values($row))).')';
   if(count($batch)>=100){fwrite($fh,'INSERT INTO `'.$table.'` (`'.implode('`,`',array_keys($row)).'`) VALUES\n'.implode(",\n",$batch).";\n");$batch=[];}
  }
  if($batch){$keys=array_keys($row??[]);if($keys)fwrite($fh,'INSERT INTO `'.$table.'` (`'.implode('`,`',$keys).'`) VALUES\n'.implode(",\n",$batch).";\n");}
  fwrite($fh,"\n");
 }
 fwrite($fh,"SET FOREIGN_KEY_CHECKS=1;\n");fclose($fh);
}
function rv_zip_tree(ZipArchive $zip,string $root,string $prefix=''): void {
 $real=realpath($root);if(!$real||!is_dir($real))return;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($real,FilesystemIterator::SKIP_DOTS));
 foreach($it as $file){if(!$file->isFile())continue;$path=$file->getRealPath();$rel=ltrim(str_replace('\\','/',substr($path,strlen($real))),'/');$zip->addFile($path,trim($prefix.'/'.$rel,'/'));}
}
function rv_backup_path(string $path,string $root): ?string {$real=realpath($path);$base=realpath($root);return($real&&$base&&str_starts_with($real,$base.DIRECTORY_SEPARATOR))?$real:null;}

if(isset($_GET['download'])){
 $id=(int)$_GET['download'];$st=$db->prepare('SELECT * FROM book_backups WHERE id=? AND status="completed"');$st->execute([$id]);$b=$st->fetch();$path=$b?rv_backup_path((string)$b['file_path'],$backupDir):null;if(!$path||!is_file($path)){http_response_code(404);exit('Backup not found.');}
 header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.basename($path).'"');header('Content-Length: '.filesize($path));header('X-Content-Type-Options: nosniff');readfile($path);exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'){book_require_admin('backup.manage');
 book_verify_csrf();$action=(string)($_POST['action']??'');$id=max(0,(int)($_POST['id']??0));
 try{
  if($action==='create'){
   $type=in_array($_POST['type']??'', ['database','files','full'],true)?(string)$_POST['type']:'database';
   $db->prepare('INSERT INTO book_backups(type,status,started_at,created_by) VALUES(?,"running",NOW(),?)')->execute([$type,book_user_id()]);$id=(int)$db->lastInsertId();$stamp=date('Ymd-His');$base='readvault-'.$type.'-'.$stamp;
   try{
    if($type==='database'){$path=$backupDir.'/'.$base.'.sql';rv_database_dump($db,$path);}
    else{
     if(!class_exists('ZipArchive'))throw new RuntimeException('PHP ZipArchive extension is required for file backups.');$path=$backupDir.'/'.$base.'.zip';$zip=new ZipArchive();if($zip->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Unable to create ZIP backup.');
     if($type==='full'){$tmp=$backupDir.'/database-'.$stamp.'.sql';rv_database_dump($db,$tmp);$zip->addFile($tmp,'database/readvault.sql');}
     rv_zip_tree($zip,BOOK_CONFIG['paths']['books'],'storage/private/books');rv_zip_tree($zip,BOOK_CONFIG['paths']['covers'],'storage/private/covers');rv_zip_tree($zip,BOOK_CONFIG['paths']['uploads'],'storage/private/uploads');rv_zip_tree($zip,BOOK_CONFIG['paths']['exports'],'storage/exports');$zip->close();if(isset($tmp)&&is_file($tmp))unlink($tmp);
    }
    $size=filesize($path)?:0;$checksum=hash_file('sha256',$path);$db->prepare('UPDATE book_backups SET status="completed",file_path=?,file_size=?,checksum_sha256=?,completed_at=NOW() WHERE id=?')->execute([$path,$size,$checksum,$id]);book_log('admin.backup.created','backup',$id,['type'=>$type,'size'=>$size]);book_flash('ok',ucfirst($type).' backup completed.');
   }catch(Throwable $e){$db->prepare('UPDATE book_backups SET status="failed",error_message=?,completed_at=NOW() WHERE id=?')->execute([mb_substr($e->getMessage(),0,2000),$id]);throw $e;}
  }elseif($action==='delete'){$st=$db->prepare('SELECT file_path FROM book_backups WHERE id=?');$st->execute([$id]);$path=rv_backup_path((string)$st->fetchColumn(),$backupDir);if($path&&is_file($path))unlink($path);$db->prepare('DELETE FROM book_backups WHERE id=?')->execute([$id]);book_log('admin.backup.deleted','backup',$id);book_flash('ok','Backup deleted.');}
 }catch(Throwable $e){book_flash('error',BOOK_CONFIG['app']['debug']?$e->getMessage():'Backup operation failed. Check storage permissions and PHP Zip support.');}
 header('Location: '.book_url('admin/backups.php'));exit;
}
$backups=$db->query('SELECT b.*,u.name created_by_name FROM book_backups b LEFT JOIN book_users u ON u.id=b.created_by ORDER BY b.created_at DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);$diskFree=@disk_free_space($backupDir);$diskTotal=@disk_total_space($backupDir);
book_render_header('Backup','admin-backup','Create downloadable database, private file and full platform data backups.');
?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/../includes/sidebar.php';?><section class="book-content"><div class="book-topbar"><div class="book-title"><h1>⧉ Backup</h1><p>Create database, private-book-file or combined backups. Backup files remain outside public web access.</p></div><a class="book-btn secondary" href="<?=book_url('admin/index.php')?>">Admin home</a></div><?php if($m=book_flash('ok')):?><div class="book-alert ok"><?=book_e($m)?></div><?php endif;?><?php if($m=book_flash('error')):?><div class="book-alert danger"><?=book_e($m)?></div><?php endif;?>
<div class="book-grid" style="margin-top:18px"><div class="book-card book-span-8"><h3>Create a backup</h3><p class="book-muted">Database creates a portable SQL dump. Files includes private books, covers, uploads and exports. Full combines both into a ZIP.</p><form method="post" class="book-actions" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='Creating backup…'"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="create"><select class="book-select" name="type" style="max-width:240px"><option value="database">Database SQL</option><option value="files">Private files ZIP</option><option value="full">Full data ZIP</option></select><button class="book-btn">Create now</button></form></div><div class="book-card book-span-4"><h3>Storage</h3><p><strong><?=book_e($backupDir)?></strong></p><p class="book-muted">Free <?=book_e($diskFree!==false?number_format($diskFree/1073741824,2).' GB':'Unknown')?> of <?=book_e($diskTotal!==false?number_format($diskTotal/1073741824,2).' GB':'Unknown')?>.</p><div class="book-alert warn">Backups do not include <code>.env</code> secrets. Store APP_KEY and database credentials separately.</div></div></div>
<div class="book-card" style="margin-top:18px"><h3>Backup history</h3><div class="book-table-wrap"><table class="book-table"><thead><tr><th>Created</th><th>Type</th><th>Status</th><th>Size</th><th>Checksum</th><th>Created by</th><th>Error</th><th>Actions</th></tr></thead><tbody><?php foreach($backups as $b):?><tr><td><?=book_e($b['created_at'])?></td><td><?=book_e($b['type'])?></td><td><span class="book-chip <?=$b['status']==='completed'?'ok':($b['status']==='failed'?'danger':'warn')?>"><?=book_e($b['status'])?></span></td><td><?=book_e($b['file_size']?number_format($b['file_size']/1048576,2).' MB':'—')?></td><td><code><?=book_e($b['checksum_sha256']?substr($b['checksum_sha256'],0,16).'…':'—')?></code></td><td><?=book_e($b['created_by_name']?:'System')?></td><td><small><?=book_e($b['error_message']?:'—')?></small></td><td><div class="book-actions"><?php if($b['status']==='completed'):?><a class="book-icon-btn" href="<?=book_url('admin/backups.php?download='.(int)$b['id'])?>">Download</a><?php endif;?><form method="post" onsubmit="return confirm('Delete this backup file and record?')"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$b['id']?>"><button class="book-icon-btn danger">Delete</button></form></div></td></tr><?php endforeach;if(!$backups):?><tr><td colspan="8" class="book-muted">No backup jobs have been run.</td></tr><?php endif;?></tbody></table></div></div></section></div></main><?php book_render_footer();?>
