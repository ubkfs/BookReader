<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_admin('subscriptions.view');
$db = book_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    book_require_admin('subscriptions.manage');
    book_verify_csrf();
    $action = (string)($_POST['action'] ?? 'update_plan');

    if ($action === 'update_plan') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        if ($id < 1 || $name === '') {
            book_flash('error', 'A valid plan and plan name are required.');
        } else {
            $db->prepare('UPDATE book_subscription_plans SET name=?,description=?,duration_days=?,trial_days=?,book_limit=?,offline_limit=?,family_profiles=?,grace_period_days=?,is_lifetime=?,is_active=?,sort_order=? WHERE id=?')->execute([
                $name,
                trim((string)($_POST['description'] ?? '')),
                ($_POST['duration_days'] ?? '') === '' ? null : max(0, (int)$_POST['duration_days']),
                max(0, (int)($_POST['trial_days'] ?? 0)),
                max(0, (int)($_POST['book_limit'] ?? 0)),
                max(0, (int)($_POST['offline_limit'] ?? 0)),
                max(1, (int)($_POST['family_profiles'] ?? 1)),
                max(0, (int)($_POST['grace_period_days'] ?? 0)),
                isset($_POST['is_lifetime']) ? 1 : 0,
                isset($_POST['is_active']) ? 1 : 0,
                max(0, (int)($_POST['sort_order'] ?? 0)),
                $id,
            ]);
            book_log('admin.plan.updated', 'subscription_plan', $id);
            book_flash('ok', 'Plan updated.');
        }
    }

    if ($action === 'save_price') {
        $planId = (int)($_POST['plan_id'] ?? 0);
        $priceId = (int)($_POST['price_id'] ?? 0);
        $country = strtoupper(trim((string)($_POST['country_code'] ?? '')));
        $currency = strtoupper(trim((string)($_POST['currency'] ?? '')));
        $amount = trim((string)($_POST['amount'] ?? ''));
        $compareAt = trim((string)($_POST['compare_at'] ?? ''));

        $planExists = $db->prepare('SELECT COUNT(*) FROM book_subscription_plans WHERE id=?');
        $planExists->execute([$planId]);
        if (!(int)$planExists->fetchColumn()) {
            book_flash('error', 'Plan not found.');
        } elseif ($country !== '' && !preg_match('/^[A-Z]{2}$/', $country)) {
            book_flash('error', 'Country code must be blank for a global price or contain two letters.');
        } elseif (!preg_match('/^[A-Z]{3}$/', $currency)) {
            book_flash('error', 'Currency must be a three-letter ISO code, such as USD or INR.');
        } elseif (!is_numeric($amount) || (float)$amount < 0) {
            book_flash('error', 'Enter a valid non-negative price.');
        } else {
            $amountMinor = book_money_to_minor($amount, $currency);
            $compareMinor = $compareAt !== '' && is_numeric($compareAt) ? book_money_to_minor($compareAt, $currency) : null;
            $countryValue = $country !== '' ? $country : null;
            $active = isset($_POST['is_active']) ? 1 : 0;
            $taxInclusive = isset($_POST['tax_inclusive']) ? 1 : 0;

            if ($priceId > 0) {
                $stmt = $db->prepare('UPDATE book_plan_prices SET country_code=?,currency=?,amount_minor=?,compare_at_minor=?,tax_inclusive=?,is_active=? WHERE id=? AND plan_id=?');
                $stmt->execute([$countryValue, $currency, $amountMinor, $compareMinor, $taxInclusive, $active, $priceId, $planId]);
            } else {
                $existing = $countryValue === null
                    ? $db->prepare('SELECT id FROM book_plan_prices WHERE plan_id=? AND country_code IS NULL AND currency=? LIMIT 1')
                    : $db->prepare('SELECT id FROM book_plan_prices WHERE plan_id=? AND country_code=? AND currency=? LIMIT 1');
                $countryValue === null ? $existing->execute([$planId, $currency]) : $existing->execute([$planId, $countryValue, $currency]);
                $existingId = (int)($existing->fetchColumn() ?: 0);
                if ($existingId) {
                    $db->prepare('UPDATE book_plan_prices SET amount_minor=?,compare_at_minor=?,tax_inclusive=?,is_active=? WHERE id=?')->execute([$amountMinor, $compareMinor, $taxInclusive, $active, $existingId]);
                    $priceId = $existingId;
                } else {
                    $db->prepare('INSERT INTO book_plan_prices (plan_id,country_code,currency,amount_minor,compare_at_minor,tax_inclusive,is_active) VALUES (?,?,?,?,?,?,?)')->execute([$planId, $countryValue, $currency, $amountMinor, $compareMinor, $taxInclusive, $active]);
                    $priceId = (int)$db->lastInsertId();
                }
            }
            book_log('admin.plan_price.saved', 'plan_price', $priceId, ['plan_id' => $planId, 'country' => $countryValue, 'currency' => $currency]);
            book_flash('ok', 'Country price saved.');
        }
    }

    header('Location: ' . book_url('admin/plans.php'));
    exit;
}

$plans = $db->query('SELECT * FROM book_subscription_plans ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
$priceRows = $db->query('SELECT * FROM book_plan_prices ORDER BY plan_id,country_code,currency')->fetchAll(PDO::FETCH_ASSOC);
$pricesByPlan = [];
foreach ($priceRows as $price) {
    $pricesByPlan[(int)$price['plan_id']][] = $price;
}

book_render_header('Subscription Plans', 'admin-plans');
?>
<main class="book-app" id="main-content"><div class="book-shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<section class="book-content">
  <div class="book-topbar"><div class="book-title"><h1>Subscription plans</h1><p>Configure entitlements and country-specific prices. A blank country creates the global fallback price.</p></div></div>
  <?php if ($message = book_flash('ok')): ?><div class="book-alert ok"><?= book_e($message) ?></div><?php endif; ?>
  <?php if ($message = book_flash('error')): ?><div class="book-alert danger"><?= book_e($message) ?></div><?php endif; ?>

  <div class="book-grid" style="margin-top:18px">
  <?php foreach ($plans as $plan): $planPrices = $pricesByPlan[(int)$plan['id']] ?? []; ?>
    <div class="book-card book-span-12">
      <form method="post" class="book-form">
        <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
        <input type="hidden" name="action" value="update_plan">
        <input type="hidden" name="id" value="<?= (int)$plan['id'] ?>">
        <div class="book-actions"><span class="book-chip <?= $plan['is_active'] ? 'ok' : 'danger' ?>"><?= $plan['is_active'] ? 'Active' : 'Hidden' ?></span><code><?= book_e((string)$plan['code']) ?></code></div>
        <div class="book-mini-grid">
          <div><label class="book-label">Name</label><input class="book-input" name="name" value="<?= book_e((string)$plan['name']) ?>" required></div>
          <div><label class="book-label">Sort order</label><input class="book-input" type="number" min="0" name="sort_order" value="<?= (int)$plan['sort_order'] ?>"></div>
        </div>
        <label class="book-label">Description</label><textarea class="book-textarea" name="description"><?= book_e((string)$plan['description']) ?></textarea>
        <div class="book-mini-grid">
          <div><label class="book-label">Duration days</label><input class="book-input" type="number" min="0" name="duration_days" value="<?= book_e((string)$plan['duration_days']) ?>"></div>
          <div><label class="book-label">Trial days</label><input class="book-input" type="number" min="0" name="trial_days" value="<?= (int)$plan['trial_days'] ?>"></div>
          <div><label class="book-label">Book limit</label><input class="book-input" type="number" min="0" name="book_limit" value="<?= (int)$plan['book_limit'] ?>"></div>
          <div><label class="book-label">Offline limit</label><input class="book-input" type="number" min="0" name="offline_limit" value="<?= (int)$plan['offline_limit'] ?>"></div>
          <div><label class="book-label">Family profiles</label><input class="book-input" type="number" min="1" name="family_profiles" value="<?= (int)$plan['family_profiles'] ?>"></div>
          <div><label class="book-label">Grace days</label><input class="book-input" type="number" min="0" name="grace_period_days" value="<?= (int)$plan['grace_period_days'] ?>"></div>
        </div>
        <div class="book-actions"><label><input type="checkbox" name="is_active" <?= $plan['is_active'] ? 'checked' : '' ?>> Active</label><label><input type="checkbox" name="is_lifetime" <?= $plan['is_lifetime'] ? 'checked' : '' ?>> Lifetime</label><button class="book-btn">Save plan</button></div>
      </form>

      <hr>
      <h3>Country pricing</h3>
      <div class="book-table-wrap"><table class="book-table"><thead><tr><th>Country</th><th>Currency</th><th>Price</th><th>Compare at</th><th>Tax</th><th>Status</th></tr></thead><tbody>
      <?php foreach ($planPrices as $price): ?><tr><td><?= book_e((string)($price['country_code'] ?: 'GLOBAL')) ?></td><td><?= book_e((string)$price['currency']) ?></td><td><?= book_e(book_format_money((int)$price['amount_minor'], (string)$price['currency'], false)) ?></td><td><?= $price['compare_at_minor'] !== null ? book_e(book_format_money((int)$price['compare_at_minor'], (string)$price['currency'], false)) : '—' ?></td><td><?= $price['tax_inclusive'] ? 'Inclusive' : 'Exclusive' ?></td><td><?= $price['is_active'] ? 'Active' : 'Inactive' ?></td></tr><?php endforeach; ?>
      <?php if (!$planPrices): ?><tr><td colspan="6" class="book-muted">No prices configured.</td></tr><?php endif; ?>
      </tbody></table></div>

      <form method="post" class="book-form" style="margin-top:18px">
        <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
        <input type="hidden" name="action" value="save_price">
        <input type="hidden" name="plan_id" value="<?= (int)$plan['id'] ?>">
        <div class="book-mini-grid">
          <div><label class="book-label">Existing price</label><select class="book-select" name="price_id"><option value="0">Add or upsert a price</option><?php foreach ($planPrices as $price): ?><option value="<?= (int)$price['id'] ?>"><?= book_e((string)($price['country_code'] ?: 'GLOBAL') . ' · ' . (string)$price['currency']) ?></option><?php endforeach; ?></select></div>
          <div><label class="book-label">Country code</label><input class="book-input" name="country_code" maxlength="2" pattern="[A-Za-z]{2}" placeholder="Blank = global"></div>
          <div><label class="book-label">Currency</label><input class="book-input" name="currency" maxlength="3" pattern="[A-Za-z]{3}" value="USD" required></div>
          <div><label class="book-label">Price</label><input class="book-input" type="number" name="amount" min="0" step="0.001" required></div>
          <div><label class="book-label">Compare-at price</label><input class="book-input" type="number" name="compare_at" min="0" step="0.001"></div>
        </div>
        <div class="book-actions"><label><input type="checkbox" name="tax_inclusive"> Tax inclusive</label><label><input type="checkbox" name="is_active" checked> Active</label><button class="book-btn secondary">Save price</button></div>
      </form>
    </div>
  <?php endforeach; ?>
  </div>
</section></div></main>
<?php book_render_footer(); ?>
