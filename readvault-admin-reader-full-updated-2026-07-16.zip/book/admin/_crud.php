<?php
declare(strict_types=1);

/** Shared, whitelisted CRUD helpers for the ReadVault administrator console. */

function admin_crud_policy(string $module): array {
    $base = [
        'create' => true,
        'edit' => true,
        'delete' => true,
        'where' => '',
        'params' => [],
        'readonly' => ['id','created_at','updated_at','uploaded_at','last_opened_at','completed_at','last_used_at','paid_at','issued_at','checked_at'],
        'hidden' => ['password_hash','pin_hash','client_secret_hash','raw_response'],
        'list' => [],
        'form' => [],
        'defaults' => [],
        'notice' => '',
    ];

    $overrides = [
        'books' => [
            'create'=>false,
            'delete'=>true,
            'list'=>['id','title','author','file_type','access_type','moderation_status','is_published','file_size','uploaded_at'],
            'form'=>['user_id','publisher_id','primary_author_id','category_id','title','slug','subtitle','author','category','description','isbn10','isbn13','language_code','publication_date','cover_path','drm_mode','total_pages','total_words','reading_status','access_type','requires_subscription','is_downloadable','is_scanned','is_published','moderation_status','price_minor','currency','seo_title','seo_description','tags_json'],
            'notice'=>'Use Upload Book to add a file. This screen manages catalog metadata, access, moderation, pricing and DRM settings.',
        ],
        'subscriptions' => [
            'delete'=>false,
            'list'=>['id','user_id','plan_id','status','starts_at','ends_at','trial_ends_at','grace_ends_at','auto_renew','payment_provider','created_at'],
            'form'=>['user_id','plan_id','status','starts_at','ends_at','trial_ends_at','grace_ends_at','cancelled_at','auto_renew','payment_provider','provider_customer_id','provider_subscription_id','next_plan_id'],
            'defaults'=>['starts_at'=>'__NOW__'],
            'notice'=>'Subscription changes affect access immediately. Records are retained instead of hard-deleted for billing and entitlement audit.',
        ],
        'trials' => [
            'delete'=>false,
            'where'=>'status = ?',
            'params'=>['trialing'],
            'list'=>['id','user_id','plan_id','status','starts_at','trial_ends_at','ends_at','created_at'],
            'form'=>['user_id','plan_id','status','starts_at','trial_ends_at','ends_at','grace_ends_at','auto_renew'],
            'defaults'=>['status'=>'trialing','starts_at'=>'__NOW__'],
            'notice'=>'This view only shows trialing subscriptions. A user can still be restricted to one trial by the existing trial_used_at check.',
        ],
        'reviews' => [
            'create'=>false,
            'list'=>['id','user_id','book_id','rating','title','status','helpful_count','created_at'],
            'form'=>['rating','title','body','status','helpful_count'],
        ],
        'reports' => ['create'=>false,'edit'=>false,'delete'=>false,'list'=>['id','user_id','action','entity_type','entity_id','ip_address','created_at']],
        'analytics' => ['create'=>false,'edit'=>false,'delete'=>false,'list'=>['id','user_id','profile_id','book_id','start_page','end_page','pages_read','duration_seconds','focus_seconds','device_type','started_at','ended_at']],
        'reading-statistics' => ['create'=>false,'edit'=>false,'delete'=>false,'list'=>['id','user_id','profile_id','book_id','pages_read','duration_seconds','focus_seconds','device_type','started_at','ended_at']],
        'activity' => ['create'=>false,'edit'=>false,'delete'=>false,'list'=>['id','user_id','action','entity_type','entity_id','ip_address','created_at']],
        'downloads' => [
            'create'=>false,'delete'=>false,
            'list'=>['id','user_id','book_id','device_id','download_type','bytes_transferred','expires_at','revoked_at','created_at'],
            'form'=>['expires_at','revoked_at'],
            'notice'=>'Set revoked_at to revoke an offline entitlement. Browser-cached bytes are removed when the client next synchronizes.',
        ],
        'invoices' => [
            'create'=>false,'delete'=>false,
            'list'=>['id','invoice_number','user_id','order_id','status','currency','total_minor','issued_at'],
            'form'=>['status','billing_details','pdf_path'],
            'notice'=>'Invoice totals are immutable accounting values. Only status, billing snapshot and generated PDF path can be corrected here.',
        ],
        'push' => ['create'=>false,'edit'=>false,'delete'=>true,'list'=>['id','user_id','device_id','endpoint','expires_at','created_at']],
        'notifications' => [
            'list'=>['id','user_id','channel','type','title','message','read_at','sent_at','created_at'],
            'form'=>['user_id','channel','type','title','message','action_url','data_json','read_at','sent_at'],
            'defaults'=>['channel'=>'in_app','type'=>'info'],
        ],
        'seo' => ['list'=>['id','entity_type','entity_id','route_key','locale','title','canonical_url','robots','updated_at']],
        'blogs' => ['list'=>['id','title','slug','author_user_id','status','published_at','updated_at'],'defaults'=>['author_user_id'=>'__CURRENT_USER__','status'=>'draft']],
        'advertisements' => ['list'=>['id','name','placement','creative_type','impressions','clicks','is_active','starts_at','ends_at']],
        'translation' => ['list'=>['id','locale','namespace','translation_key','translation_value','is_machine_translated','updated_at']],
        'taxes' => ['list'=>['id','country_code','region_code','name','rate','is_inclusive','is_active']],
        'challenges' => ['list'=>['id','title','target_type','target_value','starts_at','ends_at','visibility','is_active','created_by'],'defaults'=>['created_by'=>'__CURRENT_USER__','is_active'=>'1']],
        'referrals' => ['create'=>true,'list'=>['id','referrer_user_id','referred_user_id','code','status','qualified_at','created_at']],
        'gifts' => ['list'=>['id','purchaser_user_id','recipient_email','plan_id','gift_code','status','expires_at','redeemed_by','redeemed_at','created_at'],'defaults'=>['purchaser_user_id'=>'__CURRENT_USER__','gift_code'=>'__GIFT_CODE__','status'=>'pending']],
        'categories' => ['list'=>['id','parent_id','name','slug','is_active','sort_order']],
        'publishers' => ['list'=>['id','name','owner_user_id','verification_status','website_url','created_at']],
        'authors' => ['list'=>['id','name','owner_user_id','verification_status','website_url','created_at']],
        'genres' => ['list'=>['id','name','slug','description']],
        'collections' => ['list'=>['id','name','slug','is_featured','is_active','created_at']],
    ];
    return array_replace_recursive($base, $overrides[$module] ?? []);
}

function admin_table_columns(PDO $db, string $table): array {
    $rows = $db->query('DESCRIBE `'.$table.'`')->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($rows as $row) $out[(string)$row['Field']] = $row;
    return $out;
}

function admin_enum_options(string $type): array {
    if (!preg_match('/^enum\((.*)\)$/i', $type, $m)) return [];
    return array_map(static fn($v)=>str_replace("''", "'", trim($v, "'")), str_getcsv($m[1], ',', "'", "\\"));
}

function admin_is_bool(array $column): bool {
    return preg_match('/^tinyint\(1\)/i', (string)$column['Type']) === 1;
}

function admin_is_numeric_type(string $type): bool {
    return preg_match('/^(tinyint|smallint|mediumint|int|bigint|decimal|float|double)/i', $type) === 1;
}

function admin_is_textarea(string $name, string $type): bool {
    return str_contains(strtolower($type), 'text') || str_ends_with($name, '_json') || in_array($name, ['description','content','html_body','text_body','message','body','bio','schema_json','open_graph_json','billing_details','metadata'], true);
}

function admin_reference_config(string $field): ?array {
    $map = [
        'user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'owner_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'author_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'assigned_to'=>['book_users','id','CONCAT(name," <",email,">")','role IN ("support","admin","super_admin") AND deleted_at IS NULL'],
        'created_by'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'purchaser_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'redeemed_by'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'referrer_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'referred_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'linked_user_id'=>['book_users','id','CONCAT(name," <",email,">")','deleted_at IS NULL'],
        'plan_id'=>['book_subscription_plans','id','CONCAT(name," (",code,")")','1=1'],
        'next_plan_id'=>['book_subscription_plans','id','CONCAT(name," (",code,")")','1=1'],
        'book_id'=>['book_books','id','title','1=1'],
        'publisher_id'=>['book_publishers','id','name','1=1'],
        'primary_author_id'=>['book_author_profiles','id','name','1=1'],
        'category_id'=>['book_categories','id','name','1=1'],
        'parent_id'=>['book_categories','id','name','1=1'],
        'badge_id'=>['book_achievement_badges','id','name','1=1'],
        'order_id'=>['book_orders','id','order_number','1=1'],
        'coupon_id'=>['book_coupons','id','code','1=1'],
        'device_id'=>['book_user_devices','id','COALESCE(device_name,fingerprint)','1=1'],
        'profile_id'=>['book_family_profiles','id','name','1=1'],
        'family_account_id'=>['book_family_accounts','id','name','1=1'],
    ];
    return $map[$field] ?? null;
}

function admin_reference_options(PDO $db, string $field, mixed $current = null): array {
    $cfg = admin_reference_config($field);
    if (!$cfg) return [];
    [$table,$id,$label,$where] = $cfg;
    try {
        $sql = "SELECT `$id` AS id,$label AS label FROM `$table` WHERE $where ORDER BY label LIMIT 500";
        $rows = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        if ($current && !array_filter($rows, static fn($r)=>(string)$r['id']===(string)$current)) {
            $st=$db->prepare("SELECT `$id` AS id,$label AS label FROM `$table` WHERE `$id`=? LIMIT 1");$st->execute([$current]);if($row=$st->fetch(PDO::FETCH_ASSOC))$rows[]=$row;
        }
        return $rows;
    } catch (Throwable) { return []; }
}

function admin_default_value(string $value): mixed {
    return match ($value) {
        '__NOW__' => date('Y-m-d H:i:s'),
        '__CURRENT_USER__' => book_user_id(),
        '__GIFT_CODE__' => strtoupper(bin2hex(random_bytes(16))),
        default => $value,
    };
}

function admin_datetime_for_input(mixed $value): string {
    if (!$value) return '';
    $ts = strtotime((string)$value);
    return $ts ? date('Y-m-d\TH:i', $ts) : '';
}

function admin_normalize_value(string $field, array $column, mixed $raw): mixed {
    $type = strtolower((string)$column['Type']);
    if (is_array($raw)) $raw = json_encode(array_values($raw), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $raw = is_string($raw) ? trim($raw) : $raw;
    if ($raw === '' && strtoupper((string)$column['Null']) === 'YES') return null;
    if (admin_is_bool($column)) return in_array((string)$raw, ['1','true','on','yes'], true) ? 1 : 0;
    $enum = admin_enum_options((string)$column['Type']);
    if ($enum && !in_array((string)$raw, $enum, true)) throw new InvalidArgumentException('Invalid value for '.str_replace('_',' ',$field).'.');
    if (str_contains($type, 'json')) {
        if ($raw === '' || $raw === null) return null;
        json_decode((string)$raw, true, 512, JSON_THROW_ON_ERROR);
        return (string)$raw;
    }
    if (preg_match('/datetime|timestamp/i', $type)) {
        if ($raw === '' || $raw === null) return null;
        $ts = strtotime((string)$raw);
        if (!$ts) throw new InvalidArgumentException('Invalid date/time for '.str_replace('_',' ',$field).'.');
        return date('Y-m-d H:i:s', $ts);
    }
    if (preg_match('/^date\b/i', $type)) {
        if ($raw === '' || $raw === null) return null;
        $ts = strtotime((string)$raw);
        if (!$ts) throw new InvalidArgumentException('Invalid date for '.str_replace('_',' ',$field).'.');
        return date('Y-m-d', $ts);
    }
    if (admin_is_numeric_type($type)) {
        if ($raw === '' || $raw === null) return strtoupper((string)$column['Null']) === 'YES' ? null : 0;
        if (!is_numeric($raw)) throw new InvalidArgumentException('A numeric value is required for '.str_replace('_',' ',$field).'.');
        return str_contains($type, 'int') ? (int)$raw : (float)$raw;
    }
    if ($field === 'country_code' && $raw !== null) return strtoupper(substr((string)$raw,0,2));
    if ($field === 'currency' && $raw !== null) return strtoupper(substr((string)$raw,0,3));
    return $raw;
}

function admin_form_fields(array $columns, array $policy): array {
    if ($policy['form']) return array_values(array_filter($policy['form'], static fn($f)=>isset($columns[$f])));
    $fields=[];
    foreach($columns as $name=>$col){
        if(in_array($name,$policy['hidden'],true)||in_array($name,$policy['readonly'],true))continue;
        if(str_contains(strtolower((string)$col['Extra']),'auto_increment'))continue;
        $fields[]=$name;
    }
    return $fields;
}

function admin_list_fields(array $columns, array $policy): array {
    if ($policy['list']) return array_values(array_filter($policy['list'], static fn($f)=>isset($columns[$f])));
    $preferred=['id','name','title','email','code','status','type','provider','currency','amount_minor','total_minor','user_id','book_id','created_at','updated_at','starts_at','ends_at'];
    $fields=array_values(array_intersect($preferred,array_keys($columns)));
    return $fields ?: array_slice(array_keys($columns),0,8);
}

function admin_search_fields(array $columns): array {
    $out=[];
    foreach($columns as $name=>$col){
        $type=strtolower((string)$col['Type']);
        if(preg_match('/char|text|enum/i',$type) && !in_array($name,['password_hash','pin_hash','client_secret_hash','raw_response'],true))$out[]=$name;
    }
    return array_slice($out,0,12);
}

function admin_record_label(array $row): string {
    foreach(['name','title','email','code','ticket_number','invoice_number','gift_code','translation_key','action'] as $field){if(isset($row[$field])&&$row[$field]!=='')return (string)$row[$field];}
    return '#'.(string)($row['id']??'');
}

function admin_render_value(string $field, mixed $value): string {
    if ($value === null || $value === '') return '<span class="book-muted">—</span>';
    if (is_string($value) && strlen($value)>180) $value=mb_substr($value,0,177).'…';
    if (str_ends_with($field,'_size') || $field==='bytes_transferred') {
        $bytes=(int)$value;$units=['B','KB','MB','GB','TB'];$i=0;while($bytes>=1024&&$i<count($units)-1){$bytes/=1024;$i++;}return book_e(number_format((float)$bytes,$i?1:0).' '.$units[$i]);
    }
    if (in_array($field,['is_active','is_published','requires_subscription','is_downloadable','is_scanned','is_featured','is_inclusive','is_machine_translated','auto_renew'],true)) return '<span class="book-chip '.((int)$value?'ok':'warn').'">'.((int)$value?'Yes':'No').'</span>';
    if ($field==='status' || str_ends_with($field,'_status')) return '<span class="book-chip">'.book_e((string)$value).'</span>';
    return nl2br(book_e((string)$value));
}

function admin_render_field(PDO $db, string $field, array $column, mixed $value): string {
    $label=ucwords(str_replace('_',' ',$field));$type=strtolower((string)$column['Type']);$required=strtoupper((string)$column['Null'])==='NO' && $column['Default']===null && !str_contains(strtolower((string)$column['Extra']),'auto_increment');
    $requiredAttr=$required?' required':'';$id='field_'.preg_replace('/[^a-z0-9_]/i','_',$field);
    $help='';
    if(str_ends_with($field,'_json')||str_contains($type,'json'))$help='<small class="book-form-help">Valid JSON, for example <code>{"key":"value"}</code> or <code>["US","GB"]</code>.</small>';
    if(str_ends_with($field,'_minor'))$help='<small class="book-form-help">Enter the amount in the currency’s smallest unit (for example 999 = USD 9.99; 999 = JPY 999).</small>';
    $html='<div class="admin-field"><label class="book-label" for="'.book_e($id).'">'.book_e($label).($required?' *':'').'</label>';
    if(admin_is_bool($column)){
        $html.='<label class="toggle-row"><input type="hidden" name="fields['.book_e($field).']" value="0"><input id="'.book_e($id).'" type="checkbox" name="fields['.book_e($field).']" value="1" '.((int)$value?'checked':'').'> Enabled / yes</label>';
    }elseif($opts=admin_enum_options((string)$column['Type'])){
        $html.='<select class="book-select" id="'.book_e($id).'" name="fields['.book_e($field).']"'.$requiredAttr.'>';
        if(!$required)$html.='<option value="">— None —</option>';
        foreach($opts as $opt)$html.='<option value="'.book_e($opt).'" '.((string)$value===$opt?'selected':'').'>'.book_e(ucwords(str_replace('_',' ',$opt))).'</option>';
        $html.='</select>';
    }elseif($refs=admin_reference_options($db,$field,$value)){
        $html.='<select class="book-select" id="'.book_e($id).'" name="fields['.book_e($field).']"'.$requiredAttr.'><option value="">— None —</option>';
        foreach($refs as $row)$html.='<option value="'.(int)$row['id'].'" '.((string)$value===(string)$row['id']?'selected':'').'>'.book_e((string)$row['label']).'</option>';
        $html.='</select>';
    }elseif(admin_is_textarea($field,$type)){
        $html.='<textarea class="book-textarea admin-code-area" id="'.book_e($id).'" name="fields['.book_e($field).']"'.$requiredAttr.'>'.book_e((string)$value).'</textarea>';
    }elseif(preg_match('/datetime|timestamp/i',$type)){
        $html.='<input class="book-input" id="'.book_e($id).'" type="datetime-local" name="fields['.book_e($field).']" value="'.book_e(admin_datetime_for_input($value)).'"'.$requiredAttr.'>';
    }elseif(preg_match('/^date\b/i',$type)){
        $html.='<input class="book-input" id="'.book_e($id).'" type="date" name="fields['.book_e($field).']" value="'.book_e((string)$value).'"'.$requiredAttr.'>';
    }elseif(admin_is_numeric_type($type)){
        $step=str_contains($type,'decimal')||str_contains($type,'float')||str_contains($type,'double')?'0.0001':'1';
        $html.='<input class="book-input" id="'.book_e($id).'" type="number" step="'.$step.'" name="fields['.book_e($field).']" value="'.book_e((string)$value).'"'.$requiredAttr.'>';
    }else{
        $inputType=$field==='email'?'email':(str_contains($field,'url')?'url':'text');
        $html.='<input class="book-input" id="'.book_e($id).'" type="'.$inputType.'" name="fields['.book_e($field).']" value="'.book_e((string)$value).'"'.$requiredAttr.'>';
    }
    return $html.$help.'</div>';
}
