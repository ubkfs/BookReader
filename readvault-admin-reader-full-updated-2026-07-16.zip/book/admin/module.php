<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/_crud.php';
$db=book_db();
$modules=require __DIR__.'/_modules.php';
$key=(string)($_GET['module']??'');
if(!isset($modules[$key])){http_response_code(404);exit('Unknown module');}
book_require_admin($key.'.view');
[$title,$table,$description,$icon]=$modules[$key];
$table=book_table_name($table);
$special=[
    'users'=>'users.php',
    'payments'=>'payments.php',
    'coupons'=>'coupons.php',
    'support'=>'support-tickets.php',
    'email-templates'=>'email-templates.php',
    'roles'=>'roles.php',
    'backup'=>'backups.php',
    'family'=>'family.php',
    'api'=>'api-clients.php',
    'health'=>'system-health.php',
];
if(isset($special[$key])){header('Location: '.book_url('admin/'.$special[$key]));exit;}

$policy=admin_crud_policy($key);
try{$columns=admin_table_columns($db,$table);}catch(Throwable $e){$columns=[];$loadError=BOOK_CONFIG['app']['debug']?$e->getMessage():'This module table is not available. Run the latest database migration.';}
$formFields=$columns?admin_form_fields($columns,$policy):[];
$listFields=$columns?admin_list_fields($columns,$policy):[];
$pk=isset($columns['id'])?'id':array_key_first($columns);

if($_SERVER['REQUEST_METHOD']==='POST' && $columns){
    book_verify_csrf();
    $action=(string)($_POST['action']??'');
    $id=max(0,(int)($_POST['id']??0));
    try{
        if($action==='delete'){
            if(!book_can($key.'.delete'))throw new RuntimeException('You do not have permission to delete records in this module.');
            if(!$policy['delete'])throw new RuntimeException('Deletion is disabled for this module.');
            if(!$id)throw new RuntimeException('Invalid record.');
            $st=$db->prepare('DELETE FROM `'.$table.'` WHERE `'.$pk.'`=? LIMIT 1');$st->execute([$id]);
            book_log('admin.'.$key.'.deleted',$key,$id);
            book_flash('ok',$title.' record deleted.');
        }elseif(in_array($action,['create','update'],true)){
            if(!book_can($key.'.manage'))throw new RuntimeException('You do not have permission to change records in this module.');
            if($action==='create'&&!$policy['create'])throw new RuntimeException('Creating records is disabled for this module.');
            if($action==='update'&&!$policy['edit'])throw new RuntimeException('Editing records is disabled for this module.');
            $posted=(array)($_POST['fields']??[]);$data=[];
            foreach($formFields as $field){
                if(!isset($columns[$field]))continue;
                $raw=array_key_exists($field,$posted)?$posted[$field]:null;
                if($action==='create' && ($raw===null||$raw==='') && array_key_exists($field,$policy['defaults']))$raw=admin_default_value((string)$policy['defaults'][$field]);
                if($field==='slug' && trim((string)$raw)===''){
                    $source=(string)($posted['title']??$posted['name']??'');
                    $raw=strtolower(trim(preg_replace('/[^a-z0-9]+/i','-',$source),'-'));
                }
                if($field==='code' && trim((string)$raw)==='' && $key==='referrals')$raw='REF-'.strtoupper(bin2hex(random_bytes(4)));
                if($field==='gift_code' && trim((string)$raw)==='')$raw=strtoupper(bin2hex(random_bytes(16)));
                $data[$field]=admin_normalize_value($field,$columns[$field],$raw);
            }
            if(!$data)throw new RuntimeException('No editable fields were submitted.');
            if($action==='create'){
                $names=array_keys($data);$sql='INSERT INTO `'.$table.'` (`'.implode('`,`',$names).'`) VALUES ('.implode(',',array_fill(0,count($names),'?')).')';
                $db->prepare($sql)->execute(array_values($data));$id=(int)$db->lastInsertId();
                book_log('admin.'.$key.'.created',$key,$id);
                book_flash('ok',$title.' record created.');
            }else{
                if(!$id)throw new RuntimeException('Invalid record.');
                $sets=array_map(static fn($f)=>'`'.$f.'`=?',array_keys($data));
                $db->prepare('UPDATE `'.$table.'` SET '.implode(',',$sets).' WHERE `'.$pk.'`=? LIMIT 1')->execute([...array_values($data),$id]);
                book_log('admin.'.$key.'.updated',$key,$id);
                book_flash('ok',$title.' record updated.');
            }
        }
    }catch(Throwable $e){
        $msg=BOOK_CONFIG['app']['debug']?$e->getMessage():'The change could not be saved. Check required values and linked records.';
        if(str_contains(strtolower($e->getMessage()),'foreign key'))$msg='This record is still referenced elsewhere and cannot be deleted.';
        if(str_contains(strtolower($e->getMessage()),'duplicate'))$msg='A record with the same unique value already exists.';
        book_flash('error',$msg);
    }
    header('Location: '.book_url('admin/module.php?module='.rawurlencode($key)));exit;
}

$mode=(string)($_GET['action']??'list');
if(in_array($mode,['create','edit'],true)&&!book_can($key.'.manage')){http_response_code(403);exit('Access denied.');}
$record=null;$recordId=max(0,(int)($_GET['id']??0));
if($columns && in_array($mode,['view','edit'],true) && $recordId){
    $st=$db->prepare('SELECT * FROM `'.$table.'` WHERE `'.$pk.'`=? LIMIT 1');$st->execute([$recordId]);$record=$st->fetch(PDO::FETCH_ASSOC)?:null;
    if(!$record){http_response_code(404);$loadError='Record not found.';}
}

$q=trim((string)($_GET['q']??''));$page=max(1,(int)($_GET['page']??1));$perPage=30;$offset=($page-1)*$perPage;$rows=[];$count=0;
if($columns && $mode==='list'){
    $where=[];$params=[];
    if($policy['where']){$where[]='('.$policy['where'].')';$params=array_merge($params,$policy['params']);}
    if($q!==''){
        $search=admin_search_fields($columns);if($search){$where[]='('.implode(' OR ',array_map(static fn($f)=>'`'.$f.'` LIKE ?',$search)).')';foreach($search as $_)$params[]='%'.$q.'%';}
    }
    $whereSql=$where?' WHERE '.implode(' AND ',$where):'';
    $st=$db->prepare('SELECT COUNT(*) FROM `'.$table.'`'.$whereSql);$st->execute($params);$count=(int)$st->fetchColumn();
    $order=isset($columns['created_at'])?'created_at':(isset($columns['updated_at'])?'updated_at':$pk);
    $sql='SELECT `'.implode('`,`',$listFields).'` FROM `'.$table.'`'.$whereSql.' ORDER BY `'.$order.'` DESC LIMIT '.$perPage.' OFFSET '.$offset;
    $st=$db->prepare($sql);$st->execute($params);$rows=$st->fetchAll(PDO::FETCH_ASSOC);
}
$totalPages=max(1,(int)ceil($count/$perPage));

book_render_header($title,'admin-'.$key,$description);
?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/../includes/sidebar.php';?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1><?=$icon?> <?=book_e($title)?></h1><p><?=book_e($description)?></p></div><div class="book-actions"><a class="book-btn secondary" href="<?=book_url('admin/index.php')?>">Admin home</a><?php if($mode!=='list'):?><a class="book-btn secondary" href="<?=book_url('admin/module.php?module='.rawurlencode($key))?>">Back to list</a><?php endif;?><?php if($mode==='list'&&$policy['create']&&book_can($key.'.manage')):?><a class="book-btn" href="<?=book_url('admin/module.php?module='.rawurlencode($key).'&action=create')?>">Add new</a><?php elseif($key==='books'):?><a class="book-btn" href="<?=book_url('upload.php')?>">Upload book</a><?php endif;?></div></div>
<?php if($m=book_flash('ok')):?><div class="book-alert ok"><?=book_e($m)?></div><?php endif;?><?php if($m=book_flash('error')):?><div class="book-alert danger"><?=book_e($m)?></div><?php endif;?>
<?php if(!empty($policy['notice'])):?><div class="book-alert" style="margin-top:14px"><?=book_e($policy['notice'])?></div><?php endif;?>
<?php if(isset($loadError)):?><div class="book-alert danger" style="margin-top:18px"><?=book_e($loadError)?></div>
<?php elseif($mode==='create' || ($mode==='edit'&&$record)): $values=$record?:[];foreach($policy['defaults'] as $field=>$default){if(!array_key_exists($field,$values))$values[$field]=admin_default_value((string)$default);}?>
<form method="post" class="book-card book-form admin-editor" style="margin-top:18px"><input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>"><input type="hidden" name="action" value="<?=$mode==='create'?'create':'update'?>"><?php if($record):?><input type="hidden" name="id" value="<?=(int)$record[$pk]?>"><?php endif;?><div><h3><?=$mode==='create'?'Add '.$title:'Edit '.book_e(admin_record_label($record))?></h3><p class="book-muted">Fields marked with * are required. Changes are written to the activity log.</p></div><div class="admin-form-grid"><?php foreach($formFields as $field)echo admin_render_field($db,$field,$columns[$field],$values[$field]??null);?></div><div class="book-actions"><button class="book-btn">Save changes</button><a class="book-btn secondary" href="<?=book_url('admin/module.php?module='.rawurlencode($key))?>">Cancel</a></div></form>
<?php elseif($mode==='view'&&$record):?>
<div class="book-card" style="margin-top:18px"><div class="book-actions" style="justify-content:space-between"><div><h3><?=book_e(admin_record_label($record))?></h3><p class="book-muted">Complete record #<?=book_e($record[$pk])?></p></div><div class="book-actions"><?php if($policy['edit']&&book_can($key.'.manage')):?><a class="book-btn small" href="<?=book_url('admin/module.php?module='.rawurlencode($key).'&action=edit&id='.(int)$record[$pk])?>">Edit</a><?php endif;?><?php if($policy['delete']&&book_can($key.'.delete')):?><form method="post" onsubmit="return confirm('Delete this record permanently? This cannot be undone.')"><input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$record[$pk]?>"><button class="book-btn small danger">Delete</button></form><?php endif;?></div></div><div class="admin-detail-grid"><?php foreach($record as $field=>$value):?><div><small class="book-muted"><?=book_e(ucwords(str_replace('_',' ',$field)))?></small><div><?=admin_render_value($field,$value)?></div></div><?php endforeach;?></div></div>
<?php else:?>
<div class="book-card" style="margin-top:18px"><div class="admin-list-head"><form method="get" class="book-actions"><input type="hidden" name="module" value="<?=book_e($key)?>"><input class="book-input admin-search" name="q" value="<?=book_e($q)?>" placeholder="Search <?=book_e(strtolower($title))?>"><button class="book-btn secondary">Search</button><?php if($q!==''):?><a class="book-btn secondary" href="<?=book_url('admin/module.php?module='.rawurlencode($key))?>">Clear</a><?php endif;?></form><span class="book-pill"><?=number_format($count)?> records</span></div><div class="book-table-wrap"><table class="book-table"><thead><tr><?php foreach($listFields as $field):?><th><?=book_e(str_replace('_',' ',$field))?></th><?php endforeach;?><th>Actions</th></tr></thead><tbody><?php foreach($rows as $row):?><tr><?php foreach($listFields as $field):?><td><?=admin_render_value($field,$row[$field]??null)?></td><?php endforeach;?><td><div class="book-actions"><a class="book-icon-btn" href="<?=book_url('admin/module.php?module='.rawurlencode($key).'&action=view&id='.(int)$row[$pk])?>">View</a><?php if($policy['edit']&&book_can($key.'.manage')):?><a class="book-icon-btn" href="<?=book_url('admin/module.php?module='.rawurlencode($key).'&action=edit&id='.(int)$row[$pk])?>">Edit</a><?php endif;?><?php if($policy['delete']&&book_can($key.'.delete')):?><form method="post" onsubmit="return confirm('Delete this record permanently?')"><input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$row[$pk]?>"><button class="book-icon-btn danger">Delete</button></form><?php endif;?></div></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="<?=count($listFields)+1?>" class="book-muted">No records found.</td></tr><?php endif;?></tbody></table></div><?php if($totalPages>1):?><div class="admin-pagination"><?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++):?><a class="book-btn small <?=$p===$page?'':'secondary'?>" href="<?=book_url('admin/module.php?module='.rawurlencode($key).'&q='.rawurlencode($q).'&page='.$p)?>"><?=$p?></a><?php endfor;?><span class="book-muted">Page <?=$page?> of <?=$totalPages?></span></div><?php endif;?></div>
<?php endif;?></section></div></main><?php book_render_footer();?>
