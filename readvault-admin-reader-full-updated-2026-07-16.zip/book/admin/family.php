<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
book_require_admin('family.view');
$db=book_db();

$resolveLinkedUser = static function(PDO $db, int $linkedUserId, int $profileId = 0, int $ownerId = 0): ?int {
    if ($linkedUserId <= 0) return null;
    $st=$db->prepare('SELECT id FROM book_users WHERE id=? AND deleted_at IS NULL');
    $st->execute([$linkedUserId]);
    $linked=(int)$st->fetchColumn();
    if(!$linked) throw new RuntimeException('The linked user account does not exist or is deleted.');
    if($ownerId && $linked===$ownerId) throw new RuntimeException('The household owner does not need a linked member profile.');
    $st=$db->prepare('SELECT COUNT(*) FROM book_family_profiles WHERE linked_user_id=? AND id<>?');
    $st->execute([$linked,$profileId]);
    if((int)$st->fetchColumn()>0) throw new RuntimeException('That user is already linked to another family profile.');
    return $linked;
};

if($_SERVER['REQUEST_METHOD']==='POST'){book_require_admin('family.manage');
    book_verify_csrf();
    $action=(string)($_POST['action']??'');
    $id=max(0,(int)($_POST['id']??0));
    try{
        if($action==='create_account'){
            $ownerId=max(1,(int)($_POST['owner_user_id']??0));
            $name=trim((string)($_POST['name']??''));
            $max=max(1,min(100,(int)($_POST['max_profiles']??1)));
            if($name==='') throw new RuntimeException('Household name is required.');
            $db->prepare('INSERT INTO book_family_accounts(owner_user_id,name,max_profiles) VALUES(?,?,?)')->execute([$ownerId,$name,$max]);
            $id=(int)$db->lastInsertId();
            book_log('admin.family.created','family_account',$id,['owner_user_id'=>$ownerId]);
            book_flash('ok','Family household created.');
        }elseif($action==='update_account'){
            $name=trim((string)($_POST['name']??''));
            if($name==='') throw new RuntimeException('Household name is required.');
            $db->prepare('UPDATE book_family_accounts SET name=?,max_profiles=? WHERE id=?')->execute([$name,max(1,min(100,(int)$_POST['max_profiles'])),$id]);
            book_log('admin.family.updated','family_account',$id);
            book_flash('ok','Family account updated.');
        }elseif(in_array($action,['add_profile','update_profile'],true)){
            $familyId=max(1,(int)($_POST['family_account_id']??$id));
            $profileId=$action==='update_profile'?max(1,(int)($_POST['profile_id']??0)):0;
            $st=$db->prepare('SELECT owner_user_id,max_profiles FROM book_family_accounts WHERE id=?');$st->execute([$familyId]);$family=$st->fetch(PDO::FETCH_ASSOC);
            if(!$family) throw new RuntimeException('Family household not found.');
            if($action==='add_profile'){
                $st=$db->prepare('SELECT COUNT(*) FROM book_family_profiles WHERE family_account_id=?');$st->execute([$familyId]);
                if((int)$st->fetchColumn()>=(int)$family['max_profiles']) throw new RuntimeException('This household has reached its profile limit.');
            }
            $name=trim((string)($_POST['name']??''));if($name==='')throw new RuntimeException('Profile name is required.');
            $linked=$resolveLinkedUser($db,(int)($_POST['linked_user_id']??0),$profileId,(int)$family['owner_user_id']);
            $child=isset($_POST['is_child'])?1:0;
            $rating=trim((string)($_POST['content_rating']??''))?:null;
            $pin=trim((string)($_POST['pin']??''));
            if($action==='add_profile'){
                $db->prepare('INSERT INTO book_family_profiles(family_account_id,linked_user_id,name,is_child,content_rating,pin_hash) VALUES(?,?,?,?,?,?)')->execute([$familyId,$linked,$name,$child,$rating,$pin!==''?password_hash($pin,PASSWORD_DEFAULT):null]);
                $profileId=(int)$db->lastInsertId();
                book_log('admin.family_profile.created','family_profile',$profileId,['family_account_id'=>$familyId]);
                book_flash('ok','Family profile added.');
            }else{
                $sql='UPDATE book_family_profiles SET linked_user_id=?,name=?,is_child=?,content_rating=?'.($pin!==''?',pin_hash=?':'').' WHERE id=? AND family_account_id=?';
                $params=[$linked,$name,$child,$rating];if($pin!=='')$params[]=password_hash($pin,PASSWORD_DEFAULT);$params[]=$profileId;$params[]=$familyId;
                $db->prepare($sql)->execute($params);
                book_log('admin.family_profile.updated','family_profile',$profileId);
                book_flash('ok','Family profile updated.');
            }
            $id=$familyId;
        }elseif($action==='delete_profile'){
            $pid=(int)$_POST['profile_id'];
            $st=$db->prepare('SELECT family_account_id FROM book_family_profiles WHERE id=?');$st->execute([$pid]);$id=(int)$st->fetchColumn();
            $db->prepare('DELETE FROM book_family_profiles WHERE id=?')->execute([$pid]);
            book_log('admin.family_profile.deleted','family_profile',$pid);book_flash('ok','Profile deleted.');
        }elseif($action==='delete_account'){
            $db->prepare('DELETE FROM book_family_accounts WHERE id=?')->execute([$id]);
            book_log('admin.family.deleted','family_account',$id);book_flash('ok','Family account and profiles deleted.');$id=0;
        }
    }catch(Throwable $e){
        $message=BOOK_CONFIG['app']['debug']?$e->getMessage():'Family action failed.';
        if(str_contains(strtolower($e->getMessage()),'duplicate'))$message='That owner already has a family household.';
        book_flash('error',$message);
    }
    header('Location: '.book_url('admin/family.php'.($id?'?id='.$id:'')));exit;
}

$accounts=$db->query('SELECT f.*,u.name owner_name,u.email owner_email,
 (SELECT p.name FROM book_subscriptions s JOIN book_subscription_plans p ON p.id=s.plan_id WHERE s.user_id=f.owner_user_id AND s.status IN("active","trialing","grace") ORDER BY s.id DESC LIMIT 1) plan_name,
 (SELECT COUNT(*) FROM book_family_profiles fp WHERE fp.family_account_id=f.id) profile_count
 FROM book_family_accounts f JOIN book_users u ON u.id=f.owner_user_id ORDER BY f.created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
$id=(int)($_GET['id']??($accounts[0]['id']??0));$account=null;$profiles=[];
foreach($accounts as $a)if((int)$a['id']===$id)$account=$a;
if($account){$st=$db->prepare('SELECT fp.*,u.name linked_name,u.email linked_email FROM book_family_profiles fp LEFT JOIN book_users u ON u.id=fp.linked_user_id WHERE fp.family_account_id=? ORDER BY fp.created_at');$st->execute([$id]);$profiles=$st->fetchAll(PDO::FETCH_ASSOC);}
$users=$db->query('SELECT id,name,email FROM book_users WHERE deleted_at IS NULL ORDER BY name LIMIT 1000')->fetchAll(PDO::FETCH_ASSOC);
book_render_header('Family Sharing','admin-family','Manage subscription households, profile limits, child profiles and linked users.');
?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/../includes/sidebar.php';?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>♟ Family sharing</h1><p>Inspect household owners, subscription limits, child controls and linked member accounts.</p></div><a class="book-btn secondary" href="<?=book_url('admin/index.php')?>">Admin home</a></div>
<?php if($m=book_flash('ok')):?><div class="book-alert ok"><?=book_e($m)?></div><?php endif;?><?php if($m=book_flash('error')):?><div class="book-alert danger"><?=book_e($m)?></div><?php endif;?>
<div class="book-alert" style="margin-top:18px"><strong>How family sharing works:</strong> a household owner pays for the subscription. Each linked profile uses a separate registered ReadVault account and inherits the owner’s active entitlement, while progress, notes, highlights and devices remain separate. Billing, expiry and limits stay with the owner.</div>
<div class="book-grid" style="margin-top:18px">
  <div class="book-card book-span-4"><h3>Households</h3><?php foreach($accounts as $a):?><a class="role-list-item <?=$id===(int)$a['id']?'active':''?>" href="<?=book_url('admin/family.php?id='.(int)$a['id'])?>"><span><strong><?=book_e($a['name'])?></strong><small><?=book_e($a['owner_name'].' · '.$a['owner_email'])?></small></span><span><?=(int)$a['profile_count']?> / <?=(int)$a['max_profiles']?></span></a><?php endforeach;if(!$accounts):?><p class="book-muted">No family accounts.</p><?php endif;?><hr><details><summary class="book-btn small">Add household</summary><form method="post" class="book-form" style="margin-top:14px"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="create_account"><label class="book-label">Owner account</label><select class="book-select" name="owner_user_id" required><option value="">Select owner</option><?php foreach($users as $u):?><option value="<?=(int)$u['id']?>"><?=book_e($u['name'].' <'.$u['email'].'>')?></option><?php endforeach;?></select><label class="book-label">Household name</label><input class="book-input" name="name" required><label class="book-label">Profile limit</label><input class="book-input" type="number" min="1" max="100" name="max_profiles" value="5"><button class="book-btn">Create household</button></form></details></div>
  <div class="book-card book-span-8"><?php if($account):?>
    <form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="update_account"><input type="hidden" name="id" value="<?=(int)$account['id']?>"><h2><?=book_e($account['name'])?></h2><p><?=book_e($account['owner_name'])?> · <?=book_e($account['owner_email'])?> · <?=book_e($account['plan_name']?:'No active paid plan')?></p><div class="book-mini-grid"><div><label class="book-label">Household name</label><input class="book-input" name="name" value="<?=book_e($account['name'])?>" required></div><div><label class="book-label">Maximum profiles</label><input class="book-input" type="number" min="1" max="100" name="max_profiles" value="<?=(int)$account['max_profiles']?>"></div></div><button class="book-btn small">Save account</button></form>
    <hr><h3>Profiles</h3><div class="admin-module-grid"><?php foreach($profiles as $p):?><article class="book-card family-profile-card" style="box-shadow:none"><span class="admin-module-icon"><?=$p['is_child']?'🧒':'👤'?></span><h3><?=book_e($p['name'])?></h3><p class="book-muted"><?=$p['is_child']?'Child profile':'Standard profile'?><?= $p['content_rating']?' · '.book_e($p['content_rating']):'' ?><br><?=book_e($p['linked_name']?:'Not linked to a login')?><?= $p['linked_email']?' · '.book_e($p['linked_email']):'' ?></p><details><summary class="book-icon-btn">Edit</summary><form method="post" class="book-form" style="margin-top:12px"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="update_profile"><input type="hidden" name="family_account_id" value="<?=(int)$account['id']?>"><input type="hidden" name="profile_id" value="<?=(int)$p['id']?>"><input class="book-input" name="name" value="<?=book_e($p['name'])?>" required><select class="book-select" name="linked_user_id"><option value="">No linked login</option><?php foreach($users as $u):?><option value="<?=(int)$u['id']?>" <?=(int)$p['linked_user_id']===(int)$u['id']?'selected':''?>><?=book_e($u['name'].' <'.$u['email'].'>')?></option><?php endforeach;?></select><input class="book-input" name="content_rating" value="<?=book_e($p['content_rating']??'')?>" placeholder="Content rating"><input class="book-input" type="password" name="pin" inputmode="numeric" placeholder="New PIN (blank keeps current)"><label><input type="checkbox" name="is_child" <?=$p['is_child']?'checked':''?>> Child profile</label><button class="book-btn small">Save profile</button></form></details><form method="post" onsubmit="return confirm('Delete this profile?')"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="delete_profile"><input type="hidden" name="profile_id" value="<?=(int)$p['id']?>"><button class="book-icon-btn danger">Delete</button></form></article><?php endforeach;if(!$profiles):?><p class="book-muted">No profiles yet.</p><?php endif;?></div>
    <hr><form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="add_profile"><input type="hidden" name="family_account_id" value="<?=(int)$account['id']?>"><h3>Add profile</h3><div class="admin-form-grid"><div><label class="book-label">Name</label><input class="book-input" name="name" required></div><div><label class="book-label">Linked user</label><select class="book-select" name="linked_user_id"><option value="">None</option><?php foreach($users as $u):?><option value="<?=(int)$u['id']?>"><?=book_e($u['name'].' <'.$u['email'].'>')?></option><?php endforeach;?></select></div><div><label class="book-label">Content rating</label><input class="book-input" name="content_rating" placeholder="All, Teen, Kids"></div><div><label class="book-label">Optional PIN</label><input class="book-input" type="password" name="pin" inputmode="numeric"></div></div><label><input type="checkbox" name="is_child"> Child profile</label><button class="book-btn">Add profile</button></form>
    <form method="post" style="margin-top:18px" onsubmit="return confirm('Delete this family account and all profiles?')"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="delete_account"><input type="hidden" name="id" value="<?=(int)$account['id']?>"><button class="book-btn danger">Delete household</button></form>
  <?php else:?><p class="book-muted">No household selected. Add one from the left panel.</p><?php endif;?></div>
</div></section></div></main><?php book_render_footer();?>
