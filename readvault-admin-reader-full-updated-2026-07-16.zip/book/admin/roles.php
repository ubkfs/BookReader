<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
book_require_admin('roles.view');
$db=book_db();
$modules=require __DIR__.'/_modules.php';
$extraModules=[
    'settings'=>['Application Settings'],
    'feature-flags'=>['Feature Flags'],
];

function rv_seed_permissions(PDO $db,array $modules,array $extraModules=[]): void {
    $st=$db->prepare('INSERT INTO book_permissions(code,module,description) VALUES(?,?,?) ON DUPLICATE KEY UPDATE module=VALUES(module),description=VALUES(description)');
    foreach(array_merge($modules,$extraModules) as $key=>$m){
        $label=(string)($m[0]??ucwords(str_replace('-',' ',$key)));
        foreach(['view'=>'View records','manage'=>'Create and edit records','delete'=>'Delete records'] as $action=>$desc){
            $st->execute([$key.'.'.$action,$key,$desc.' in '.$label]);
        }
    }
}
rv_seed_permissions($db,$modules,$extraModules);

if($_SERVER['REQUEST_METHOD']==='POST'){
    book_require_admin('roles.manage');
    book_verify_csrf();
    $action=(string)($_POST['action']??'');
    $id=(int)($_POST['id']??0);
    try{
        if($action==='create'){
            $code=preg_replace('/[^a-z0-9_-]/','',strtolower(trim((string)($_POST['code']??''))))?:'';
            $name=trim((string)($_POST['name']??''));
            if($code===''||$name==='')throw new RuntimeException('Role code and name are required.');
            $db->prepare('INSERT INTO book_roles(code,name,description,is_system) VALUES(?,?,?,0)')->execute([$code,$name,trim((string)($_POST['description']??''))?:null]);
            $id=(int)$db->lastInsertId();
            book_log('admin.role.created','role',$id);
            book_flash('ok','Custom role created. Assign permissions below.');
        }elseif($action==='save'){
            $st=$db->prepare('SELECT code FROM book_roles WHERE id=?');$st->execute([$id]);$code=(string)$st->fetchColumn();
            if($code==='')throw new RuntimeException('Role not found.');
            $db->beginTransaction();
            $db->prepare('UPDATE book_roles SET name=?,description=? WHERE id=?')->execute([trim((string)($_POST['name']??'')),trim((string)($_POST['description']??''))?:null,$id]);
            $db->prepare('DELETE FROM book_role_permissions WHERE role_id=?')->execute([$id]);
            if($code!=='super_admin'){
                $ins=$db->prepare('INSERT INTO book_role_permissions(role_id,permission_id) VALUES(?,?)');
                foreach(array_unique(array_map('intval',(array)($_POST['permissions']??[]))) as $pid){if($pid>0)$ins->execute([$id,$pid]);}
            }
            $db->commit();
            book_log('admin.role.updated','role',$id);
            book_flash('ok',$code==='super_admin'?'Super Administrator keeps unrestricted access. Role details saved.':'Role and permissions saved.');
        }elseif($action==='delete'){
            $st=$db->prepare('SELECT is_system,code FROM book_roles WHERE id=?');$st->execute([$id]);$r=$st->fetch(PDO::FETCH_ASSOC);
            if(!$r||$r['is_system'])throw new RuntimeException('System roles cannot be deleted.');
            $used=$db->prepare('SELECT COUNT(*) FROM book_users WHERE role_id=? OR (role_id IS NULL AND role=?)');$used->execute([$id,$r['code']]);
            if((int)$used->fetchColumn()>0)throw new RuntimeException('Move users to another permission role before deleting this role.');
            $db->prepare('DELETE FROM book_roles WHERE id=?')->execute([$id]);
            book_log('admin.role.deleted','role',$id);
            book_flash('ok','Role deleted.');
            $id=0;
        }
    }catch(Throwable $e){
        if($db->inTransaction())$db->rollBack();
        book_flash('error',BOOK_CONFIG['app']['debug']?$e->getMessage():'Role action failed.');
    }
    header('Location: '.book_url('admin/roles.php'.($id?'?id='.$id:'')));exit;
}

$roles=$db->query('SELECT r.*,(SELECT COUNT(*) FROM book_role_permissions rp WHERE rp.role_id=r.id) permission_count,(SELECT COUNT(*) FROM book_users u WHERE u.role_id=r.id OR (u.role_id IS NULL AND u.role=r.code)) user_count FROM book_roles r ORDER BY is_system DESC,name')->fetchAll(PDO::FETCH_ASSOC);
$permissions=$db->query('SELECT * FROM book_permissions ORDER BY module,code')->fetchAll(PDO::FETCH_ASSOC);
$selectedId=(int)($_GET['id']??($roles[0]['id']??0));
$selected=null;$granted=[];
foreach($roles as $r)if((int)$r['id']===$selectedId)$selected=$r;
if($selected){$st=$db->prepare('SELECT permission_id FROM book_role_permissions WHERE role_id=?');$st->execute([$selectedId]);$granted=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));}
$canManage=book_can('roles.manage');
book_render_header('Roles & Permissions','admin-roles','Manage role definitions and least-privilege permission assignments.');
?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/../includes/sidebar.php';?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>🔐 Roles & permissions</h1><p>Assign a permission role to a staff account from Users. The checks below are enforced on admin routes and actions.</p></div><a class="book-btn secondary" href="<?=book_url('admin/index.php')?>">Admin home</a></div>
<?php if($m=book_flash('ok')):?><div class="book-alert ok"><?=book_e($m)?></div><?php endif;?><?php if($m=book_flash('error')):?><div class="book-alert danger"><?=book_e($m)?></div><?php endif;?>
<div class="book-alert" style="margin-top:18px"><strong>How access works:</strong> <code>view</code> opens a module, <code>manage</code> allows create/edit actions, and <code>delete</code> allows permanent deletion. Super Administrator is always unrestricted. Existing Admin accounts remain unrestricted until a permission role is assigned.</div>
<div class="book-grid" style="margin-top:18px">
<div class="book-card book-span-4"><h3>Roles</h3>
<?php foreach($roles as $r):?><a class="role-list-item <?=$selectedId===(int)$r['id']?'active':''?>" href="<?=book_url('admin/roles.php?id='.(int)$r['id'])?>"><span><strong><?=book_e($r['name'])?></strong><small><?=book_e($r['code'])?></small></span><span><?=(int)$r['user_count']?> users<br><?=(int)$r['permission_count']?> permissions</span></a><?php endforeach;?>
<?php if($canManage):?><hr><form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="create"><h4>Create custom role</h4><input class="book-input" name="code" placeholder="content_editor" required><input class="book-input" name="name" placeholder="Content Editor" required><textarea class="book-textarea" name="description" placeholder="Role purpose"></textarea><button class="book-btn">Create role</button></form><?php endif;?>
</div>
<div class="book-card book-span-8"><?php if($selected):?>
<form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)$selected['id']?>">
<div class="admin-profile-head"><div><h2><?=book_e($selected['name'])?></h2><code><?=book_e($selected['code'])?></code></div><span class="book-chip <?=$selected['is_system']?'ok':'warn'?>"><?=$selected['is_system']?'System role':'Custom role'?></span></div>
<label class="book-label">Display name</label><input class="book-input" name="name" value="<?=book_e($selected['name'])?>" required <?=$canManage?'':'disabled'?>>
<label class="book-label">Description</label><textarea class="book-textarea" name="description" <?=$canManage?'':'disabled'?>><?=book_e($selected['description'])?></textarea>
<h3>Module permissions</h3><div class="permission-grid"><?php $last='';foreach($permissions as $p):if($last!==$p['module']):$last=$p['module'];?><h4><?=book_e($modules[$last][0]??$extraModules[$last][0]??ucwords(str_replace('-',' ',$last)))?></h4><?php endif;?><label><input type="checkbox" name="permissions[]" value="<?=(int)$p['id']?>" <?=($selected['code']==='super_admin'||in_array((int)$p['id'],$granted,true))?'checked':''?> <?=(!$canManage||$selected['code']==='super_admin')?'disabled':''?>> <span><strong><?=book_e(substr($p['code'],strrpos($p['code'],'.')+1))?></strong><small><?=book_e($p['description'])?></small></span></label><?php endforeach;?></div>
<?php if($canManage):?><button class="book-btn">Save role permissions</button><?php endif;?></form>
<?php if($canManage&&!$selected['is_system']):?><form method="post" style="margin-top:14px" onsubmit="return confirm('Delete this custom role?')"><input type="hidden" name="_csrf" value="<?=book_csrf_token()?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$selected['id']?>"><button class="book-btn danger">Delete role</button></form><?php endif;?>
<?php else:?><p class="book-muted">Create or select a role.</p><?php endif;?></div></div>
</section></div></main><?php book_render_footer();?>
