<?php
require_once __DIR__.'/../includes/bootstrap.php';
book_require_admin();
$db=book_db();
$modules=require __DIR__.'/_modules.php';
function admin_scalar(PDO $db,string $sql,mixed $default=0):mixed{try{$v=$db->query($sql)->fetchColumn();return $v===false?$default:$v;}catch(Throwable){return $default;}}

$metrics=[];
if(book_can('users.view'))$metrics['Total users']=(int)admin_scalar($db,'SELECT COUNT(*) FROM book_users WHERE deleted_at IS NULL');
if(book_can('analytics.view')){
    $metrics['Daily active']=(int)admin_scalar($db,'SELECT COUNT(DISTINCT user_id) FROM book_reading_sessions WHERE started_at>=DATE_SUB(NOW(),INTERVAL 1 DAY)');
    $metrics['Monthly active']=(int)admin_scalar($db,'SELECT COUNT(DISTINCT user_id) FROM book_reading_sessions WHERE started_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)');
    $metrics['Reading hours']=round(((int)admin_scalar($db,'SELECT COALESCE(SUM(duration_seconds),0) FROM book_reading_sessions'))/3600,1);
}
if(book_can('subscriptions.view'))$metrics['Active subscriptions']=(int)admin_scalar($db,'SELECT COUNT(*) FROM book_subscriptions WHERE status IN("active","trialing","grace") AND (ends_at IS NULL OR ends_at>NOW() OR grace_ends_at>NOW())');
if(book_can('books.view'))$metrics['Books']=(int)admin_scalar($db,'SELECT COUNT(*) FROM book_books');
if(book_can('payments.view')){
    $revenueRows=[];
    try{$revenueRows=$db->query('SELECT UPPER(currency) currency,COALESCE(SUM(amount_minor),0) amount_minor FROM book_payments WHERE status="captured" GROUP BY UPPER(currency) ORDER BY UPPER(currency)')->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable){}
    $metrics['Captured revenue']=$revenueRows?implode(' · ',array_map(static fn(array $row):string=>book_format_money((int)$row['amount_minor'],(string)$row['currency']),$revenueRows)):'—';
}
if(book_can('support.view'))$metrics['Open tickets']=(int)admin_scalar($db,'SELECT COUNT(*) FROM book_support_tickets WHERE status NOT IN("resolved","closed")');

$latest=[];
if(book_can('activity.view')){try{$latest=$db->query('SELECT l.*,u.name user_name FROM book_activity_logs l LEFT JOIN book_users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT 12')->fetchAll();}catch(Throwable){}}
$health=[];
if(book_can('health.view')){
    $health=[
      ['Database',$db instanceof PDO,'Connected'],
      ['Private storage',is_dir(BOOK_CONFIG['paths']['books'])&&is_writable(BOOK_CONFIG['paths']['books']),'Book storage writable'],
      ['Exports',is_dir(BOOK_CONFIG['paths']['exports'])&&is_writable(BOOK_CONFIG['paths']['exports']),'Export storage writable'],
      ['Application key',BOOK_CONFIG['app']['key']!=='change-this-app-key-before-production','Production key configured'],
      ['Stripe',BOOK_CONFIG['payments']['stripe']['secret_key']!=='','Gateway key '.(BOOK_CONFIG['payments']['stripe']['secret_key']?'configured':'missing')],
      ['Razorpay',BOOK_CONFIG['payments']['razorpay']['key_secret']!=='','Gateway key '.(BOOK_CONFIG['payments']['razorpay']['key_secret']?'configured':'missing')],
    ];
}
$visibleModules=array_filter($modules,static fn(array $m,string $key):bool=>book_can($key.'.view'),ARRAY_FILTER_USE_BOTH);
book_render_header('Admin Console','admin','ReadVault administration, subscriptions, catalog, analytics, security and platform operations.');?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/../includes/sidebar.php';?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>Admin console</h1><p>Operate the modules assigned to your staff role. Every write action is protected and logged.</p></div><div class="book-actions"><?php if(book_can('health.view')):?><a class="book-btn secondary" href="<?=book_url('admin/system-health.php')?>">Run health check</a><?php endif;?><?php if(book_can('feature-flags.view')):?><a class="book-btn" href="<?=book_url('admin/feature-flags.php')?>">Feature flags</a><?php endif;?></div></div>
<div class="book-grid"><?php foreach($metrics as $label=>$value):?><div class="book-card book-stat"><span class="book-muted"><?=book_e($label)?></span><strong><?=book_e($value)?></strong></div><?php endforeach;?>
<div class="book-card <?=$health?'book-span-8':'book-span-12'?>"><h3>Platform modules</h3><div class="admin-module-grid" style="margin-top:15px"><?php foreach($visibleModules as $key=>$m):?><a class="book-card admin-module" style="box-shadow:none" href="<?=book_url('admin/module.php?module='.rawurlencode($key))?>"><span class="admin-module-icon"><?=$m[3]?></span><span><strong><?=book_e($m[0])?></strong><p><?=book_e($m[2])?></p></span></a><?php endforeach;if(!$visibleModules):?><p class="book-muted">This account has no module permissions. Ask a Super Administrator to assign a permission role.</p><?php endif;?></div></div>
<?php if($health):?><div class="book-card book-span-4"><h3>System readiness</h3><?php foreach($health as [$name,$ok,$detail]):?><div class="book-kv-item"><span class="health-dot" style="background:<?=$ok?'var(--book-success)':'var(--book-danger)'?>"></span><strong><?=book_e($name)?></strong><small class="book-muted d-block"><?=book_e($detail)?></small></div><?php endforeach;?><div class="book-actions" style="margin-top:14px"><?php if(book_can('settings.view')):?><a class="book-btn small secondary" href="<?=book_url('admin/settings.php')?>">Settings</a><?php endif;?><?php if(book_can('subscriptions.view')):?><a class="book-btn small secondary" href="<?=book_url('admin/plans.php')?>">Plans</a><?php endif;?></div></div><?php endif;?>
<?php if(book_can('activity.view')):?><div class="book-card book-span-12"><h3>Recent activity</h3><div class="book-table-wrap"><table class="book-table"><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th></tr></thead><tbody><?php foreach($latest as $row):?><tr><td><?=book_e($row['created_at'])?></td><td><?=book_e($row['user_name']?:'System')?></td><td><?=book_e($row['action'])?></td><td><?=book_e(trim(($row['entity_type']??'').' #'.($row['entity_id']??'')))?></td><td><?=book_e($row['ip_address'])?></td></tr><?php endforeach;if(!$latest):?><tr><td colspan="5" class="book-muted">Activity will appear as the platform is used.</td></tr><?php endif;?></tbody></table></div></div><?php endif;?></div></section></div></main><?php book_render_footer();?>
