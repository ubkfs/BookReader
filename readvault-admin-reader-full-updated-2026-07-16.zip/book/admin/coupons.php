<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_admin('coupons.view');
$db = book_db();

function coupon_datetime(?string $value): ?string {
    $value = trim((string)$value);
    if ($value === '') return null;
    $time = strtotime($value);
    return $time ? date('Y-m-d H:i:s', $time) : null;
}
function coupon_json_ids(array $values): ?string {
    $ids = array_values(array_unique(array_filter(array_map('intval', $values), static fn($v)=>$v > 0)));
    return $ids ? json_encode($ids) : null;
}
function coupon_json_countries(string $value): ?string {
    $codes = preg_split('/[\s,;]+/', strtoupper(trim($value))) ?: [];
    $codes = array_values(array_unique(array_filter($codes, static fn($v)=>preg_match('/^[A-Z]{2}$/', $v))));
    return $codes ? json_encode($codes) : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    book_require_admin('coupons.manage');
    book_verify_csrf();
    $action = (string)($_POST['action'] ?? 'save');

    if ($action === 'save') {
        $id = max(0, (int)($_POST['id'] ?? 0));
        $code = strtoupper(trim((string)($_POST['code'] ?? '')));
        if ($code === '') $code = 'FREE-' . strtoupper(bin2hex(random_bytes(4)));
        $code = preg_replace('/[^A-Z0-9_-]/', '', $code) ?: '';
        $type = in_array($_POST['discount_type'] ?? '', ['percent','fixed'], true) ? (string)$_POST['discount_type'] : 'percent';
        $value = max(0, (float)($_POST['discount_value'] ?? 0));
        $currency = strtoupper(trim((string)($_POST['currency'] ?? '')));
        $maxRedemptions = trim((string)($_POST['max_redemptions'] ?? ''));
        $perUserLimit = max(1, (int)($_POST['per_user_limit'] ?? 1));
        $startsAt = coupon_datetime($_POST['starts_at'] ?? null);
        $endsAt = coupon_datetime($_POST['ends_at'] ?? null);
        $planJson = coupon_json_ids($_POST['plan_ids'] ?? []);
        $countryJson = coupon_json_countries((string)($_POST['country_codes'] ?? ''));
        $active = isset($_POST['is_active']) ? 1 : 0;

        if ($code === '' || strlen($code) > 64) {
            book_flash('error', 'Enter a valid coupon code of up to 64 letters, numbers, hyphens, or underscores.');
        } elseif ($type === 'percent' && ($value <= 0 || $value > 100)) {
            book_flash('error', 'Percentage coupons must be greater than 0 and no more than 100. Use 100% for a completely free plan.');
        } elseif ($type === 'fixed' && ($value <= 0 || !preg_match('/^[A-Z]{3}$/', $currency))) {
            book_flash('error', 'Fixed discounts require a positive amount and a three-letter currency code.');
        } elseif ($startsAt && $endsAt && strtotime($endsAt) <= strtotime($startsAt)) {
            book_flash('error', 'The coupon end time must be after the start time.');
        } else {
            $currencyValue = $type === 'fixed' ? $currency : null;
            $maxValue = $maxRedemptions === '' ? null : max(1, (int)$maxRedemptions);
            try {
                if ($id > 0) {
                    $sql = 'UPDATE book_coupons SET code=?,discount_type=?,discount_value=?,currency=?,max_redemptions=?,per_user_limit=?,starts_at=?,ends_at=?,plan_ids_json=?,country_codes_json=?,is_active=? WHERE id=?';
                    $db->prepare($sql)->execute([$code,$type,$value,$currencyValue,$maxValue,$perUserLimit,$startsAt,$endsAt,$planJson,$countryJson,$active,$id]);
                    book_log('admin.coupon.updated', 'coupon', $id, ['code'=>$code]);
                } else {
                    $sql = 'INSERT INTO book_coupons (code,discount_type,discount_value,currency,max_redemptions,per_user_limit,starts_at,ends_at,plan_ids_json,country_codes_json,is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
                    $db->prepare($sql)->execute([$code,$type,$value,$currencyValue,$maxValue,$perUserLimit,$startsAt,$endsAt,$planJson,$countryJson,$active]);
                    $id = (int)$db->lastInsertId();
                    book_log('admin.coupon.created', 'coupon', $id, ['code'=>$code]);
                }
                book_flash('ok', 'Coupon saved. A 100% coupon activates the selected plan without opening a payment gateway.');
            } catch (Throwable $e) {
                $message = str_contains(strtolower($e->getMessage()), 'duplicate') ? 'That coupon code already exists.' : (BOOK_CONFIG['app']['debug'] ? $e->getMessage() : 'Coupon could not be saved.');
                book_flash('error', $message);
            }
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare('UPDATE book_coupons SET is_active=IF(is_active=1,0,1) WHERE id=?')->execute([$id]);
        book_log('admin.coupon.toggled', 'coupon', $id);
        book_flash('ok', 'Coupon status changed.');
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $used = $db->prepare('SELECT (SELECT COUNT(*) FROM book_coupon_redemptions WHERE coupon_id=?) + (SELECT COUNT(*) FROM book_orders WHERE coupon_id=?)');
        $used->execute([$id,$id]);
        if ((int)$used->fetchColumn() > 0) {
            $db->prepare('UPDATE book_coupons SET is_active=0 WHERE id=?')->execute([$id]);
            book_flash('error', 'Used coupons are retained for audit history and were deactivated instead of deleted.');
        } else {
            $db->prepare('DELETE FROM book_coupons WHERE id=?')->execute([$id]);
            book_log('admin.coupon.deleted', 'coupon', $id);
            book_flash('ok', 'Unused coupon deleted.');
        }
    }
    header('Location: ' . book_url('admin/coupons.php'));
    exit;
}

$plans = $db->query('SELECT id,name,code FROM book_subscription_plans ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
$coupons = $db->query('SELECT c.*,COUNT(DISTINCT r.id) redemption_count,COUNT(DISTINCT o.id) order_count FROM book_coupons c LEFT JOIN book_coupon_redemptions r ON r.coupon_id=c.id LEFT JOIN book_orders o ON o.coupon_id=c.id GROUP BY c.id ORDER BY c.created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
$editId=max(0,(int)($_GET['edit']??0));$editing=null;foreach($coupons as $row){if((int)$row['id']===$editId){$editing=$row;break;}}
$editPlans=$editing?(json_decode((string)($editing['plan_ids_json']??''),true)?:[]):[];
$editCountries=$editing?implode(', ',json_decode((string)($editing['country_codes_json']??''),true)?:[]):'';
book_render_header('Coupons', 'admin-coupons', 'Create controlled subscription discounts, including one-use 100% free access codes.');
?>
<main class="book-app" id="main-content"><div class="book-shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<section class="book-content">
  <div class="book-topbar"><div class="book-title"><h1>Coupon codes</h1><p>Create percentage or fixed discounts. Set 100% and a redemption limit of 1 when you want to give one person a plan completely free.</p></div><a class="book-btn secondary" href="<?= book_url('admin/index.php') ?>">Admin home</a></div>
  <?php if ($message = book_flash('ok')): ?><div class="book-alert ok"><?= book_e($message) ?></div><?php endif; ?>
  <?php if ($message = book_flash('error')): ?><div class="book-alert danger"><?= book_e($message) ?></div><?php endif; ?>

  <form method="post" class="book-card book-form" style="margin-top:18px">
    <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <?php if($editing):?><input type="hidden" name="id" value="<?=(int)$editing['id']?>"><?php endif;?>
    <h3><?=$editing?'Edit coupon '.book_e($editing['code']):'Create coupon'?></h3>
    <div class="book-mini-grid">
      <div><label class="book-label">Code</label><input class="book-input" name="code" maxlength="64" placeholder="Leave blank to generate" value="<?=book_e($editing['code']??'')?>"></div>
      <div><label class="book-label">Discount type</label><select class="book-select" name="discount_type" id="couponType"><option value="percent" <?=($editing['discount_type']??'percent')==='percent'?'selected':''?>>Percentage</option><option value="fixed" <?=($editing['discount_type']??'')==='fixed'?'selected':''?>>Fixed amount</option></select></div>
      <div><label class="book-label">Value</label><input class="book-input" type="number" name="discount_value" min="0.001" step="0.001" value="<?=book_e((string)($editing['discount_value']??100))?>" required><small class="book-form-help">100 with Percentage = fully free.</small></div>
      <div><label class="book-label">Fixed-discount currency</label><input class="book-input" name="currency" maxlength="3" value="<?=book_e((string)($editing['currency']??'USD'))?>" pattern="[A-Za-z]{3}"></div>
      <div><label class="book-label">Maximum redemptions</label><input class="book-input" type="number" name="max_redemptions" min="1" value="<?=book_e((string)($editing['max_redemptions']??1))?>" placeholder="Blank = unlimited"></div>
      <div><label class="book-label">Per-user limit</label><input class="book-input" type="number" name="per_user_limit" min="1" value="<?=book_e((string)($editing['per_user_limit']??1))?>"></div>
      <div><label class="book-label">Starts at</label><input class="book-input" type="datetime-local" name="starts_at" value="<?=!empty($editing['starts_at'])?book_e(date('Y-m-d\TH:i',strtotime($editing['starts_at']))):''?>"></div>
      <div><label class="book-label">Ends at</label><input class="book-input" type="datetime-local" name="ends_at" value="<?=!empty($editing['ends_at'])?book_e(date('Y-m-d\TH:i',strtotime($editing['ends_at']))):''?>"></div>
    </div>
    <label class="book-label">Limit to plans</label>
    <div class="book-actions"><?php foreach ($plans as $plan): ?><label><input type="checkbox" name="plan_ids[]" value="<?= (int)$plan['id'] ?>" <?=in_array((int)$plan['id'],array_map('intval',$editPlans),true)?'checked':''?>> <?= book_e($plan['name']) ?></label><?php endforeach; ?></div>
    <label class="book-label">Limit to countries</label><input class="book-input" name="country_codes" placeholder="Optional: US, IN, JP, GB" value="<?=book_e($editCountries)?>"><small class="book-form-help">Leave blank for all countries.</small>
    <label><input type="checkbox" name="is_active" <?=!$editing||$editing['is_active']?'checked':''?>> Active immediately</label>
    <div class="book-actions"><button class="book-btn"><?=$editing?'Save coupon':'Create coupon'?></button><?php if($editing):?><a class="book-btn secondary" href="<?=book_url('admin/coupons.php')?>">Cancel edit</a><?php endif;?></div>
  </form>

  <div class="book-card" style="margin-top:18px">
    <h3>Existing coupons</h3>
    <div class="book-table-wrap"><table class="book-table"><thead><tr><th>Code</th><th>Discount</th><th>Limits</th><th>Validity</th><th>Usage</th><th>Status</th><th>Actions</th></tr></thead><tbody>
    <?php foreach ($coupons as $coupon):
      $discount = $coupon['discount_type'] === 'percent' ? rtrim(rtrim(number_format((float)$coupon['discount_value'],2,'.',''),'0'),'.').'%' : book_e((string)$coupon['currency']).' '.rtrim(rtrim(number_format((float)$coupon['discount_value'],3,'.',''),'0'),'.');
    ?>
      <tr>
        <td><strong><?= book_e($coupon['code']) ?></strong></td>
        <td><?= $discount ?></td>
        <td><?= $coupon['max_redemptions'] ? 'Max '.(int)$coupon['max_redemptions'] : 'Unlimited' ?><br><small><?= (int)$coupon['per_user_limit'] ?> per user</small></td>
        <td><small><?= book_e($coupon['starts_at'] ?: 'Immediately') ?><br>to <?= book_e($coupon['ends_at'] ?: 'No expiry') ?></small></td>
        <td><?= (int)$coupon['redemption_count'] ?> redeemed<br><small><?= (int)$coupon['order_count'] ?> orders</small></td>
        <td><span class="book-chip <?= $coupon['is_active'] ? 'ok' : 'danger' ?>"><?= $coupon['is_active'] ? 'Active' : 'Inactive' ?></span></td>
        <td><div class="book-inline-actions">
          <a class="book-icon-btn" href="<?=book_url('admin/coupons.php?edit='.(int)$coupon['id'])?>">Edit</a>
          <form method="post"><input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$coupon['id'] ?>"><button class="book-icon-btn"><?= $coupon['is_active'] ? 'Deactivate' : 'Activate' ?></button></form>
          <form method="post" onsubmit="return confirm('Delete this unused coupon?')"><input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$coupon['id'] ?>"><button class="book-icon-btn danger">Delete</button></form>
        </div></td>
      </tr>
    <?php endforeach; if (!$coupons): ?><tr><td colspan="7" class="book-muted">No coupons created yet.</td></tr><?php endif; ?>
    </tbody></table></div>
  </div>
</section></div></main>
<?php book_render_footer(); ?>
