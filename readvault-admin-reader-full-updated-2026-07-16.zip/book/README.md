# ReadVault Independent SaaS Book Platform

ReadVault is a self-contained PHP 8.3 and MySQL 8 application intended for deployment at:

`https://services.teknouf.com/book`

It does **not** import configuration, authentication, sessions, database connections, routing, assets, storage, or payment code from `teknouf.com`.

## What is included

- Independent `.env` and `/config/config.php`
- Dedicated PDO connection and MySQL schema
- Every database table uses the `book_` namespace; collision-prone domain tables use descriptive names such as `book_author_profiles` and `book_ui_translations`
- Complete original-to-prefixed table mapping is documented in `docs/DATABASE_TABLES.md`
- Composer PSR-4 autoloading
- Registration, login, email verification, password reset, remember-me, devices, login history, revoke device, and logout-all
- Free, trial, monthly, quarterly, six-month, annual, and optional lifetime plans
- Country-aware prices, coupons, orders, captured payments, invoice records, expiry, grace periods, upgrades/downgrades, cancellation preference, and one-trial-per-account enforcement
- Stripe Checkout and Razorpay Order adapters with signed webhook verification
- Encrypted administrator-managed gateway credentials with `.env` fallback
- PDF and EPUB reading through expiring signed URLs
- PDF.js and ePub.js readers with page, scroll, and desktop double-page modes
- Dark, sepia, night, high-contrast, brightness, margins, font size, line height, letter spacing, dyslexia mode, and keyboard navigation
- Bookmarks, highlights, underlines, notes, vocabulary, search, revision, and PDF/DOCX/TXT/Markdown/CSV export adapters
- Browser text-to-speech, voice selection, speed, pitch, pause, resume, and stop
- Focus mode, Pomodoro timer, generated ambient audio, fullscreen, auto-scroll, and Screen Wake Lock support
- Synchronized progress, last location, reading sessions, time estimates, goals, streaks, badges, challenges, and leaderboards
- PWA manifest, service worker, installability, offline shell, IndexedDB book cache, app shortcuts, update detection, and background-sync extension point
- Family profile limits, wishlists, price alerts, recommendation feed, referral/gift data model, author/publisher data model, and feature flags
- User account center for subscription, invoices, achievements, downloads, and devices
- Admin console covering all requested business and operational modules
- Public landing page, book pages, blog, canonical URLs, JSON-LD, robots, and dynamic sitemap
- CSP, CSRF, prepared statements, secure cookies, signed stream tokens, HTTP Range support, rate limiting, private storage rules, MIME/signature checks, security headers, and audit logs
- Cron jobs for subscription expiry/reminders, queue processing, cleanup, and health checks

## Important implementation boundary

This package is a production-oriented application foundation, not a claim that every possible commercial workflow is complete. The central reading, identity, entitlement, payment, PWA, security, SEO, and admin-control paths are implemented. Several large business domains, such as publisher royalty accounting, automated tax registration, full affiliate payout settlement, licensed DRM/KMS integration, payment-provider recurring billing, moderation automation, and native mobile notification delivery, have schema and service boundaries ready for project-specific implementation.

Administrative modules now provide searchable record views and guarded create, edit and delete workflows where the underlying domain permits them. Sensitive areas use dedicated audited screens: users, payments, support tickets, email templates, backups, API clients, roles and permissions, and family sharing. Payment reconciliation changes local records only; actual gateway refunds must still be performed through the configured provider or a provider-specific integration.

## Requirements

- PHP 8.3+
- MySQL 8+
- PHP extensions: `pdo_mysql`, `json`, `openssl`, `fileinfo`, `mbstring`, `curl`
- Apache with `mod_rewrite`, `mod_headers`, `mod_deflate`, and `mod_expires`, or equivalent Nginx rules
- HTTPS in production
- Composer 2

Optional export and SMTP libraries are installed by Composer:

- PHPMailer
- Dompdf
- PHPWord


## ReadVault 2.3 operational update

Existing installations must run `database/migrations/002_admin_operations.sql` after taking a database backup. The update adds operational admin workflows, transactional email templates, database/file/full backup generation, support-ticket conversations, family entitlement sharing, PDF mobile reflow selection, reader typography controls, speech-follow scrolling, and automatic next-page narration.

Family sharing works by linking a separate ReadVault user account to a profile in the subscription owner’s household. The linked member inherits the owner’s active entitlement while keeping separate progress, notes, highlights and devices. Billing, expiry, profile limits and offline limits remain controlled by the owner.

## Installation

1. Extract the project into the document root path that maps to `/book`.
2. Create a new, empty MySQL database and database user. Do not reuse the main website database.
3. Copy the environment template:

   ```bash
   cp .env.example .env
   ```

4. Generate three separate secrets:

   ```bash
   php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
   ```

   Run it three times and set `APP_KEY`, `JWT_SECRET`, and `SIGNED_URL_SECRET`. Generate a separate `CRON_SECRET` if web-triggered cron is required.

5. Enter database, SMTP, payment, OAuth, API, and application URL values in `.env`.
   Keep `DB_TABLE_PREFIX=book_`; the supplied schema and application queries are already namespaced with this prefix.
6. Install dependencies:

   ```bash
   composer install --no-dev --optimize-autoloader
   ```

7. Grant the PHP process write access to these directories:

   ```text
   storage/private/
   storage/exports/
   storage/cache/
   storage/logs/
   storage/backups/
   ```

8. Open `https://services.teknouf.com/book/install.php` and create the first super administrator.
9. Delete `install.php` or deny web access after successful setup.
10. Configure Stripe and Razorpay webhooks:

    ```text
    https://services.teknouf.com/book/webhooks/stripe.php
    https://services.teknouf.com/book/webhooks/razorpay.php
    ```

11. Configure the cron jobs documented in `docs/CRON.md`.
12. Verify `/admin/system-health.php` while signed in as an administrator.

## Apache deployment

The included `.htaccess` blocks configuration, application source, database scripts, private storage, logs, backups, dotfiles, and directory listing. The application also emits runtime security headers.

Ensure the `/book` directory allows overrides:

```apache
<Directory /var/www/services/book>
    AllowOverride All
    Require all granted
</Directory>
```

## Nginx deployment notes

Deny direct access to at least:

```nginx
location ~ ^/book/(config|database|app|includes|storage/private|storage/logs|storage/backups)/ { deny all; }
location ~ ^/book/\. { deny all; }
```

Pass PHP files to PHP-FPM and set upload limits in both Nginx and PHP:

```nginx
client_max_body_size 200M;
```

Relevant PHP values:

```ini
upload_max_filesize=200M
post_max_size=205M
max_execution_time=120
memory_limit=512M
```

## Reader file security

Uploaded files are stored below `storage/private/books`, not as public assets. The browser receives an expiring HMAC-signed token bound to the current user and book. `view-pdf.php` validates the session, token, ownership or entitlement, expiry, storage root, and file type before streaming.

This is application-level DRM through access control and signed streaming. For publisher-grade encrypted-at-rest delivery, connect `encryption_key_id` and `drm_mode=encrypted_stream` to a KMS/HSM and a range-aware encryption format. Do not invent proprietary cryptography.

## PWA and offline reading

The service worker caches the application shell and navigated pages but deliberately bypasses protected book-stream requests. A user must explicitly select **Save offline** in the reader. The offline API verifies the subscription and plan limit before the browser stores the protected response in IndexedDB. The expiry cron revokes premium offline entitlements after access ends.

The reader requests the Screen Wake Lock API while the toggle is enabled and reading is visible. Browser or operating-system policy can still refuse or release the lock, so the script reacquires it after visibility changes and reports current status.

## Payment architecture

- Stripe uses Checkout Sessions and signed webhook verification.
- Razorpay creates Orders and verifies both checkout signatures and webhooks.
- Fulfillment is idempotent at the provider payment and invoice layers.
- Payment and webhook payloads are retained for audit.
- Administrator-entered keys are encrypted with `APP_KEY`; environment values remain the preferred production source.

The included gateways create one-time payments. True provider-managed auto-renewal requires recurring Stripe Prices/Subscriptions or Razorpay Subscriptions plus provider-specific cancellation, retry, dunning, and renewal webhooks. The database and entitlement fields are ready for that extension.

## SEO

Public content includes:

- `/index.php`
- `/book.php?id=...` or `?slug=...`
- `/blog/index.php`
- `/blog/post.php?slug=...`
- `/sitemap.php`
- `/robots.txt`

Private accounts, APIs, admin screens, storage, and signed streams are blocked from crawling. Add clean rewrite routes if you prefer `/books/example-slug` and `/journal/article-slug`.

## Source layout

```text
app/Core/              Database, session and authentication
app/Payments/          Payment gateway adapters
app/Services/          Entitlement, signing, mail, flags and fulfillment
config/                 Independent configuration
admin/                  Admin console and explicit settings screens
account/                User subscription, invoices and devices
auth/                   Independent identity flows
api/                    Authenticated reader and account APIs
cron/                   Scheduled operational jobs
database/               Baseline schema, migrations and seeders
storage/private/        Non-public books and uploads
storage/exports/        Time-limited user exports
assets/                  Application CSS, JavaScript and icons
blog/                    Public SEO article pages
docs/                    Architecture, security, cron and deployment notes
```

## Validation before launch

- Replace all example secrets.
- Use a dedicated least-privilege database account.
- Run Composer with optimized production autoloading.
- Confirm HTTPS and secure cookies.
- Confirm private storage is denied at the web-server layer.
- Verify CSP against any self-hosted/CDN assets you change.
- Configure SMTP and test verification, reset, and expiry messages.
- Configure and verify gateway webhook signatures.
- Test trial, coupon, successful payment, failed payment, expiry, grace, and cancellation cases.
- Test PDF and EPUB files on Android, tablet, desktop, offline mode, and low-memory devices.
- Set legal terms, privacy policy, copyright takedown process, retention periods, tax rules, and licensing rules for your countries.
- Add backups outside the web root and perform a restore drill.

See `docs/ARCHITECTURE.md`, `docs/SECURITY.md`, `docs/CRON.md`, and `docs/FEATURE_STATUS.md`.
