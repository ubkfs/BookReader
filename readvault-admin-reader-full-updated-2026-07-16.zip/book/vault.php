<?php
require_once __DIR__ . '/includes/bootstrap.php'; book_require_login();
$db = book_db();
$uid = book_user_id();
$q = trim($_GET['q'] ?? '');
$type = $_GET['type'] ?? 'all';
$items = [];
function add_items(&$items,$rows,$type,$titleKey,$contentKey,$endpoint){
    foreach($rows as $r){
        $items[] = [
            'id'=>$r['id'] ?? 0,
            'type'=>$type,
            'endpoint'=>$endpoint,
            'raw'=>$r,
            'title'=>$r[$titleKey] ?? ucfirst($type),
            'content'=>$r[$contentKey] ?? '',
            'book_title'=>$r['book_title'] ?? '',
            'page_number'=>$r['page_number'] ?? '',
            'created_at'=>$r['created_at'] ?? ''
        ];
    }
}
if($type==='all'||$type==='notes'){$sql='SELECT n.*,b.title book_title FROM book_notes n LEFT JOIN book_books b ON n.book_id=b.id WHERE n.user_id=?';$p=[$uid];if($q){$sql.=' AND (n.title LIKE ? OR n.content LIKE ?)';$p[]="%$q%";$p[]="%$q%";}$stmt=$db->prepare($sql.' ORDER BY n.created_at DESC LIMIT 100');$stmt->execute($p);add_items($items,$stmt->fetchAll(PDO::FETCH_ASSOC),'note','title','content','notes');}
if($type==='all'||$type==='highlights'){$sql='SELECT h.*,b.title book_title FROM book_highlights h LEFT JOIN book_books b ON h.book_id=b.id WHERE h.user_id=?';$p=[$uid];if($q){$sql.=' AND h.selected_text LIKE ?';$p[]="%$q%";}$stmt=$db->prepare($sql.' ORDER BY h.created_at DESC LIMIT 100');$stmt->execute($p);add_items($items,$stmt->fetchAll(PDO::FETCH_ASSOC),'highlight','category','selected_text','highlights');}
if($type==='all'||$type==='vocabulary'){$sql='SELECT v.*,b.title book_title,v.source_page page_number FROM book_vocabulary v LEFT JOIN book_books b ON v.book_id=b.id WHERE v.user_id=?';$p=[$uid];if($q){$sql.=' AND (v.word LIKE ? OR v.meaning LIKE ? OR v.simple_meaning LIKE ?)';$p[]="%$q%";$p[]="%$q%";$p[]="%$q%";}$stmt=$db->prepare($sql.' ORDER BY v.created_at DESC LIMIT 100');$stmt->execute($p);add_items($items,$stmt->fetchAll(PDO::FETCH_ASSOC),'vocabulary','word','meaning','vocabulary');}
if($type==='all'||$type==='bookmarks'){$sql='SELECT bm.*,b.title book_title FROM book_bookmarks bm LEFT JOIN book_books b ON bm.book_id=b.id WHERE bm.user_id=?';$p=[$uid];if($q){$sql.=' AND bm.name LIKE ?';$p[]="%$q%";}$stmt=$db->prepare($sql.' ORDER BY bm.created_at DESC LIMIT 100');$stmt->execute($p);add_items($items,$stmt->fetchAll(PDO::FETCH_ASSOC),'bookmark','name','type','bookmarks');}
usort($items,fn($a,$b)=>strcmp($b['created_at'],$a['created_at']));
book_render_header('Knowledge Vault','book-vault');
?>
<main class="book-app"><div class="book-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><section class="book-content"><div class="book-topbar"><div class="book-title"><h1>My Knowledge Vault</h1><p>Search, edit and delete notes, highlights, bookmarks and vocabulary.</p></div><a class="book-btn secondary" href="<?= book_url('api/export.php?type=revision_pack') ?>">Export Revision Pack</a></div>
<div class="book-card"><form class="book-actions" method="get"><input class="book-input" style="max-width:460px" name="q" value="<?= book_e($q) ?>" placeholder="Search your knowledge"><select class="book-select" style="max-width:180px" name="type"><option value="all">All</option><option value="notes" <?= $type==='notes'?'selected':'' ?>>Notes</option><option value="highlights" <?= $type==='highlights'?'selected':'' ?>>Highlights</option><option value="vocabulary" <?= $type==='vocabulary'?'selected':'' ?>>Vocabulary</option><option value="bookmarks" <?= $type==='bookmarks'?'selected':'' ?>>Bookmarks</option></select><button class="book-btn">Search</button></form></div>
<div class="book-card" style="margin-top:18px"><?php foreach($items as $it): ?><div class="book-kv-item" data-id="<?= (int)$it['id'] ?>" data-type="<?= book_e($it['type']) ?>" data-endpoint="<?= book_e($it['endpoint']) ?>" data-raw='<?= book_e(json_encode($it['raw'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>'><span class="book-chip"><?= book_e($it['type']) ?></span><strong><?= book_e($it['title'] ?: ucfirst($it['type'])) ?></strong><p><?= nl2br(book_e($it['content'])) ?></p><small class="book-muted"><?= book_e($it['book_title']) ?> <?= $it['page_number']?' · Page '.(int)$it['page_number']:'' ?> · <?= book_e($it['created_at']) ?></small><div class="book-inline-actions"><button class="book-icon-btn vault-edit">Edit</button><button class="book-icon-btn danger vault-delete">Delete</button><?php if(!empty($it['raw']['book_id']) && !empty($it['page_number'])): ?><a class="book-icon-btn" href="<?= book_url('reader.php?id='.(int)$it['raw']['book_id'].'&page='.(int)$it['page_number']) ?>">Open Page</a><?php endif; ?></div></div><?php endforeach; if(!$items): ?><p class="book-muted">Nothing found yet.</p><?php endif; ?></div>
</section></div></main>
<script>
document.querySelectorAll('.vault-delete').forEach(btn=>btn.onclick=async()=>{const item=btn.closest('.book-kv-item');if(!confirm('Delete this '+item.dataset.type+'?'))return;const r=await bookApi('api/'+item.dataset.endpoint+'.php?action=delete',{id:item.dataset.id});if(r.success)item.remove();else alert(r.message||'Failed');});
document.querySelectorAll('.vault-edit').forEach(btn=>btn.onclick=async()=>{const item=btn.closest('.book-kv-item');const raw=JSON.parse(item.dataset.raw||'{}');let r=null;if(item.dataset.type==='note'){const title=prompt('Note title',raw.title||'');if(title===null)return;const content=prompt('Note content',raw.content||'');if(content===null)return;r=await bookApi('api/notes.php?action=update',{id:item.dataset.id,title,content});}else if(item.dataset.type==='vocabulary'){const word=prompt('Word',raw.word||'');if(word===null)return;const meaning=prompt('Meaning',raw.meaning||raw.simple_meaning||'');if(meaning===null)return;r=await bookApi('api/vocabulary.php?action=update',{id:item.dataset.id,word,meaning,simple_meaning:raw.simple_meaning||meaning,part_of_speech:raw.part_of_speech||'',pronunciation:raw.pronunciation||'',synonyms:raw.synonyms||'',antonyms:raw.antonyms||'',example_sentence:raw.example_sentence||''});}else if(item.dataset.type==='bookmark'){const name=prompt('Bookmark name',raw.name||'Bookmark');if(name===null)return;const page=prompt('Page number',raw.page_number||1);if(page===null)return;r=await bookApi('api/bookmarks.php?action=update',{id:item.dataset.id,name,page_number:page,type:raw.type||'page'});}else if(item.dataset.type==='highlight'){const note=prompt('Highlight note',raw.note||'');if(note===null)return;const color=prompt('Color: yellow, green, blue, red, purple, orange',raw.color||'yellow');if(color===null)return;r=await bookApi('api/highlights.php?action=update',{id:item.dataset.id,note,color,category:raw.category||'important'});}if(r?.success)location.reload();else alert(r?.message||'Failed');});
</script>
<?php book_render_footer(); ?>
