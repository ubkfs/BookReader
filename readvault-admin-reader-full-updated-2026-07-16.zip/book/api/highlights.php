<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

$colors = ['yellow','green','blue','red','purple','orange'];
$cats = ['important','definition','example','revision','quote','exam_question'];

if ($action === 'list') {
    $bookId = (int)($_GET['book_id'] ?? 0);
    $sql = 'SELECT * FROM book_highlights WHERE user_id=?';
    $p = [$uid];
    if ($bookId) { $sql .= ' AND book_id=?'; $p[] = $bookId; }
    $sql .= ' ORDER BY created_at DESC';
    $st = $db->prepare($sql);
    $st->execute($p);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

if ($action === 'create') {
    book_verify_csrf();
    $bookId = (int)($_POST['book_id'] ?? 0);
    $page = (int)($_POST['page_number'] ?? 0);
    $text = trim($_POST['selected_text'] ?? '');
    $color = $_POST['color'] ?? 'yellow';
    $cat = $_POST['category'] ?? 'important';
    if (!$bookId || !$page || $text === '' || !book_fetch_user_book($db,$bookId,$uid)) book_json(['success'=>false,'message'=>'Invalid highlight.']);
    if (!in_array($color,$colors,true)) $color='yellow';
    if (!in_array($cat,$cats,true)) $cat='important';
    $st = $db->prepare('INSERT INTO book_highlights (user_id,book_id,page_number,location_value,selected_text,normalized_text,color,category,note) VALUES (?,?,?,?,?,?,?,?,?)');
    $st->execute([$uid,$bookId,$page,trim((string)($_POST['location_value']??''))?:null,$text,mb_strtolower($text,'UTF-8'),$color,$cat,$_POST['note']??null]);
    book_json(['success'=>true,'id'=>(int)$db->lastInsertId(),'message'=>'Highlight saved.']);
}

if ($action === 'update') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $color = $_POST['color'] ?? 'yellow';
    $cat = $_POST['category'] ?? 'important';
    if (!in_array($color,$colors,true)) $color='yellow';
    if (!in_array($cat,$cats,true)) $cat='important';
    $note = $_POST['note'] ?? null;
    $db->prepare('UPDATE book_highlights SET color=?, category=?, note=?, updated_at=NOW() WHERE id=? AND user_id=?')->execute([$color,$cat,$note,$id,$uid]);
    book_json(['success'=>true,'message'=>'Highlight updated.']);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM book_highlights WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_json(['success'=>true,'message'=>'Highlight deleted.']);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
