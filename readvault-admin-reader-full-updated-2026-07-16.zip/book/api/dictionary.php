<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
book_rate_limit('dictionary', 100, 60);

$db = book_db();
$uid = book_user_id();
$rawWord = trim($_GET['word'] ?? '');
$word = book_normalize_quiz_word($rawWord);
if (!$word) {
    book_json(['success'=>false,'message'=>'Please search only one word. Sentences or phrases are not added to quiz words.']);
}

$bookId = (int)($_GET['book_id'] ?? 0) ?: null;
$page = (int)($_GET['page_number'] ?? 0) ?: null;
if ($bookId && !book_fetch_user_book($db, $bookId, $uid)) {
    book_json(['success'=>false,'message'=>'Book not found.']);
}

$url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' . rawurlencode($word);
$data = null;
$error = '';

if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'ReadVault/1.2 Dictionary Lookup',
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($body && $code >= 200 && $code < 300) $data = json_decode($body, true);
} else {
    $ctx = stream_context_create(['http'=>['timeout'=>10,'header'=>"Accept: application/json\r\nUser-Agent: ReadVault/1.2\r\n"]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body) $data = json_decode($body, true);
}

if (!$data || empty($data[0]['meanings'])) {
    // Still add the searched single word to quiz words so the user can edit its meaning later.
    $vocabId = book_upsert_vocabulary_word($db, $uid, $word, [
        'book_id'=>$bookId,
        'source_page'=>$page,
        'meaning'=>'',
        'simple_meaning'=>''
    ]);
    book_json([
        'success'=>false,
        'saved_to_quiz'=>true,
        'vocabulary_id'=>$vocabId,
        'message'=>'Meaning not found or dictionary API unavailable. The single word was still added to Quiz Words; you can edit the meaning manually.',
        'debug'=>$error ?: null
    ]);
}

$entry = $data[0];
$definitions = [];
$synonyms = [];
$antonyms = [];
$firstMeaning = $entry['meanings'][0] ?? [];
$firstDefinition = $firstMeaning['definitions'][0] ?? [];

foreach (($entry['meanings'] ?? []) as $meaning) {
    foreach (($meaning['definitions'] ?? []) as $def) {
        if (!empty($def['definition'])) {
            $definitions[] = [
                'part_of_speech' => $meaning['partOfSpeech'] ?? '',
                'definition' => $def['definition'],
                'example' => $def['example'] ?? ''
            ];
        }
    }
    $synonyms = array_merge($synonyms, $meaning['synonyms'] ?? []);
    $antonyms = array_merge($antonyms, $meaning['antonyms'] ?? []);
}

$payload = [
    'success'=>true,
    'word'=>$entry['word'] ?? $word,
    'meaning'=>$firstDefinition['definition'] ?? '',
    'simple_meaning'=>$firstDefinition['definition'] ?? '',
    'example'=>$firstDefinition['example'] ?? '',
    'part_of_speech'=>$firstMeaning['partOfSpeech'] ?? '',
    'synonyms'=>implode(', ', array_slice(array_values(array_unique($synonyms)), 0, 12)),
    'antonyms'=>implode(', ', array_slice(array_values(array_unique($antonyms)), 0, 12)),
    'pronunciation'=>$entry['phonetic'] ?? (($entry['phonetics'][0]['text'] ?? '') ?: ''),
    'definitions'=>array_slice($definitions, 0, 8)
];

$vocabId = book_upsert_vocabulary_word($db, $uid, $payload['word'] ?: $word, [
    'book_id'=>$bookId,
    'source_page'=>$page,
    'meaning'=>$payload['meaning'],
    'simple_meaning'=>$payload['simple_meaning'],
    'synonyms'=>$payload['synonyms'],
    'antonyms'=>$payload['antonyms'],
    'pronunciation'=>$payload['pronunciation'],
    'part_of_speech'=>$payload['part_of_speech'],
    'example_sentence'=>$payload['example']
]);

$payload['saved_to_quiz'] = true;
$payload['vocabulary_id'] = $vocabId;
$payload['message'] = 'Added to Quiz Words.';
book_json($payload);
