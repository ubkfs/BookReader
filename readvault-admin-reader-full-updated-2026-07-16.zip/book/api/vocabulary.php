<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

function book_vocab_owned(PDO $db, int $id, int $uid): ?array {
    $st = $db->prepare('SELECT * FROM book_vocabulary WHERE id=? AND user_id=?');
    $st->execute([$id, $uid]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

if ($action === 'list') {
    $bookId = (int)($_GET['book_id'] ?? 0);
    $sql = 'SELECT v.*, b.title book_title FROM book_vocabulary v LEFT JOIN book_books b ON v.book_id=b.id WHERE v.user_id=?';
    $params = [$uid];
    if ($bookId) { $sql .= ' AND v.book_id=?'; $params[] = $bookId; }
    $sql .= ' ORDER BY v.created_at DESC';
    $st = $db->prepare($sql);
    $st->execute($params);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

if ($action === 'save') {
    book_verify_csrf();
    $word = book_normalize_quiz_word($_POST['word'] ?? '');
    if (!$word) book_json(['success'=>false,'message'=>'Only a single word can be saved to Quiz Words. Sentences and phrases are not allowed.']);
    $bookId = (int)($_POST['book_id'] ?? 0) ?: null;
    if ($bookId && !book_fetch_user_book($db, $bookId, $uid)) book_json(['success'=>false,'message'=>'Book not found.']);

    $vocabId = book_upsert_vocabulary_word($db, $uid, $word, [
        'book_id'=>$bookId,
        'source_page'=>(int)($_POST['source_page'] ?? 0) ?: null,
        'meaning'=>$_POST['meaning'] ?? null,
        'simple_meaning'=>$_POST['simple_meaning'] ?? null,
        'bengali_meaning'=>$_POST['bengali_meaning'] ?? null,
        'hindi_meaning'=>$_POST['hindi_meaning'] ?? null,
        'synonyms'=>$_POST['synonyms'] ?? null,
        'antonyms'=>$_POST['antonyms'] ?? null,
        'pronunciation'=>$_POST['pronunciation'] ?? null,
        'example_sentence'=>$_POST['example_sentence'] ?? null,
        'part_of_speech'=>$_POST['part_of_speech'] ?? null
    ]);
    book_json(['success'=>true,'message'=>'Word saved to Quiz Words.','vocabulary_id'=>$vocabId]);
}

if ($action === 'update') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    if (!$id || !book_vocab_owned($db, $id, $uid)) book_json(['success'=>false,'message'=>'Word not found.']);
    $word = book_normalize_quiz_word($_POST['word'] ?? '');
    if (!$word) book_json(['success'=>false,'message'=>'Only a single word can be saved to Quiz Words.']);
    $st = $db->prepare('UPDATE book_vocabulary SET word=?, meaning=?, simple_meaning=?, bengali_meaning=?, hindi_meaning=?, synonyms=?, antonyms=?, pronunciation=?, example_sentence=?, part_of_speech=?, updated_at=NOW() WHERE id=? AND user_id=?');
    $st->execute([
        $word,
        $_POST['meaning'] ?? null,
        $_POST['simple_meaning'] ?? null,
        $_POST['bengali_meaning'] ?? null,
        $_POST['hindi_meaning'] ?? null,
        $_POST['synonyms'] ?? null,
        $_POST['antonyms'] ?? null,
        $_POST['pronunciation'] ?? null,
        $_POST['example_sentence'] ?? null,
        $_POST['part_of_speech'] ?? null,
        $id,$uid
    ]);
    book_json(['success'=>true,'message'=>'Word updated.']);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM book_vocabulary WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_json(['success'=>true,'message'=>'Word deleted.']);
}

if ($action === 'review') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $result = $_POST['result'] ?? 'forgotten';
    $w = book_vocab_owned($db, $id, $uid);
    if (!$w) book_json(['success'=>false,'message'=>'Word not found.']);
    if ($result === 'remembered') {
        $level = min(8, (int)$w['review_level'] + 1);
        $days = [1=>1,2=>3,3=>7,4=>14,5=>30,6=>60,7=>120,8=>180][$level];
        $db->prepare('UPDATE book_vocabulary SET review_level=?, remembered_count=remembered_count+1, next_review_at=DATE_ADD(NOW(), INTERVAL ? DAY) WHERE id=? AND user_id=?')->execute([$level,$days,$id,$uid]);
    } else {
        $db->prepare('UPDATE book_vocabulary SET review_level=1, forgotten_count=forgotten_count+1, next_review_at=DATE_ADD(NOW(), INTERVAL 1 DAY) WHERE id=? AND user_id=?')->execute([$id,$uid]);
    }
    book_json(['success'=>true]);
}

if ($action === 'quiz') {
    $st = $db->prepare('SELECT word,meaning,simple_meaning,bengali_meaning,hindi_meaning,synonyms,antonyms,pronunciation,example_sentence,part_of_speech FROM book_vocabulary WHERE user_id=? AND COALESCE(meaning,simple_meaning,bengali_meaning,hindi_meaning,"")<>"" ORDER BY RAND() LIMIT 12');
    $st->execute([$uid]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    $questions = [];
    foreach ($rows as $row) {
        $answer = $row['meaning'] ?: ($row['simple_meaning'] ?: ($row['hindi_meaning'] ?: $row['bengali_meaning']));
        $opts = [$answer];
        foreach ($rows as $r) {
            $m = $r['meaning'] ?: ($r['simple_meaning'] ?: ($r['hindi_meaning'] ?: $r['bengali_meaning']));
            if ($m !== $answer && $m && !in_array($m, $opts, true)) $opts[] = $m;
            if (count($opts) >= 4) break;
        }
        if (count($opts) >= 2) {
            shuffle($opts);
            $meta = [];
            if (!empty($row['part_of_speech'])) $meta[] = 'Part of speech: '.$row['part_of_speech'];
            if (!empty($row['pronunciation'])) $meta[] = 'Pronunciation: '.$row['pronunciation'];
            if (!empty($row['synonyms'])) $meta[] = 'Synonyms: '.$row['synonyms'];
            if (!empty($row['antonyms'])) $meta[] = 'Antonyms: '.$row['antonyms'];
            if (!empty($row['example_sentence'])) $meta[] = 'Example: '.$row['example_sentence'];
            if (!empty($row['hindi_meaning'])) $meta[] = 'Hindi: '.$row['hindi_meaning'];
            if (!empty($row['bengali_meaning'])) $meta[] = 'Bengali: '.$row['bengali_meaning'];
            $questions[] = [
                'question'=>'What is the meaning of "'.$row['word'].'"?',
                'options'=>$opts,
                'answer'=>$answer,
                'word'=>$row['word'],
                'part_of_speech'=>$row['part_of_speech'],
                'pronunciation'=>$row['pronunciation'],
                'synonyms'=>$row['synonyms'],
                'antonyms'=>$row['antonyms'],
                'example_sentence'=>$row['example_sentence'],
                'hindi_meaning'=>$row['hindi_meaning'],
                'bengali_meaning'=>$row['bengali_meaning'],
                'meta'=>$meta
            ];
        }
    }
    book_json(['success'=>true,'questions'=>$questions]);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
