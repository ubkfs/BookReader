<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';book_require_login();$db=book_db();$uid=book_user_id();$action=$_GET['action']??'';
if($action!=='end_session')book_verify_csrf();
if($action==='start_session'){
  $bookId=(int)($_POST['book_id']??0);$start=max(1,(int)($_POST['start_page']??1));$device=(string)($_POST['device_type']??'desktop');if(!book_fetch_user_book($db,$bookId,$uid))book_json(['success'=>false,'message'=>'Book not found.'],404);
  $allowed=['desktop','mobile','tablet','extension','pwa'];if(!in_array($device,$allowed,true))$device='desktop';
  $st=$db->prepare('INSERT INTO book_reading_sessions (user_id,book_id,device_id,start_page,started_at,device_type) VALUES (?,?,?,?,NOW(),?)');$st->execute([$uid,$bookId,(int)($_SESSION['device_id']??0)?:null,$start,$device]);book_json(['success'=>true,'session_id'=>(int)$db->lastInsertId()]);
}
if($action==='update_progress'){
  $bookId=(int)($_POST['book_id']??0);$page=max(1,(int)($_POST['page']??1));$total=max(0,(int)($_POST['total_pages']??0));$location=trim((string)($_POST['location_value']??''));$pct=max(0,min(100,(float)($_POST['progress_percent']??($total?($page/$total*100):0))));
  if(!book_fetch_user_book($db,$bookId,$uid))book_json(['success'=>false,'message'=>'Book not found.'],404);
  $db->prepare('INSERT INTO book_progress (user_id,book_id,device_id,page_number,location_value,progress_percent,last_read_at) VALUES (?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE device_id=VALUES(device_id),page_number=VALUES(page_number),location_value=VALUES(location_value),progress_percent=VALUES(progress_percent),last_read_at=NOW()')->execute([$uid,$bookId,(int)($_SESSION['device_id']??0)?:null,$page,$location?:null,$pct]);
  $db->prepare('UPDATE book_books SET current_page=?,total_pages=GREATEST(total_pages,?),current_location=?,last_opened_at=NOW(),reading_status=IF(reading_status="not_started","reading",reading_status) WHERE id=? AND user_id=?')->execute([$page,$total,$location?:null,$bookId,$uid]);
  book_json(['success'=>true,'progress_percent'=>$pct]);
}
if($action==='end_session'){
  $bookId=(int)($_POST['book_id']??0);$sid=(int)($_POST['session_id']??0);$end=max(1,(int)($_POST['end_page']??1));
  if($sid){$st=$db->prepare('SELECT * FROM book_reading_sessions WHERE id=? AND user_id=?');$st->execute([$sid,$uid]);$s=$st->fetch();if($s){$dur=max(0,time()-strtotime($s['started_at']));$pages=max(0,$end-(int)$s['start_page']+1);$db->prepare('UPDATE book_reading_sessions SET end_page=?,pages_read=?,ended_at=NOW(),duration_seconds=? WHERE id=? AND user_id=?')->execute([$end,$pages,$dur,$sid,$uid]);$db->prepare('UPDATE book_progress SET seconds_read=seconds_read+?,last_read_at=NOW() WHERE user_id=? AND book_id=?')->execute([$dur,$uid,$bookId]);}}
  $today=date('Y-m-d');$st=$db->prepare('SELECT last_read_date,current_streak,longest_streak,total_days_read FROM book_reading_streaks WHERE user_id=?');$st->execute([$uid]);$r=$st->fetch();if(!$r){$db->prepare('INSERT INTO book_reading_streaks (user_id,current_streak,longest_streak,total_days_read,last_read_date) VALUES (?,1,1,1,?)')->execute([$uid,$today]);}elseif($r['last_read_date']!==$today){$y=date('Y-m-d',strtotime('-1 day'));$cur=$r['last_read_date']===$y?(int)$r['current_streak']+1:1;$db->prepare('UPDATE book_reading_streaks SET current_streak=?,longest_streak=GREATEST(longest_streak,?),total_days_read=total_days_read+1,last_read_date=? WHERE user_id=?')->execute([$cur,$cur,$today,$uid]);}
  book_json(['success'=>true]);
}
if($action==='complete'){$bookId=(int)($_POST['book_id']??0);$db->prepare('UPDATE book_books SET reading_status="completed",completed_at=NOW() WHERE id=? AND user_id=?')->execute([$bookId,$uid]);book_json(['success'=>true]);}
book_json(['success'=>false,'message'=>'Unknown action'],400);
