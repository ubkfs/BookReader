<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

function book_goal_payload(): array {
    $gt = $_POST['goal_type'] ?? 'daily';
    $tt = $_POST['target_type'] ?? 'pages';
    $val = max(1, (int)($_POST['target_value'] ?? 0));
    $start = $_POST['start_date'] ?? date('Y-m-d');
    $end = ($_POST['end_date'] ?? '') ?: null;
    $status = $_POST['status'] ?? 'active';
    if (!in_array($gt,['daily','weekly','monthly','yearly'],true)) $gt='daily';
    if (!in_array($tt,['pages','chapters','books','minutes'],true)) $tt='pages';
    if (!in_array($status,['active','completed','paused','failed'],true)) $status='active';
    return [$gt,$tt,$val,$start,$end,$status];
}

if ($action === 'create') {
    book_verify_csrf();
    [$gt,$tt,$val,$start,$end] = book_goal_payload();
    $st = $db->prepare('INSERT INTO book_reading_goals (user_id,goal_type,target_type,target_value,start_date,end_date) VALUES (?,?,?,?,?,?)');
    $st->execute([$uid,$gt,$tt,$val,$start,$end]);
    book_json(['success'=>true,'message'=>'Goal created successfully.']);
}

if ($action === 'update') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    [$gt,$tt,$val,$start,$end,$status] = book_goal_payload();
    $db->prepare('UPDATE book_reading_goals SET goal_type=?, target_type=?, target_value=?, start_date=?, end_date=?, status=? WHERE id=? AND user_id=?')->execute([$gt,$tt,$val,$start,$end,$status,$id,$uid]);
    book_json(['success'=>true,'message'=>'Goal updated.']);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM book_reading_goals WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_json(['success'=>true,'message'=>'Goal deleted.']);
}

if ($action === 'list') {
    $st = $db->prepare('SELECT * FROM book_reading_goals WHERE user_id=? ORDER BY created_at DESC');
    $st->execute([$uid]);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
