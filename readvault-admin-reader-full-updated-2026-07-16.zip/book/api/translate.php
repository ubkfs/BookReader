<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
book_verify_csrf();
book_rate_limit('translate', 50, 60);

$db = book_db();
$uid = book_user_id();
$text = trim($_POST['text'] ?? '');
$target = $_POST['target_language'] ?? 'hi';
$source = $_POST['source_language'] ?? 'auto';
$bookId = (int)($_POST['book_id'] ?? 0) ?: null;
$page = (int)($_POST['page_number'] ?? 0) ?: null;

if (!$text) book_json(['success'=>false,'message'=>'No text selected.']);
$allowed = ['en','es','fr','de','it','pt','ar','hi','bn','zh','ja','ko','tr','ru'];
if (!in_array($target, $allowed, true)) $target = 'en';
if (!in_array($source, array_merge(['auto'], $allowed), true)) $source = 'auto';
if ($bookId && !book_fetch_user_book($db, $bookId, $uid)) book_json(['success'=>false,'message'=>'Book not found.']);

function book_translate_http_json_post(string $url, array $payload, int $timeout = 12): array {
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json','Accept: application/json'],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'ReadVault/1.2 Translate'
        ]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        return [$code, $res, $err];
    }
    $ctx = stream_context_create(['http'=>['method'=>'POST','timeout'=>$timeout,'header'=>"Content-Type: application/json\r\nAccept: application/json\r\nUser-Agent: ReadVault/1.2\r\n",'content'=>$body]]);
    $res = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $code = (int)$m[1];
    return [$code, $res, ''];
}

function book_translate_http_get_json(string $url, int $timeout = 12): array {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>$timeout, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_USERAGENT=>'ReadVault/1.2 Translate', CURLOPT_HTTPHEADER=>['Accept: application/json']]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        return [$code, $res, $err];
    }
    $ctx = stream_context_create(['http'=>['timeout'=>$timeout,'header'=>"Accept: application/json\r\nUser-Agent: ReadVault/1.2\r\n"]]);
    $res = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $code = (int)$m[1];
    return [$code, $res, ''];
}

function book_translation_dictionary_summary(string $word): array {
    $word = book_normalize_quiz_word($word) ?: trim($word);
    if ($word === '') return [];
    $url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' . rawurlencode($word);
    [$code, $body] = book_translate_http_get_json($url, 8);
    if (!$body || $code < 200 || $code >= 300) return [];
    $data = json_decode($body, true);
    if (!$data || empty($data[0]['meanings'])) return [];
    $entry = $data[0];
    $firstMeaning = $entry['meanings'][0] ?? [];
    $firstDefinition = $firstMeaning['definitions'][0] ?? [];
    $synonyms = [];
    $antonyms = [];
    foreach (($entry['meanings'] ?? []) as $meaning) {
        $synonyms = array_merge($synonyms, $meaning['synonyms'] ?? []);
        $antonyms = array_merge($antonyms, $meaning['antonyms'] ?? []);
    }
    return [
        'meaning'=>$firstDefinition['definition'] ?? '',
        'simple_meaning'=>$firstDefinition['definition'] ?? '',
        'example_sentence'=>$firstDefinition['example'] ?? '',
        'part_of_speech'=>$firstMeaning['partOfSpeech'] ?? '',
        'synonyms'=>implode(', ', array_slice(array_values(array_unique($synonyms)), 0, 12)),
        'antonyms'=>implode(', ', array_slice(array_values(array_unique($antonyms)), 0, 12)),
        'pronunciation'=>$entry['phonetic'] ?? (($entry['phonetics'][0]['text'] ?? '') ?: '')
    ];
}

$translated = null;
$status = 'unavailable';
$provider = '';
$errors = [];

// 1) User-configured LibreTranslate endpoint, then common public endpoint fallback.
$st = $db->prepare('SELECT setting_value FROM book_settings WHERE user_id=? AND setting_key="libretranslate_endpoint"');
$st->execute([$uid]);
$userEndpoint = trim((string)$st->fetchColumn());
$endpoints = array_values(array_unique(array_filter([$userEndpoint, 'https://libretranslate.com/translate'])));

foreach ($endpoints as $endpoint) {
    $payload = ['q'=>$text, 'source'=>$source, 'target'=>$target, 'format'=>'text'];
    $apiKeyStmt = $db->prepare('SELECT setting_value FROM book_settings WHERE user_id=? AND setting_key="libretranslate_api_key"');
    $apiKeyStmt->execute([$uid]);
    $apiKey = trim((string)$apiKeyStmt->fetchColumn());
    if (str_starts_with($apiKey, 'enc:')) {
        $apiKey = (string)(book_decrypt(substr($apiKey, 4)) ?? '');
    }
    if ($apiKey !== '') $payload['api_key'] = $apiKey;

    [$code, $body, $err] = book_translate_http_json_post($endpoint, $payload);
    if ($body && $code >= 200 && $code < 300) {
        $json = json_decode($body, true);
        $translated = $json['translatedText'] ?? $json['translated_text'] ?? null;
        if ($translated) { $status='success'; $provider='LibreTranslate'; break; }
        $errors[] = 'LibreTranslate returned no translatedText';
    } else {
        $errors[] = 'LibreTranslate failed: HTTP '.$code.' '.$err;
    }
}

// 2) MyMemory fallback for short snippets in supported language pairs.
if (!$translated) {
    $pairs = [];
    if ($source !== 'auto') $pairs[] = $source.'|'.$target;
    if ($target === 'en') {
        $pairs = array_merge($pairs, ['hi|en','bn|en','en|en']);
    } else {
        $pairs = array_merge($pairs, ['en|'.$target, 'auto|'.$target]);
    }
    $pairs = array_values(array_unique($pairs));

    foreach ($pairs as $pair) {
        $url = 'https://api.mymemory.translated.net/get?q=' . rawurlencode(mb_substr($text, 0, 450, 'UTF-8')) . '&langpair=' . rawurlencode($pair);
        [$code, $body, $err] = book_translate_http_get_json($url);
        if ($body && $code >= 200 && $code < 300) {
            $json = json_decode($body, true);
            $candidate = $json['responseData']['translatedText'] ?? null;
            if ($candidate && mb_strtolower($candidate, 'UTF-8') !== mb_strtolower($text, 'UTF-8')) {
                $translated = $candidate;
                $status = 'success';
                $provider = 'MyMemory';
                break;
            }
            $errors[] = 'MyMemory pair '.$pair.' returned no useful translation';
        } else {
            $errors[] = 'MyMemory failed '.$pair.': HTTP '.$code.' '.$err;
        }
    }
}

$ins = $db->prepare('INSERT INTO book_translations (user_id,book_id,page_number,original_text,translated_text,source_language,target_language,provider,status) VALUES (?,?,?,?,?,?,?,?,?)');
$ins->execute([$uid,$bookId,$page,$text,$translated,$source,$target,$provider ?: 'none',$status]);

$savedToQuiz = false;
$quizWord = null;
$vocabularyId = null;
$notSavedReason = 'Only single translated words are added to Quiz Words. Sentences and phrases stay in translation history only.';

if ($translated) {
    $singleWord = book_normalize_quiz_word($text);
    if ($singleWord) {
        $quizWord = $singleWord;
        $dictionaryFields = book_translation_dictionary_summary($singleWord);

        // If the selected word is not English and the translation target is English, try dictionary details for the translated English word.
        if (!$dictionaryFields && $target === 'en') {
            $translatedWord = book_normalize_quiz_word($translated);
            if ($translatedWord) {
                $dictionaryFields = book_translation_dictionary_summary($translatedWord);
            }
        }

        $fields = array_merge($dictionaryFields, [
            'book_id'=>$bookId,
            'source_page'=>$page
        ]);

        if ($target === 'hi') {
            $fields['hindi_meaning'] = $translated;
        } elseif ($target === 'bn') {
            $fields['bengali_meaning'] = $translated;
        } elseif ($target === 'en') {
            if (empty($fields['meaning'])) $fields['meaning'] = $translated;
            if (empty($fields['simple_meaning'])) $fields['simple_meaning'] = $translated;
        }

        if (empty($fields['meaning']) && $target !== 'en') {
            $fields['meaning'] = $dictionaryFields['meaning'] ?? '';
        }
        if (empty($fields['simple_meaning']) && !empty($fields['meaning'])) {
            $fields['simple_meaning'] = $fields['meaning'];
        }

        $vocabularyId = book_upsert_vocabulary_word($db, $uid, $quizWord, $fields);
        $savedToQuiz = true;
        $notSavedReason = null;
    }
}

if (!$translated) {
    book_json([
        'success'=>false,
        'translated_text'=>null,
        'message'=>'Translation service is unavailable right now. Add a LibreTranslate endpoint/API key in Settings or try a shorter English text.',
        'saved_to_quiz'=>false,
        'quiz_save_reason'=>$notSavedReason,
        'errors'=>array_slice($errors, 0, 3)
    ]);
}

book_json([
    'success'=>true,
    'translated_text'=>$translated,
    'provider'=>$provider,
    'saved_to_quiz'=>$savedToQuiz,
    'quiz_word'=>$quizWord,
    'vocabulary_id'=>$vocabularyId,
    'quiz_save_reason'=>$notSavedReason
]);
