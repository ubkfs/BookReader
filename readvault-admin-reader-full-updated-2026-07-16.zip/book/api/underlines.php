<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

if ($action === 'list') {
    $bookId = (int)($_GET['book_id'] ?? 0);
    $st = $db->prepare('SELECT * FROM book_underlines WHERE user_id=? AND book_id=? ORDER BY created_at DESC');
    $st->execute([$uid,$bookId]);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

if ($action === 'create') {
    book_verify_csrf();
    $bookId = (int)($_POST['book_id'] ?? 0);
    $page = (int)($_POST['page_number'] ?? 0);
    $text = trim($_POST['selected_text'] ?? '');
    $style = $_POST['underline_style'] ?? 'single';
    $color = $_POST['color'] ?? 'yellow';
    if (!book_fetch_user_book($db,$bookId,$uid) || !$text) book_json(['success'=>false,'message'=>'Invalid underline.']);
    if (!in_array($style,['single','double','dotted'],true)) $style='single';
    $st = $db->prepare('INSERT INTO book_underlines (user_id,book_id,page_number,selected_text,underline_style,color) VALUES (?,?,?,?,?,?)');
    $st->execute([$uid,$bookId,$page,$text,$style,$color]);
    book_json(['success'=>true,'id'=>(int)$db->lastInsertId()]);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM book_underlines WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_json(['success'=>true,'message'=>'Underline deleted.']);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
