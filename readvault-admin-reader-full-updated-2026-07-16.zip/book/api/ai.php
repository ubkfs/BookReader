<?php
require_once __DIR__ . '/../includes/bootstrap.php'; book_require_login(); book_verify_csrf(); book_rate_limit('book_ai', 20, 60);
$db=book_db();$uid=book_user_id();$action=$_GET['action']??'ask-book';
$provider=$_POST['provider']??'openrouter';
$stmt=$db->prepare('SELECT encrypted_key FROM book_api_keys WHERE user_id=? AND provider=? AND is_active=1');$stmt->execute([$uid,$provider]);$enc=$stmt->fetchColumn();
if(!$enc) book_json(['success'=>false,'ai_available'=>false,'message'=>'AI features are disabled. Add your own API key in Settings.']);
$key=book_decrypt($enc); if(!$key) book_json(['success'=>false,'message'=>'Could not decrypt API key. Save it again.']);
$question=trim($_POST['question']??$_POST['prompt']??'');$bookId=(int)($_POST['book_id']??0);$context='';
if($bookId && book_fetch_user_book($db,$bookId,$uid)){$st=$db->prepare('SELECT text_content FROM book_pages WHERE book_id=? ORDER BY page_number ASC LIMIT 8');$st->execute([$bookId]);$context=implode("\n",array_column($st->fetchAll(PDO::FETCH_ASSOC),'text_content'));}
$prompt="You are a helpful book tutor. Use the context if available.\n\nContext:\n".substr($context,0,12000)."\n\nUser request:\n".$question;
if(!$question) book_json(['success'=>false,'message'=>'Question is required.']);
$result=null;
if(in_array($provider,['openai','deepseek','openrouter'],true)){
    $endpoint=$provider==='openai'?'https://api.openai.com/v1/chat/completions':($provider==='deepseek'?'https://api.deepseek.com/chat/completions':'https://openrouter.ai/api/v1/chat/completions');
    $model=$provider==='openai'?'gpt-4o-mini':($provider==='deepseek'?'deepseek-chat':'openai/gpt-4o-mini');
    $payload=json_encode(['model'=>$model,'messages'=>[['role'=>'system','content'=>'Explain books clearly and concisely.'],['role'=>'user','content'=>$prompt]],'temperature'=>0.3]);
    $ch=curl_init($endpoint);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>25]);$body=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode($body,true);if($code>=200&&$code<300)$result=$json['choices'][0]['message']['content']??null;
}
if($provider==='gemini'){
    $endpoint='https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key='.rawurlencode($key);
    $payload=json_encode(['contents'=>[['parts'=>[['text'=>$prompt]]]]]);$ch=curl_init($endpoint);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>25]);$body=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode($body,true);if($code>=200&&$code<300)$result=$json['candidates'][0]['content']['parts'][0]['text']??null;
}
if(!$result) book_json(['success'=>false,'message'=>'AI request failed. Check your API key/provider.']);
book_json(['success'=>true,'answer'=>$result]);
