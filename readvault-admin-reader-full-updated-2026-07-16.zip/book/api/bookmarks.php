<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

if ($action === 'list') {
    $bookId = (int)($_GET['book_id'] ?? 0);
    $sql = 'SELECT * FROM book_bookmarks WHERE user_id=?';
    $p = [$uid];
    if ($bookId) { $sql .= ' AND book_id=?'; $p[] = $bookId; }
    $sql .= ' ORDER BY created_at DESC';
    $st = $db->prepare($sql);
    $st->execute($p);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

if ($action === 'create') {
    book_verify_csrf();
    $bookId = (int)($_POST['book_id'] ?? 0);
    $page = max(1, (int)($_POST['page_number'] ?? 1));
    $name = trim($_POST['name'] ?? ('Page '.$page));
    $type = $_POST['type'] ?? 'page';
    if (!book_fetch_user_book($db, $bookId, $uid)) book_json(['success'=>false,'message'=>'Book not found.']);
    $allowed = ['page','chapter','revision','important','formula','interview','custom'];
    if (!in_array($type, $allowed, true)) $type = 'page';
    $st = $db->prepare('INSERT INTO book_bookmarks (user_id,book_id,page_number,location_value,name,type) VALUES (?,?,?,?,?,?)');
    $st->execute([$uid,$bookId,$page,trim((string)($_POST['location_value']??''))?:null,$name,$type]);
    book_json(['success'=>true,'id'=>(int)$db->lastInsertId(),'message'=>'Bookmark saved.']);
}

if ($action === 'update') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $page = max(1, (int)($_POST['page_number'] ?? 1));
    $name = trim($_POST['name'] ?? 'Bookmark');
    $type = $_POST['type'] ?? 'page';
    $allowed = ['page','chapter','revision','important','formula','interview','custom'];
    if (!in_array($type, $allowed, true)) $type = 'page';
    $db->prepare('UPDATE book_bookmarks SET page_number=?, name=?, type=? WHERE id=? AND user_id=?')->execute([$page,$name,$type,$id,$uid]);
    book_json(['success'=>true,'message'=>'Bookmark updated.']);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM book_bookmarks WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_json(['success'=>true,'message'=>'Bookmark deleted.']);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
