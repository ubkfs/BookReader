<?php
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$action = $_GET['action'] ?? 'list';

if ($action === 'list') {
    $st = $db->prepare('SELECT * FROM book_books WHERE user_id=? ORDER BY uploaded_at DESC');
    $st->execute([$uid]);
    book_json(['success'=>true,'items'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
}

if ($action === 'update') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $book = book_fetch_user_book($db,$id,$uid);
    if (!$book) book_json(['success'=>false,'message'=>'Book not found.']);
    $title = trim($_POST['title'] ?? $book['title']);
    $author = trim($_POST['author'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $status = $_POST['reading_status'] ?? $book['reading_status'];
    if (!in_array($status,['not_started','reading','completed','archived'],true)) $status = $book['reading_status'];
    if (!$title) book_json(['success'=>false,'message'=>'Title is required.']);
    $db->prepare('UPDATE book_books SET title=?, author=?, category=?, reading_status=?, completed_at=IF(?="completed" AND completed_at IS NULL,NOW(),completed_at) WHERE id=? AND user_id=?')->execute([$title,$author,$category,$status,$status,$id,$uid]);
    book_json(['success'=>true,'message'=>'Book updated.']);
}

if ($action === 'delete') {
    book_verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $book = book_fetch_user_book($db,$id,$uid);
    if (!$book) book_json(['success'=>false,'message'=>'Book not found.']);
    $path = BOOK_MODULE_DIR.'/'.ltrim($book['file_path'],'/');
    if (is_file($path)) @unlink($path);
    $db->prepare('DELETE FROM book_books WHERE id=? AND user_id=?')->execute([$id,$uid]);
    book_log('book_deleted','book',$id);
    book_json(['success'=>true,'message'=>'Book deleted.']);
}

book_json(['success'=>false,'message'=>'Unknown action'],400);
