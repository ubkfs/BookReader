<?php
require_once __DIR__.'/../includes/bootstrap.php'; book_require_login();
if($_SERVER['REQUEST_METHOD']!=='POST') book_json(['success'=>false,'message'=>'Method not allowed'],405); book_verify_csrf(); book_rate_limit('wishlist',30,60);
$data=json_decode(file_get_contents('php://input'),true)?:$_POST; $bookId=(int)($data['book_id']??0);$action=(string)($data['action']??'add');
if(!$bookId)book_json(['success'=>false,'message'=>'Invalid book'],422);$db=book_db();$uid=book_user_id();
$st=$db->prepare('SELECT id FROM book_books WHERE id=? AND is_published=1');$st->execute([$bookId]);if(!$st->fetchColumn())book_json(['success'=>false,'message'=>'Book not found'],404);
if($action==='remove'){$db->prepare('DELETE FROM book_wishlists WHERE user_id=? AND book_id=?')->execute([$uid,$bookId]);book_json(['success'=>true,'message'=>'Removed from wishlist']);}
$db->prepare('INSERT IGNORE INTO book_wishlists(user_id,book_id) VALUES(?,?)')->execute([$uid,$bookId]);book_json(['success'=>true,'message'=>'Added to wishlist']);
