<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (!book_is_logged_in()) {
    book_render_header('Online Library and PWA eBook Reader','home','Read PDF and EPUB books online with highlights, notes, synchronized progress, offline reading, focus tools and flexible subscriptions.');
    ?>
    <main id="main-content">
      <section class="landing-hero"><div class="landing-wrap"><span class="book-chip">Independent reading platform</span><h1>Your books, notes, and reading progress in one private space.</h1><p>Read PDF and EPUB books online, save highlights and notes, continue across devices, use voice reading and focus tools, and keep selected books available offline through an installable PWA.</p><div class="book-actions" style="margin-top:24px"><a class="book-btn" href="<?= book_url('auth/register.php') ?>">Start reading free</a><a class="book-btn secondary" href="<?= book_url('subscription/plans.php') ?>">View subscriptions</a><a class="book-btn secondary" href="<?= book_url('blog/index.php') ?>">Reading journal</a></div></div></section>
      <section class="book-app" style="padding-top:52px"><div class="landing-wrap"><div class="book-grid"><article class="book-card book-span-4"><span class="admin-module-icon">📖</span><h3>Kindle-style reader</h3><p class="book-muted">Fullscreen, scroll or page modes, dark, sepia and high-contrast themes, typography controls, bookmarks, highlights, notes, and estimated time left.</p></article><article class="book-card book-span-4"><span class="admin-module-icon">↻</span><h3>Progress everywhere</h3><p class="book-muted">Synchronize last location, reading time, goals, streaks, devices, vocabulary, and revision material across signed-in sessions.</p></article><article class="book-card book-span-4"><span class="admin-module-icon">↓</span><h3>Installable and offline</h3><p class="book-muted">Install on Android, tablet, or desktop. Save entitled books in IndexedDB and keep the screen awake during active reading.</p></article><article class="book-card book-span-6"><h2>Built for readers and study</h2><ul class="feature-list"><li>PDF and EPUB secure signed streaming</li><li>Text-to-speech with voice, speed and pitch controls</li><li>Private notes, highlights, bookmarks and exports</li><li>Reading goals, focus timer, ambient sound and challenges</li><li>Dyslexia-friendly typography and keyboard navigation</li></ul></article><article class="book-card book-span-6"><h2>Built as an independent SaaS</h2><ul class="feature-list"><li>Dedicated authentication, sessions, database and storage</li><li>Country pricing, trials, coupons, subscriptions and invoices</li><li>Stripe and Razorpay adapters with signed webhooks</li><li>Family profiles, recommendations, referrals and gift architecture</li><li>Admin analytics, feature flags, SEO, blog and system health</li></ul></article></div></div></section>
    </main>
    <?php book_render_footer(); exit;
}

$db = book_db();
$userId = book_user_id();
if (!$db || !book_table_exists($db, 'book_books')) {
    book_render_header('ReadVault Setup', 'book-dashboard');
    echo '<main class="book-app"><div class="book-shell">'; include __DIR__.'/includes/sidebar.php';
    echo '<section class="book-content"><div class="book-card"><h1>ReadVault needs database setup</h1><p class="book-muted">Import <code>book/database/schema.sql</code> in phpMyAdmin, or open the installer below.</p><a class="book-btn" href="'.book_url('install.php').'">Run Installer</a></div></section></div></main>';
    book_render_footer(); exit;
}
$stats = ['books'=>0,'completed'=>0,'reading'=>0,'pages'=>0,'seconds'=>0,'vocab'=>0,'highlights'=>0];
$stmt=$db->prepare('SELECT COUNT(*) FROM book_books WHERE user_id=?');$stmt->execute([$userId]);$stats['books']=(int)$stmt->fetchColumn();
$stmt=$db->prepare("SELECT COUNT(*) FROM book_books WHERE user_id=? AND reading_status='completed'");$stmt->execute([$userId]);$stats['completed']=(int)$stmt->fetchColumn();
$stmt=$db->prepare("SELECT COUNT(*) FROM book_books WHERE user_id=? AND reading_status IN ('reading','not_started')");$stmt->execute([$userId]);$stats['reading']=(int)$stmt->fetchColumn();
$stmt=$db->prepare('SELECT COALESCE(SUM(pages_read),0), COALESCE(SUM(duration_seconds),0) FROM book_reading_sessions WHERE user_id=?');$stmt->execute([$userId]);[$stats['pages'],$stats['seconds']]=$stmt->fetch(PDO::FETCH_NUM) ?: [0,0];
$stmt=$db->prepare('SELECT COUNT(*) FROM book_vocabulary WHERE user_id=?');$stmt->execute([$userId]);$stats['vocab']=(int)$stmt->fetchColumn();
$stmt=$db->prepare('SELECT COUNT(*) FROM book_highlights WHERE user_id=?');$stmt->execute([$userId]);$stats['highlights']=(int)$stmt->fetchColumn();
$stmt=$db->prepare('SELECT * FROM book_books WHERE user_id=? ORDER BY last_opened_at DESC, uploaded_at DESC LIMIT 6');$stmt->execute([$userId]);$recentBooks=$stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt=$db->prepare('SELECT * FROM book_reading_goals WHERE user_id=? AND status="active" ORDER BY created_at DESC LIMIT 4');$stmt->execute([$userId]);$goals=$stmt->fetchAll(PDO::FETCH_ASSOC);
book_render_header('ReadVault Dashboard', 'book-dashboard');
?>
<main class="book-app">
  <div class="book-shell">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <section class="book-content">
      <div class="book-topbar">
        <div class="book-title"><h1>Book Dashboard</h1><p>Continue reading, revise highlights, and track your progress.</p></div>
        <div class="book-actions"><a class="book-btn" href="<?= book_url('upload.php') ?>">Upload Book</a><a class="book-btn secondary" href="<?= book_url('vault.php') ?>">Knowledge Vault</a></div>
      </div>
      <div class="book-grid">
        <div class="book-card book-stat"><span class="book-muted">Books Uploaded</span><strong><?= (int)$stats['books'] ?></strong></div>
        <div class="book-card book-stat"><span class="book-muted">Completed</span><strong><?= (int)$stats['completed'] ?></strong></div>
        <div class="book-card book-stat"><span class="book-muted">Pages Read</span><strong><?= (int)$stats['pages'] ?></strong></div>
        <div class="book-card book-stat"><span class="book-muted">Vocabulary</span><strong><?= (int)$stats['vocab'] ?></strong></div>
        <div class="book-card book-span-8" id="continue-reading">
          <h3>Continue Reading</h3>
          <?php if (!$recentBooks): ?><p class="book-muted">No books yet. Upload your first PDF or EPUB.</p><?php endif; ?>
          <div class="book-grid">
            <?php foreach($recentBooks as $b): $pct=$b['total_pages']?min(100,round($b['current_page']/$b['total_pages']*100)):0; ?>
              <div class="book-card book-span-6" style="box-shadow:none">
                <span class="book-chip"><?= book_e($b['category'] ?: 'Book') ?></span>
                <h3><?= book_e($b['title']) ?></h3>
                <p class="book-muted"><?= book_e($b['author'] ?: 'Unknown author') ?></p>
                <div class="book-progress"><span style="width:<?= $pct ?>%"></span></div>
                <p class="book-muted">Page <?= (int)$b['current_page'] ?> of <?= (int)$b['total_pages'] ?> · <?= $pct ?>%</p>
                <a class="book-btn small" href="<?= book_url('reader.php?id='.(int)$b['id']) ?>">Resume</a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="book-card book-span-4">
          <h3>Active Goals</h3>
          <?php if (!$goals): ?><p class="book-muted">Create a reading goal to build consistency.</p><a class="book-btn small" href="<?= book_url('goals.php') ?>">Create Goal</a><?php endif; ?>
          <?php foreach($goals as $g): ?><div class="book-kv-item"><strong><?= book_e(ucfirst($g['goal_type'])) ?> goal</strong><p class="book-muted"><?= (int)$g['target_value'] ?> <?= book_e($g['target_type']) ?></p></div><?php endforeach; ?>
        </div>
        <div class="book-card book-span-12">
          <h3>Revision Snapshot</h3>
          <p class="book-muted">You have <?= (int)$stats['highlights'] ?> saved highlights and <?= (int)$stats['vocab'] ?> vocabulary words ready for revision.</p>
          <div class="book-actions"><a class="book-btn secondary" href="<?= book_url('revision.php') ?>">Open Revision Dashboard</a><a class="book-btn secondary" href="<?= book_url('vocabulary.php') ?>">Practice Vocabulary</a></div>
        </div>
      </div>
    </section>
  </div>
</main>
<?php book_render_footer(true); ?>
