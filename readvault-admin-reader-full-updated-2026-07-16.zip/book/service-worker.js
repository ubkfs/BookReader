const VERSION='readvault-v2.3.0';
const STATIC_CACHE=`${VERSION}-static`;
const PAGE_CACHE=`${VERSION}-pages`;
const basePath=new URL(self.registration.scope).pathname.replace(/\/$/,'');
const at=(path)=>`${basePath}/${String(path).replace(/^\//,'')}`;
const APP_SHELL=[at('offline.html'),at('assets/css/book.css'),at('assets/js/app.js'),at('assets/js/pwa.js'),at('assets/js/offline-library.js'),at('assets/js/speech.js'),at('assets/js/reader-enhancements.js'),at('assets/icons/icon-192.png'),at('assets/icons/icon-512.png')];
self.addEventListener('install',event=>{event.waitUntil(caches.open(STATIC_CACHE).then(cache=>cache.addAll(APP_SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>!k.startsWith(VERSION)).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET')return;
  const url=new URL(request.url);
  if(url.origin===location.origin&&(url.pathname.endsWith('/view-pdf.php')||url.pathname.includes('/webhooks/')||url.pathname.includes('/payments/')))return;
  if(request.mode==='navigate'){
    event.respondWith(fetch(request).then(response=>{const copy=response.clone();caches.open(PAGE_CACHE).then(c=>c.put(request,copy));return response;}).catch(async()=>await caches.match(request)||await caches.match(at('offline.html'))));
    return;
  }
  const staticLike=['style','script','font','image','worker'].includes(request.destination)||url.hostname==='cdn.jsdelivr.net'||url.hostname==='cdnjs.cloudflare.com';
  if(staticLike){event.respondWith(caches.match(request).then(cached=>{const network=fetch(request).then(response=>{if(response.ok||response.type==='opaque')caches.open(STATIC_CACHE).then(c=>c.put(request,response.clone()));return response;}).catch(()=>cached);return cached||network;}));}
});
self.addEventListener('sync',event=>{if(event.tag==='readvault-progress-sync')event.waitUntil(Promise.resolve());});
