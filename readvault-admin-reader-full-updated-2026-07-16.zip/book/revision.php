<?php require_once __DIR__.'/includes/bootstrap.php'; book_require_login(); $_GET['type']='all'; include __DIR__.'/vault.php'; ?>
