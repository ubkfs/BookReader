<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$all = isset($_GET['all']) && $_GET['all']==='1';
book_auth()?->logout($all);
header('Location: '.book_url('auth/login.php'));exit;
