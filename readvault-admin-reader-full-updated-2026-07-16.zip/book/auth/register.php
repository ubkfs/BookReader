<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (book_is_logged_in()) { header('Location: ' . book_url('index.php')); exit; }
$error='';$verificationLink='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    book_verify_csrf(); book_rate_limit('register', 5, 3600);
    if ((string)($_POST['password']??'') !== (string)($_POST['password_confirmation']??'')) $error='Passwords do not match.';
    else {
        $result=book_auth()?->register((string)($_POST['name']??''),(string)($_POST['email']??''),(string)($_POST['password']??''));
        if($result&&$result['success']){
            $verificationLink=book_url('auth/verify-email.php?token='.rawurlencode($result['verification_token']));
            book_flash('success','Account created. You may log in now. Please verify your email from the verification message.');
            if(BOOK_CONFIG['app']['env']==='production') {
                book_send_template((string)$_POST['email'],'verify_email',[
                    'name'=>(string)($_POST['name']??'Reader'),
                    'verification_url'=>$verificationLink,
                    'expires_at'=>date('F j, Y g:i A',time()+86400),
                ],'en',[
                    'subject'=>'Verify your ReadVault email',
                    'html'=>'<h1>Verify your email</h1><p>Activate your ReadVault account by opening this secure link:</p><p><a href="{{verification_url}}">Verify email address</a></p>',
                    'text'=>'Verify your email: {{verification_url}}',
                ]);
                header('Location: '.book_url('auth/login.php')); exit;
            }
        } else $error=$result['message']??'Registration failed.';
    }
}
book_render_header('Create account','auth-register');
?>
<main class="auth-page"><section class="auth-card"><h1>Create your ReadVault account</h1><p class="book-muted">Independent login, subscription, devices, and reading history.</p>
<?php if($error):?><div class="alert alert-danger"><?=book_e($error)?></div><?php endif;?>
<?php if($verificationLink):?><div class="alert alert-success">Account created. Development verification link: <a href="<?=book_e($verificationLink)?>">verify email</a>.</div><?php endif;?>
<form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>">
<label class="book-label">Full name</label><input class="book-input" name="name" autocomplete="name" required maxlength="150">
<label class="book-label">Email</label><input class="book-input" type="email" name="email" autocomplete="email" required>
<label class="book-label">Password</label><input class="book-input" type="password" name="password" autocomplete="new-password" minlength="10" required><small class="book-muted">At least 10 characters.</small>
<label class="book-label">Confirm password</label><input class="book-input" type="password" name="password_confirmation" autocomplete="new-password" minlength="10" required>
<label class="form-check"><input class="form-check-input" type="checkbox" required><span class="form-check-label">I agree to the Terms and Privacy Policy.</span></label>
<button class="book-btn w-100 justify-content-center">Create account</button></form><div class="auth-links"><a href="<?=book_url('auth/login.php')?>">Already registered? Log in</a></div></section></main>
<?php book_render_footer(); ?>
