<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (book_is_logged_in()) { header('Location: ' . book_url('index.php')); exit; }
$error='';
$redirect = book_safe_redirect((string)($_GET['redirect'] ?? $_POST['redirect'] ?? book_url('index.php')));
if ($_SERVER['REQUEST_METHOD']==='POST') {
    book_verify_csrf(); book_rate_limit('login', 8, 900);
    $result = book_auth()?->attempt((string)($_POST['email']??''),(string)($_POST['password']??''),!empty($_POST['remember']));
    if ($result && $result['success']) { header('Location: '.$redirect); exit; }
    $error = $result['message'] ?? 'Login failed.';
}
book_render_header('Log in','auth-login','Log in to your independent ReadVault account.');
?>
<main class="auth-page"><section class="auth-card"><div class="auth-brand"><span class="brand-mark">R</span><div><h1>Welcome back</h1><p>Continue reading on any device.</p></div></div>
<?php if($error):?><div class="alert alert-danger"><?=book_e($error)?></div><?php endif;?>
<?php if($m=book_flash('success')):?><div class="alert alert-success"><?=book_e($m)?></div><?php endif;?>
<form method="post" class="book-form">
<input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>"><input type="hidden" name="redirect" value="<?=book_e($redirect)?>">
<label class="book-label">Email</label><input class="book-input" type="email" name="email" autocomplete="email" required>
<label class="book-label">Password</label><input class="book-input" type="password" name="password" autocomplete="current-password" required>
<label class="form-check"><input class="form-check-input" type="checkbox" name="remember" value="1"><span class="form-check-label">Remember this device for 30 days</span></label>
<button class="book-btn w-100 justify-content-center">Log in</button></form>
<div class="auth-links"><a href="<?=book_url('auth/forgot-password.php')?>">Forgot password?</a><a href="<?=book_url('auth/register.php')?>">Create account</a></div>
<div class="future-login"><button class="book-btn secondary w-100" disabled>Google login · ready for OAuth keys</button><button class="book-btn secondary w-100" disabled>Apple login · ready for OAuth keys</button></div>
</section></main><?php book_render_footer(); ?>
