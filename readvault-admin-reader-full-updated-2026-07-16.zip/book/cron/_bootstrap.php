<?php
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
$cli=PHP_SAPI==='cli';$token=(string)($_GET['token']??'');$secret=(string)BOOK_CONFIG['security']['cron_secret'];
if(!$cli&&($secret===''||!hash_equals($secret,$token))){http_response_code(403);exit('Forbidden');}
if(!$cli)header('Content-Type: text/plain; charset=utf-8');
