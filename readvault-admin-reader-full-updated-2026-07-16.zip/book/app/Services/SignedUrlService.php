<?php
declare(strict_types=1);
namespace BookSaaS\Services;

final class SignedUrlService
{
    public function __construct(private string $secret) {}

    public function sign(array $claims, int $ttl = 900): string
    {
        $claims['exp'] = time() + $ttl;
        $claims['nonce'] = bin2hex(random_bytes(8));
        $payload = rtrim(strtr(base64_encode(json_encode($claims, JSON_UNESCAPED_SLASHES)), '+/', '-_'), '=');
        $signature = rtrim(strtr(base64_encode(hash_hmac('sha256', $payload, $this->secret, true)), '+/', '-_'), '=');
        return $payload . '.' . $signature;
    }

    public function verify(string $token): ?array
    {
        [$payload, $signature] = array_pad(explode('.', $token, 2), 2, '');
        if ($payload === '' || $signature === '') return null;
        $expected = rtrim(strtr(base64_encode(hash_hmac('sha256', $payload, $this->secret, true)), '+/', '-_'), '=');
        if (!hash_equals($expected, $signature)) return null;
        $json = base64_decode(strtr($payload, '-_', '+/'), true);
        $claims = $json ? json_decode($json, true) : null;
        if (!is_array($claims) || (int)($claims['exp'] ?? 0) < time()) return null;
        return $claims;
    }
}
