<?php
declare(strict_types=1);
namespace BookSaaS\Services;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use RuntimeException;
use Throwable;

final class PaymentFulfillmentService
{
    public function __construct(private PDO $db) {}

    /** Atomically captures an order, records coupon use, replaces the active entitlement, and issues an invoice. */
    public function fulfill(int $orderId,string $provider,string $providerPaymentId,array $raw=[]): bool
    {
        $stmt=$this->db->prepare('SELECT o.*,p.duration_days,p.trial_days,p.is_lifetime,p.grace_period_days FROM book_orders o JOIN book_subscription_plans p ON p.id=o.plan_id WHERE o.id=? LIMIT 1');
        $stmt->execute([$orderId]);
        $order=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$order)return false;

        $captured=$this->db->prepare('SELECT id FROM book_payments WHERE order_id=? AND status="captured" LIMIT 1');
        $captured->execute([$orderId]);
        if($captured->fetchColumn())return true;

        try{
            $this->db->beginTransaction();

            if(!empty($order['coupon_id'])){
                $coupon=$this->db->prepare('SELECT id,max_redemptions,per_user_limit FROM book_coupons WHERE id=? AND is_active=1 FOR UPDATE');
                $coupon->execute([(int)$order['coupon_id']]);
                $couponRow=$coupon->fetch(PDO::FETCH_ASSOC);
                if(!$couponRow)throw new RuntimeException('Coupon is no longer active.');
                $total=$this->db->prepare('SELECT COUNT(*) FROM book_coupon_redemptions WHERE coupon_id=?');
                $total->execute([(int)$couponRow['id']]);
                if((int)$couponRow['max_redemptions']>0 && (int)$total->fetchColumn()>=(int)$couponRow['max_redemptions'])throw new RuntimeException('Coupon redemption limit reached.');
                $userCount=$this->db->prepare('SELECT COUNT(*) FROM book_coupon_redemptions WHERE coupon_id=? AND user_id=?');
                $userCount->execute([(int)$couponRow['id'],(int)$order['user_id']]);
                if((int)$userCount->fetchColumn()>=max(1,(int)$couponRow['per_user_limit']))throw new RuntimeException('Per-user coupon limit reached.');
            }

            $this->db->prepare('UPDATE book_orders SET status="paid",updated_at=NOW() WHERE id=?')->execute([$orderId]);
            $this->db->prepare('INSERT INTO book_payments (order_id,user_id,provider,provider_payment_id,status,amount_minor,currency,raw_response,paid_at) VALUES (?,?,?,? ,"captured",?,?,?,NOW()) ON DUPLICATE KEY UPDATE status="captured",raw_response=VALUES(raw_response),paid_at=NOW()')
                ->execute([$orderId,$order['user_id'],$provider,$providerPaymentId,$order['total_minor'],$order['currency'],json_encode($raw,JSON_UNESCAPED_SLASHES)]);

            if(!empty($order['coupon_id'])){
                $exists=$this->db->prepare('SELECT id FROM book_coupon_redemptions WHERE coupon_id=? AND user_id=? AND order_id=? LIMIT 1');
                $exists->execute([(int)$order['coupon_id'],(int)$order['user_id'],$orderId]);
                if(!$exists->fetchColumn()){
                    $this->db->prepare('INSERT INTO book_coupon_redemptions (coupon_id,user_id,order_id) VALUES (?,?,?)')->execute([(int)$order['coupon_id'],(int)$order['user_id'],$orderId]);
                }
            }

            $this->db->prepare('UPDATE book_subscriptions SET status="expired",ends_at=LEAST(COALESCE(ends_at,NOW()),NOW()) WHERE user_id=? AND status IN ("active","trialing","grace")')->execute([$order['user_id']]);
            $now=new DateTimeImmutable('now',new DateTimeZone('UTC'));
            $endsAt=null;
            if(!(int)$order['is_lifetime'])$endsAt=$now->modify('+'.max(1,(int)$order['duration_days']).' days')->format('Y-m-d H:i:s');
            $isTrial=(int)$order['trial_days']>0;
            $status=$isTrial?'trialing':'active';
            $trialEnds=$isTrial?$now->modify('+'.(int)$order['trial_days'].' days')->format('Y-m-d H:i:s'):null;
            $graceEnds=$endsAt&&((int)$order['grace_period_days']>0)?(new DateTimeImmutable($endsAt,new DateTimeZone('UTC')))->modify('+'.(int)$order['grace_period_days'].' days')->format('Y-m-d H:i:s'):null;
            $this->db->prepare('INSERT INTO book_subscriptions (user_id,plan_id,status,starts_at,ends_at,trial_ends_at,grace_ends_at,auto_renew,payment_provider,provider_subscription_id) VALUES (?,?,?,NOW(),?,?,?,0,?,?)')
                ->execute([$order['user_id'],$order['plan_id'],$status,$endsAt,$trialEnds,$graceEnds,$provider,$providerPaymentId]);
            if($isTrial)$this->db->prepare('UPDATE book_users SET trial_used_at=COALESCE(trial_used_at,NOW()) WHERE id=?')->execute([$order['user_id']]);

            $invoice='INV-'.date('Ymd').'-'.str_pad((string)$orderId,7,'0',STR_PAD_LEFT);
            $this->db->prepare('INSERT IGNORE INTO book_invoices (invoice_number,order_id,user_id,status,currency,subtotal_minor,discount_minor,tax_minor,total_minor) VALUES (?,?,? ,"paid",?,?,?,?,?)')
                ->execute([$invoice,$orderId,$order['user_id'],$order['currency'],$order['subtotal_minor'],$order['discount_minor'],$order['tax_minor'],$order['total_minor']]);
            $this->db->commit();
            return true;
        }catch(Throwable $e){
            if($this->db->inTransaction())$this->db->rollBack();
            error_log('ReadVault fulfillment error: '.$e->getMessage());
            return false;
        }
    }
}
