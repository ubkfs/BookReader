<?php
declare(strict_types=1);
namespace BookSaaS\Services;

use Throwable;

final class MailService
{
    public function __construct(private array $config, private bool $debug = false) {}

    /** Send a transactional HTML email through configured SMTP or PHP mail(). */
    public function send(string $to, string $subject, string $html, string $text = ''): bool
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
        if (($this->config['driver'] ?? 'mail') === 'smtp' && class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            try {
                $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = (string)$this->config['host'];
                $mail->Port = (int)$this->config['port'];
                $mail->SMTPAuth = ($this->config['username'] ?? '') !== '';
                $mail->Username = (string)($this->config['username'] ?? '');
                $mail->Password = (string)($this->config['password'] ?? '');
                $enc = (string)($this->config['encryption'] ?? 'tls');
                if ($enc !== '') $mail->SMTPSecure = $enc;
                $mail->CharSet = 'UTF-8';
                $mail->setFrom((string)$this->config['from_address'], (string)$this->config['from_name']);
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $html;
                $mail->AltBody = $text !== '' ? $text : trim(strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $html)));
                return $mail->send();
            } catch (Throwable $e) {
                error_log('ReadVault SMTP error: '.$e->getMessage());
                if (!$this->debug) return false;
            }
        }
        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'From: '.($this->config['from_name'] ?? 'ReadVault').' <'.($this->config['from_address'] ?? 'noreply@example.com').'>',
        ];
        return @mail($to, $subject, $html, implode("\r\n", $headers));
    }
}
