<?php
declare(strict_types=1);
namespace BookSaaS\Services;

use PDO;

final class CouponService
{
    public function __construct(private PDO $db) {}

    /**
     * Validate a coupon against the current user, plan, country and currency,
     * then calculate the discount in the payment gateway's minor units.
     */
    public function quote(string $code, int $userId, int $planId, int $amountMinor, string $currency, string $countryCode): array
    {
        $code = strtoupper(trim($code));
        $currency = strtoupper(trim($currency));
        $countryCode = strtoupper(trim($countryCode));
        if ($code === '') return ['success'=>true,'coupon'=>null,'discount_minor'=>0,'message'=>''];

        $st = $this->db->prepare('SELECT * FROM book_coupons WHERE code=? AND is_active=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) LIMIT 1');
        $st->execute([$code]);
        $coupon = $st->fetch(PDO::FETCH_ASSOC);
        if (!$coupon) return ['success'=>false,'message'=>'Coupon is invalid, inactive, or expired.'];

        $planIds = json_decode((string)($coupon['plan_ids_json'] ?? ''), true);
        if (is_array($planIds) && $planIds && !in_array($planId, array_map('intval', $planIds), true)) {
            return ['success'=>false,'message'=>'This coupon does not apply to the selected plan.'];
        }

        $countries = json_decode((string)($coupon['country_codes_json'] ?? ''), true);
        if (is_array($countries) && $countries && !in_array($countryCode, array_map(static fn($v)=>strtoupper((string)$v), $countries), true)) {
            return ['success'=>false,'message'=>'This coupon is not available in your country.'];
        }

        $max = (int)($coupon['max_redemptions'] ?? 0);
        if ($max > 0) {
            $count = $this->db->prepare('SELECT COUNT(*) FROM book_coupon_redemptions WHERE coupon_id=?');
            $count->execute([(int)$coupon['id']]);
            if ((int)$count->fetchColumn() >= $max) return ['success'=>false,'message'=>'This coupon has reached its redemption limit.'];
        }

        $perUser = max(1, (int)($coupon['per_user_limit'] ?? 1));
        $count = $this->db->prepare('SELECT COUNT(*) FROM book_coupon_redemptions WHERE coupon_id=? AND user_id=?');
        $count->execute([(int)$coupon['id'], $userId]);
        if ((int)$count->fetchColumn() >= $perUser) return ['success'=>false,'message'=>'You have already used this coupon.'];

        $type = (string)$coupon['discount_type'];
        $value = max(0, (float)$coupon['discount_value']);
        $discount = 0;
        if ($type === 'percent') {
            if ($value <= 0 || $value > 100) return ['success'=>false,'message'=>'This coupon has an invalid percentage.'];
            $discount = (int)round($amountMinor * ($value / 100));
        } elseif ($type === 'fixed') {
            $couponCurrency = strtoupper(trim((string)($coupon['currency'] ?? '')));
            if ($couponCurrency !== '' && $couponCurrency !== $currency) {
                return ['success'=>false,'message'=>'This coupon is valid only for '.$couponCurrency.' payments.'];
            }
            $discount = \book_money_to_minor($value, $currency);
        } else {
            return ['success'=>false,'message'=>'This coupon type is not supported at checkout.'];
        }

        return [
            'success'=>true,
            'coupon'=>$coupon,
            'discount_minor'=>min($amountMinor, max(0, $discount)),
            'message'=>'Coupon applied.',
        ];
    }
}
