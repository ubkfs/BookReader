<?php
declare(strict_types=1);
namespace BookSaaS\Services;

use PDO;
use Throwable;

final class FeatureFlagService
{
    public function __construct(private PDO $db, private array $defaults = [], private int $userId = 0) {}

    /** Resolve a flag and apply deterministic per-user percentage rollout. */
    public function enabled(string $key, bool $fallback = false): bool
    {
        try {
            $stmt = $this->db->prepare('SELECT is_enabled,rollout_percent FROM book_feature_flags WHERE flag_key=? LIMIT 1');
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            if ($row) {
                if (!(bool)$row['is_enabled']) return false;
                $percent=max(0,min(100,(int)$row['rollout_percent']));
                if($percent>=100)return true;
                if($percent<=0||$this->userId<=0)return false;
                $bucket=(int)sprintf('%u',crc32($key.':'.$this->userId))%100;
                return $bucket<$percent;
            }
        } catch (Throwable) {}
        return (bool)($this->defaults[$key] ?? $fallback);
    }
}
