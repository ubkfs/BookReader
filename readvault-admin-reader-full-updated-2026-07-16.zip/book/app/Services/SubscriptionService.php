<?php
declare(strict_types=1);
namespace BookSaaS\Services;

use PDO;

final class SubscriptionService
{
    public function __construct(private PDO $db) {}

    public function current(int $userId): ?array
    {
        $sql = 'SELECT s.*,p.code,p.name,p.duration_days,p.book_limit,p.offline_limit,p.family_profiles,p.features_json,
                       NULL family_owner_user_id,NULL family_profile_id,0 shared_via_family
                FROM book_subscriptions s JOIN book_subscription_plans p ON p.id=s.plan_id
                WHERE s.user_id=? AND s.status IN ("active","trialing","grace")
                AND (s.ends_at IS NULL OR s.ends_at>NOW() OR (s.grace_ends_at IS NOT NULL AND s.grace_ends_at>NOW()))
                ORDER BY s.id DESC LIMIT 1';
        $stmt = $this->db->prepare($sql); $stmt->execute([$userId]);
        $own = $stmt->fetch();
        if ($own) return $own;

        // A linked family member keeps a separate login, notes and reading history,
        // while inheriting the household owner's active subscription entitlement.
        $familySql = 'SELECT s.*,p.code,p.name,p.duration_days,p.book_limit,p.offline_limit,p.family_profiles,p.features_json,
                             fa.owner_user_id family_owner_user_id,fp.id family_profile_id,1 shared_via_family
                      FROM book_family_profiles fp
                      JOIN book_family_accounts fa ON fa.id=fp.family_account_id
                      JOIN book_subscriptions s ON s.user_id=fa.owner_user_id
                      JOIN book_subscription_plans p ON p.id=s.plan_id
                      WHERE fp.linked_user_id=? AND s.status IN ("active","trialing","grace")
                      AND (s.ends_at IS NULL OR s.ends_at>NOW() OR (s.grace_ends_at IS NOT NULL AND s.grace_ends_at>NOW()))
                      ORDER BY s.id DESC LIMIT 1';
        $stmt = $this->db->prepare($familySql); $stmt->execute([$userId]);
        return $stmt->fetch() ?: null;
    }

    public function planCode(int $userId): string { return (string)($this->current($userId)['code'] ?? 'free'); }
    public function isPremium(int $userId): bool { return !in_array($this->planCode($userId), ['free'], true); }
    public function bookLimit(int $userId): int { return (int)($this->current($userId)['book_limit'] ?? 10); }
    public function canAccessCatalogBook(int $userId): bool { return $this->isPremium($userId); }
}
