<?php
declare(strict_types=1);
namespace BookSaaS\Core;

use PDO;
use Throwable;

final class Auth
{
    public function __construct(private PDO $db, private array $config) {}

    public function user(): ?array
    {
        static $user = false;
        if ($user !== false) return $user ?: null;
        $id = (int)($_SESSION['user_id'] ?? 0);
        if (!$id) return null;
        if (!empty($_SESSION['device_id'])) {
            $device = $this->db->prepare('SELECT revoked_at FROM book_user_devices WHERE id=? AND user_id=? LIMIT 1');
            $device->execute([(int)$_SESSION['device_id'],$id]);
            $revoked = $device->fetchColumn();
            if ($revoked !== false && $revoked !== null) { $this->logout(false); return null; }
        }
        $stmt = $this->db->prepare('SELECT id,name,email,role,status,email_verified_at,locale,timezone,country_code,avatar_path,trial_used_at,created_at FROM book_users WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row || $row['status'] !== 'active') {
            $this->logout(false);
            return null;
        }
        $user = $row;
        return $row;
    }

    public function check(): bool { return $this->user() !== null; }

    public function attempt(string $email, string $password, bool $remember = false): array
    {
        $email = mb_strtolower(trim($email));
        $attempts = max(1,(int)($this->config['security']['login_attempts'] ?? 5));
        $lockMinutes = max(1,(int)($this->config['security']['login_lock_minutes'] ?? 15));
        $lock = $this->db->prepare('SELECT COUNT(*) FROM book_login_history WHERE success=0 AND created_at>=DATE_SUB(NOW(),INTERVAL ? MINUTE) AND (email=? OR ip_address=?)');
        $lock->execute([$lockMinutes,$email,$this->ip()]);
        if ((int)$lock->fetchColumn() >= $attempts) return ['success'=>false,'message'=>'Too many failed attempts. Try again later.'];
        $stmt = $this->db->prepare('SELECT * FROM book_users WHERE email=? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, (string)$user['password_hash'])) {
            $this->recordLogin(null, $email, false, 'invalid_credentials');
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }
        if ($user['status'] !== 'active') {
            $this->recordLogin((int)$user['id'], $email, false, 'account_' . $user['status']);
            return ['success' => false, 'message' => 'This account is not active.'];
        }
        if (password_needs_rehash((string)$user['password_hash'], PASSWORD_DEFAULT)) {
            $this->db->prepare('UPDATE book_users SET password_hash=? WHERE id=?')->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['auth_time'] = time();
        $_SESSION['device_id'] = $this->upsertDevice((int)$user['id']);
        $this->db->prepare('UPDATE book_users SET last_login_at=NOW(), last_login_ip=? WHERE id=?')->execute([$this->ip(), $user['id']]);
        $this->recordLogin((int)$user['id'], $email, true, null);
        if ($remember) $this->issueRememberToken((int)$user['id']);
        return ['success' => true, 'user' => $user];
    }

    public function register(string $name, string $email, string $password): array
    {
        $name = trim($name);
        $email = mb_strtolower(trim($email));
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
            return ['success' => false, 'message' => 'Use a valid name, email, and a password of at least 10 characters.'];
        }
        $stmt = $this->db->prepare('SELECT id FROM book_users WHERE email=?');
        $stmt->execute([$email]);
        if ($stmt->fetchColumn()) return ['success' => false, 'message' => 'An account already exists for this email.'];
        try {
            $this->db->beginTransaction();
            $this->db->prepare('INSERT INTO book_users (name,email,password_hash,role,status,locale,timezone) VALUES (?,?,?,"reader","active",?,?)')
                ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $this->config['app']['locale'], $this->config['app']['timezone']]);
            $id = (int)$this->db->lastInsertId();
            $freePlan = $this->db->query("SELECT id FROM book_subscription_plans WHERE code='free' LIMIT 1")->fetchColumn();
            if ($freePlan) {
                $this->db->prepare('INSERT INTO book_subscriptions (user_id,plan_id,status,starts_at,auto_renew) VALUES (?, ?, "active", NOW(), 0)')->execute([$id, $freePlan]);
            }
            $this->db->prepare('INSERT INTO book_reading_streaks (user_id) VALUES (?)')->execute([$id]);
            $token = bin2hex(random_bytes(32));
            $this->db->prepare('INSERT INTO book_email_verification_tokens (user_id,token_hash,expires_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 24 HOUR))')->execute([$id, hash('sha256', $token)]);
            $this->db->commit();
            return ['success' => true, 'user_id' => $id, 'verification_token' => $token];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            return ['success' => false, 'message' => 'Registration could not be completed.'];
        }
    }

    public function logout(bool $allDevices = false): void
    {
        $userId = (int)($_SESSION['user_id'] ?? 0);
        if ($userId) {
            if ($allDevices) {
                $this->db->prepare('UPDATE book_user_devices SET revoked_at=NOW() WHERE user_id=? AND revoked_at IS NULL')->execute([$userId]);
                $this->db->prepare('DELETE FROM book_remember_tokens WHERE user_id=?')->execute([$userId]);
            } elseif (!empty($_SESSION['device_id'])) {
                $this->db->prepare('UPDATE book_user_devices SET last_seen_at=NOW() WHERE id=? AND user_id=?')->execute([$_SESSION['device_id'], $userId]);
            }
        }
        setcookie('readvault_remember', '', ['expires' => time() - 3600, 'path' => $this->config['session']['path'], 'secure' => $this->config['session']['secure'], 'httponly' => true, 'samesite' => $this->config['session']['same_site']]);
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
    }

    public function restoreRememberedLogin(): void
    {
        if ($this->check() || empty($_COOKIE['readvault_remember'])) return;
        $parts = explode(':', (string)$_COOKIE['readvault_remember'], 2);
        if (count($parts) !== 2) return;
        [$selector, $validator] = $parts;
        $stmt = $this->db->prepare('SELECT * FROM book_remember_tokens WHERE selector=? AND expires_at>NOW() LIMIT 1');
        $stmt->execute([$selector]);
        $token = $stmt->fetch();
        if (!$token || !hash_equals((string)$token['validator_hash'], hash('sha256', $validator))) return;
        $_SESSION['user_id'] = (int)$token['user_id'];
        $_SESSION['device_id'] = $this->upsertDevice((int)$token['user_id']);
        $this->issueRememberToken((int)$token['user_id']);
        $this->db->prepare('DELETE FROM book_remember_tokens WHERE id=?')->execute([$token['id']]);
    }

    private function issueRememberToken(int $userId): void
    {
        $selector = bin2hex(random_bytes(8));
        $validator = bin2hex(random_bytes(32));
        $days = (int)$this->config['security']['remember_days'];
        $this->db->prepare('INSERT INTO book_remember_tokens (user_id,selector,validator_hash,expires_at) VALUES (?,?,?,DATE_ADD(NOW(),INTERVAL ? DAY))')
            ->execute([$userId, $selector, hash('sha256', $validator), $days]);
        setcookie('readvault_remember', $selector . ':' . $validator, [
            'expires' => time() + ($days * 86400), 'path' => $this->config['session']['path'],
            'secure' => $this->config['session']['secure'], 'httponly' => true, 'samesite' => $this->config['session']['same_site']
        ]);
    }

    private function upsertDevice(int $userId): int
    {
        $fingerprint = hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . substr($this->ip(), 0, 20));
        $stmt = $this->db->prepare('SELECT id,revoked_at FROM book_user_devices WHERE user_id=? AND fingerprint=? LIMIT 1');
        $stmt->execute([$userId, $fingerprint]);
        $row = $stmt->fetch();
        if ($row) {
            $this->db->prepare('UPDATE book_user_devices SET last_seen_at=NOW(),ip_address=?,user_agent=?,revoked_at=NULL WHERE id=?')->execute([$this->ip(), $_SERVER['HTTP_USER_AGENT'] ?? '', $row['id']]);
            return (int)$row['id'];
        }
        $this->db->prepare('INSERT INTO book_user_devices (user_id,fingerprint,device_name,device_type,ip_address,user_agent,last_seen_at) VALUES (?,?,?,?,?,?,NOW())')
            ->execute([$userId, $fingerprint, $this->deviceName(), $this->deviceType(), $this->ip(), $_SERVER['HTTP_USER_AGENT'] ?? '']);
        return (int)$this->db->lastInsertId();
    }

    private function recordLogin(?int $userId, string $email, bool $success, ?string $reason): void
    {
        try {
            $this->db->prepare('INSERT INTO book_login_history (user_id,email,success,failure_reason,ip_address,user_agent,created_at) VALUES (?,?,?,?,?,?,NOW())')
                ->execute([$userId, $email, $success ? 1 : 0, $reason, $this->ip(), $_SERVER['HTTP_USER_AGENT'] ?? '']);
        } catch (Throwable) {}
    }

    private function ip(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'); }
    private function deviceType(): string { $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? ''); return str_contains($ua, 'mobile') ? 'mobile' : (str_contains($ua, 'tablet') || str_contains($ua, 'ipad') ? 'tablet' : 'desktop'); }
    private function deviceName(): string { return ucfirst($this->deviceType()) . ' browser'; }
}
