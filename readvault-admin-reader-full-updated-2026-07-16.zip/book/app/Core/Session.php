<?php
declare(strict_types=1);
namespace BookSaaS\Core;

final class Session
{
    public static function start(array $config): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) return;
        session_name($config['name']);
        session_set_cookie_params([
            'lifetime' => $config['lifetime'] * 60,
            'path' => $config['path'],
            'secure' => $config['secure'],
            'httponly' => $config['http_only'],
            'samesite' => $config['same_site'],
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');
        session_start();
        $last = (int)($_SESSION['_last_regeneration'] ?? 0);
        if ($last === 0 || time() - $last > $config['regenerate_interval']) {
            session_regenerate_id(true);
            $_SESSION['_last_regeneration'] = time();
        }
    }
}
