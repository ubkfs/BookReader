<?php
declare(strict_types=1);
namespace BookSaaS\Core;

use PDO;
use PDOException;

final class Database
{
    private static ?PDO $connection = null;

    public static function connection(array $config): PDO
    {
        if (self::$connection instanceof PDO) return self::$connection;
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $config['host'], $config['port'], $config['name'], $config['charset']);
        try {
            self::$connection = new PDO($dsn, $config['username'], $config['password'], $config['options']);
        } catch (PDOException $e) {
            throw new PDOException('ReadVault database connection failed. Check /book/.env and database permissions.', (int)$e->getCode(), $e);
        }
        return self::$connection;
    }
}
