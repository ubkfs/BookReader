<?php
declare(strict_types=1);
namespace BookSaaS\Payments;

interface PaymentGatewayInterface
{
    public function createCheckout(array $order): array;
    public function verifyWebhook(string $payload, string $signature): bool;
    public function parseWebhook(string $payload): array;
}
