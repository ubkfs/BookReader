<?php
declare(strict_types=1);
namespace BookSaaS\Payments;

final class StripeGateway implements PaymentGatewayInterface
{
    public function __construct(private array $config) {}

    public function createCheckout(array $order): array
    {
        if ($this->config['secret_key'] === '') return ['success'=>false,'message'=>'Stripe is not configured.'];
        $fields = [
            'mode' => 'payment',
            'success_url' => $order['success_url'],
            'cancel_url' => $order['cancel_url'],
            'client_reference_id' => (string)$order['order_id'],
            'customer_email' => $order['customer_email'],
            'line_items[0][quantity]' => '1',
            'line_items[0][price_data][currency]' => strtolower($order['currency']),
            'line_items[0][price_data][unit_amount]' => (string)$order['amount_minor'],
            'line_items[0][price_data][product_data][name]' => $order['description'],
            'metadata[order_id]' => (string)$order['order_id'],
            'metadata[user_id]' => (string)$order['user_id'],
            'metadata[plan_id]' => (string)$order['plan_id'],
        ];
        $ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
        curl_setopt_array($ch, [CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($fields),CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPAUTH=>CURLAUTH_BASIC,CURLOPT_USERPWD=>$this->config['secret_key'].':',CURLOPT_TIMEOUT=>25]);
        $body = curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$error=curl_error($ch);curl_close($ch);
        $data=json_decode((string)$body,true)?:[];
        if($status<200||$status>=300) return ['success'=>false,'message'=>$data['error']['message']??($error?:'Stripe request failed.'),'response'=>$data];
        return ['success'=>true,'checkout_url'=>$data['url']??null,'provider_order_id'=>$data['id']??null,'response'=>$data];
    }

    public function verifyWebhook(string $payload, string $signature): bool
    {
        $secret=$this->config['webhook_secret'];if($secret===''||$signature==='')return false;
        $parts=[];foreach(explode(',',$signature) as $item){[$k,$v]=array_pad(explode('=',$item,2),2,'');$parts[$k][]=$v;}
        $timestamp=(int)($parts['t'][0]??0);if(!$timestamp||abs(time()-$timestamp)>300)return false;
        $expected=hash_hmac('sha256',$timestamp.'.'.$payload,$secret);
        foreach($parts['v1']??[] as $candidate)if(hash_equals($expected,$candidate))return true;
        return false;
    }
    public function parseWebhook(string $payload): array { return json_decode($payload,true)?:[]; }
}
