<?php
declare(strict_types=1);
namespace BookSaaS\Payments;

final class RazorpayGateway implements PaymentGatewayInterface
{
    public function __construct(private array $config) {}
    public function createCheckout(array $order): array
    {
        if ($this->config['key_id'] === '' || $this->config['key_secret'] === '') return ['success'=>false,'message'=>'Razorpay is not configured.'];
        $payload=json_encode(['amount'=>(int)$order['amount_minor'],'currency'=>strtoupper($order['currency']),'receipt'=>(string)$order['order_number'],'notes'=>['order_id'=>(string)$order['order_id'],'user_id'=>(string)$order['user_id'],'plan_id'=>(string)$order['plan_id']]]);
        $ch=curl_init('https://api.razorpay.com/v1/orders');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_USERPWD=>$this->config['key_id'].':'.$this->config['key_secret'],CURLOPT_TIMEOUT=>25]);
        $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$error=curl_error($ch);curl_close($ch);$data=json_decode((string)$body,true)?:[];
        if($status<200||$status>=300)return['success'=>false,'message'=>$data['error']['description']??($error?:'Razorpay request failed.'),'response'=>$data];
        return['success'=>true,'provider_order_id'=>$data['id']??null,'key_id'=>$this->config['key_id'],'response'=>$data];
    }
    public function verifyWebhook(string $payload,string $signature): bool {if($this->config['webhook_secret']===''||$signature==='')return false;return hash_equals(hash_hmac('sha256',$payload,$this->config['webhook_secret']),$signature);}
    public function verifyPayment(string $orderId,string $paymentId,string $signature): bool {return hash_equals(hash_hmac('sha256',$orderId.'|'.$paymentId,$this->config['key_secret']),$signature);}
    public function parseWebhook(string $payload): array{return json_decode($payload,true)?:[];}
}
