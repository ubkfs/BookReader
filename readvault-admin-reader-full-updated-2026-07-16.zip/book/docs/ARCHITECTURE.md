# Architecture

## Independence boundary

The application root is the only bootstrap boundary. Every PHP entry point loads `includes/bootstrap.php`, which loads local `config/config.php`, local Composer autoloading, the local session, and the dedicated PDO connection. No include, redirect, asset, upload, download, AJAX, webhook, or cron path refers to the parent website.

## Layers

- **Presentation:** Bootstrap, Alpine.js, vanilla JavaScript, PDF.js, ePub.js, PWA and IndexedDB.
- **Application:** page controllers and authenticated API endpoints.
- **Domain services:** authentication, subscriptions, feature flags, signed URLs, payment fulfillment and mail.
- **Infrastructure:** PDO/MySQL, private file storage, payment APIs, SMTP, browser push extension points, cron jobs and queue table.

## Main request flows

### Authentication

The user registers in the local `book_users` table. Passwords use PHP's current `PASSWORD_DEFAULT`. Verification and reset links store only SHA-256 token hashes. Login regenerates the session ID, records history, fingerprints the browser session, and can issue a selector/validator remember token.

### Book upload

The upload endpoint checks plan limits, CSRF, rate limit, PHP upload status, size, extension, MIME, and file signature. It randomizes the filename, stores it in the user's private directory, records SHA-256, and creates a book record.

### Book read

The reader verifies the user and entitlement, creates a short-lived token containing user and book claims, and passes the token to `view-pdf.php`. The stream endpoint verifies all claims and uses Range responses for efficient PDF access. EPUB is returned to ePub.js as an authorized ArrayBuffer.

### Progress synchronization

The reader saves page or EPUB CFI location, percentage, device, reading session, duration, streak and last-opened data. Offline progress can be queued through the service-worker/background-sync extension point.

### Payment

Checkout creates a local order before contacting a gateway. The gateway returns a provider order/session identifier. Webhooks verify signatures and pass the local order to one atomic fulfillment service. Fulfillment captures the payment record, expires the previous entitlement, creates the new entitlement, records one-time trial use, and issues an invoice.

## Scaling path

For tens of thousands of users:

1. Place PHP behind a load balancer and store sessions in Redis.
2. Move private books to object storage with KMS encryption and short-lived signed origin requests.
3. Put static assets and public covers behind a CDN.
4. Run queue workers separately from web nodes.
5. Add Redis rate limits and cache hot catalog/search responses.
6. Use read replicas for analytics and reporting.
7. Partition or archive high-volume reading sessions, activity logs, search history and webhook records.
8. Export analytics into a warehouse rather than running large aggregations on the transactional database.
