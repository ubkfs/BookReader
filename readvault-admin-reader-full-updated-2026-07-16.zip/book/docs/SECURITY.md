# Security Model

## Controls included

- Secure, HTTP-only, SameSite session cookies
- Session ID regeneration after authentication
- Password hashing and rehashing
- Hashed verification, reset and remember-me tokens
- CSRF protection for state-changing browser requests
- Prepared PDO statements
- Contextual HTML escaping
- Login, API, upload, export and reader rate limits
- Device history and revocation
- HMAC-signed expiring book-stream tokens
- Ownership and subscription entitlement checks
- Private storage root validation
- Extension, MIME, signature, size and checksum checks
- CSP, HSTS, frame, content-type, referrer and permissions headers
- Signed Stripe and Razorpay webhook verification
- AES-256-GCM encryption for administrator-managed secrets
- Audit logs, webhook event storage, system health history and failed queue records

## Production improvements

The session rate limiter is suitable for a single node. Replace it with Redis or another shared atomic store before horizontal scaling. Place login throttling behind an IP/user-aware distributed limiter and consider CAPTCHA only after risk signals.

Use a secrets manager for `APP_KEY`, database passwords, SMTP credentials and gateway keys. Database-encrypted key storage is provided for managed hosting, but the application key must remain outside the database.

The default CSP permits the configured Bootstrap, Alpine, PDF.js, ePub.js and Razorpay CDN hosts. Self-host third-party libraries and remove those hosts for a stricter offline-first deployment.

Sanitize administrator-authored blog HTML with a trusted allowlist library before saving. The public article view treats stored content as trusted administrator HTML.

Add malware scanning, content disarm/reconstruction, OCR sandboxing and publisher-file review for public catalog ingestion. Never execute uploaded content.

## Copyright and DRM

Signed streaming prevents public file URLs and casual sharing. It is not equivalent to a certified commercial DRM system. Licensed publisher content may require KMS-backed encryption, forensic watermarking, license-server policy, device limits, revocation, screen-capture policy where legally and technically available, and a contractual takedown process.

## Backups

Backups should be encrypted, stored outside the web root and preferably outside the production account. Test restoration regularly. Do not consider a backup successful until a clean environment has been restored and validated.
