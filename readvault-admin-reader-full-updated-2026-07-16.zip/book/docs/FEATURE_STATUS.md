# Feature Status

## Implemented application paths

- Independent configuration, database, session and authentication
- Device and login management
- Subscription plans, country prices, coupons, trial-once enforcement, grace and invoice records
- Stripe and Razorpay one-time checkout/webhooks
- PDF/EPUB signed reader
- Wake Lock, focus, ambient audio, accessibility and reading preferences
- Notes, bookmarks, highlights, underlines, vocabulary and exports
- Progress, sessions, goals, streaks, badges, challenges and leaderboards
- Offline entitlement API, IndexedDB cache and PWA shell
- Search, recommendations, wishlist and price-alert storage
- Family profile limits
- Admin modules, feature flags, plans, encrypted payment settings and system health
- Public SEO landing, book details, reviews, blog, robots and sitemap
- Support tickets, notifications, queue and operational cron jobs

## Architecture and schema ready, requiring business-specific completion

- Provider-managed recurring subscriptions and dunning
- Automated upgrade/downgrade proration
- Gift checkout and recipient redemption user interface
- Affiliate payout settlement and fraud review
- Author and publisher self-service royalty/catalog workflows
- Commercial KMS-backed DRM and forensic watermark rendering
- Real push delivery provider integration
- Automated AI recommendation jobs and editorial controls
- Licensed book translation workflow and rights enforcement
- Tax nexus determination, VAT/GST evidence and statutory reporting
- Native PDF invoice rendering or jurisdiction-specific invoice templates
- Backup execution/restore UI and off-site storage integration
- Full moderation, advertisement delivery and royalty/reporting workflows
