# Validation Record

Validation performed on 2026-07-14 before packaging.

## Passed static and component checks

- PHP syntax lint across every PHP source file
- JavaScript syntax checks across application scripts and the service worker
- JSON parsing for `composer.json` and `manifest.json`
- Local literal route and asset reference scan with no missing targets
- Legacy parent-site import scan with no runtime imports from `teknouf.com`
- Direct private-storage URL scan with no public book-file links
- Dynamic session-path check based on `APP_URL`
- AES-256-GCM application secret encryption and decryption check
- HMAC signed reading-token creation, validation, expiry structure, and tamper-rejection check
- Internal redirect allowlist test, including rejection of protocol-relative and external redirects
- Baseline SQL statement split and quote-balance checks
- All 78 database tables begin with `book_` and have unique names
- Original column names preserved while table identifiers were renamed
- All 113 foreign-key references resolve to existing prefixed tables
- Static PHP SQL references resolve to the 78-table prefixed schema
- Baseline migration and installer schema contain identical table sets
- ZIP integrity test after packaging

## Deployment-dependent checks still required

This build environment did not provide a MySQL server, Composer executable, SMTP server, payment sandbox credentials, or a production web server. Before launch, run:

1. `composer install --no-dev --optimize-autoloader`
2. Installation against an empty MySQL 8 database
3. Stripe and Razorpay sandbox checkout and webhook tests
4. SMTP verification, reset-password, and expiry-message tests
5. Apache or Nginx private-storage denial tests
6. Android, tablet, desktop, PWA installation, offline, PDF, EPUB, text-to-speech, and Wake Lock acceptance tests
7. Subscription trial, coupon, expiry, grace-period, cancellation, and offline-revocation acceptance tests
8. Backup and restore drill

The platform documents commercial feature boundaries in `docs/FEATURE_STATUS.md` and `README.md`.
