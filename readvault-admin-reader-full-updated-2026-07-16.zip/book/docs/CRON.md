# Scheduled Jobs

Recommended crontab entries, adjusted to the real application path:

```cron
*/10 * * * * /usr/bin/php /var/www/services/book/cron/queue-worker.php 50 >> /var/log/readvault-queue.log 2>&1
15 * * * * /usr/bin/php /var/www/services/book/cron/subscription-expiry.php >> /var/log/readvault-subscriptions.log 2>&1
30 2 * * * /usr/bin/php /var/www/services/book/cron/cleanup.php >> /var/log/readvault-cleanup.log 2>&1
*/15 * * * * /usr/bin/php /var/www/services/book/cron/health-check.php >> /var/log/readvault-health.log 2>&1
```

CLI is preferred. Web invocation is allowed only when `CRON_SECRET` is configured:

```text
https://services.teknouf.com/book/cron/subscription-expiry.php?token=YOUR_SECRET
```

The subscription job sends expiry reminders, moves ended plans into grace or expired status, and revokes premium offline downloads when no premium entitlement remains.

The queue worker currently handles `email` and `notification` payloads. Add dedicated handlers for push delivery, translation, recommendation generation, exports, image optimization, backups and analytics aggregation.
