# Database Table Namespace

Every application table in this build starts with `book_`. The following four names use descriptive suffixes to avoid collisions with existing relationship or content tables:

- `authors` → `book_author_profiles` because `book_authors` is the book-to-author relationship table.
- `genres` → `book_genre_catalog` because `book_genres` is the book-to-genre relationship table.
- `notifications` → `book_user_notifications` because `book_notifications` is retained for reader compatibility.
- `translations` → `book_ui_translations` because `book_translations` stores reader/book translations.

## Complete mapping

| Original table | Namespaced table |
|---|---|
| `achievement_badges` | `book_achievement_badges` |
| `advertisements` | `book_advertisements` |
| `api_clients` | `book_api_clients` |
| `app_settings` | `book_app_settings` |
| `authors` | `book_author_profiles` |
| `backups` | `book_backups` |
| `blog_categories` | `book_blog_categories` |
| `blog_comments` | `book_blog_comments` |
| `blog_posts` | `book_blog_posts` |
| `book_activity_logs` | `book_activity_logs` |
| `book_api_keys` | `book_api_keys` |
| `book_authors` | `book_authors` |
| `book_bookmarks` | `book_bookmarks` |
| `book_books` | `book_books` |
| `book_categories` | `book_categories` |
| `book_chapters` | `book_chapters` |
| `book_downloads` | `book_downloads` |
| `book_exports` | `book_exports` |
| `book_genres` | `book_genres` |
| `book_highlights` | `book_highlights` |
| `book_notes` | `book_notes` |
| `book_notifications` | `book_notifications` |
| `book_pages` | `book_pages` |
| `book_progress` | `book_progress` |
| `book_reading_goals` | `book_reading_goals` |
| `book_reading_sessions` | `book_reading_sessions` |
| `book_reading_streaks` | `book_reading_streaks` |
| `book_settings` | `book_settings` |
| `book_translations` | `book_translations` |
| `book_underlines` | `book_underlines` |
| `book_vocabulary` | `book_vocabulary` |
| `challenge_participants` | `book_challenge_participants` |
| `collection_books` | `book_collection_books` |
| `collections` | `book_collections` |
| `coupon_redemptions` | `book_coupon_redemptions` |
| `coupons` | `book_coupons` |
| `email_templates` | `book_email_templates` |
| `email_verification_tokens` | `book_email_verification_tokens` |
| `family_accounts` | `book_family_accounts` |
| `family_profiles` | `book_family_profiles` |
| `feature_flags` | `book_feature_flags` |
| `genres` | `book_genre_catalog` |
| `gift_subscriptions` | `book_gift_subscriptions` |
| `invoices` | `book_invoices` |
| `jobs` | `book_jobs` |
| `login_history` | `book_login_history` |
| `notifications` | `book_user_notifications` |
| `orders` | `book_orders` |
| `password_reset_tokens` | `book_password_reset_tokens` |
| `payments` | `book_payments` |
| `permissions` | `book_permissions` |
| `plan_prices` | `book_plan_prices` |
| `publishers` | `book_publishers` |
| `push_subscriptions` | `book_push_subscriptions` |
| `reading_challenges` | `book_reading_challenges` |
| `recommendations` | `book_recommendations` |
| `referral_rewards` | `book_referral_rewards` |
| `referrals` | `book_referrals` |
| `remember_tokens` | `book_remember_tokens` |
| `reviews` | `book_reviews` |
| `role_permissions` | `book_role_permissions` |
| `roles` | `book_roles` |
| `schema_migrations` | `book_schema_migrations` |
| `search_history` | `book_search_history` |
| `seo_metadata` | `book_seo_metadata` |
| `subscription_events` | `book_subscription_events` |
| `subscription_plans` | `book_subscription_plans` |
| `subscriptions` | `book_subscriptions` |
| `support_ticket_messages` | `book_support_ticket_messages` |
| `support_tickets` | `book_support_tickets` |
| `system_health_checks` | `book_system_health_checks` |
| `tax_rates` | `book_tax_rates` |
| `translations` | `book_ui_translations` |
| `user_badges` | `book_user_badges` |
| `user_devices` | `book_user_devices` |
| `users` | `book_users` |
| `webhook_events` | `book_webhook_events` |
| `wishlists` | `book_wishlists` |
