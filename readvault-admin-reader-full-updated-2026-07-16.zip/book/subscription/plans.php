<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$country = strtoupper((string)(book_current_user()['country_code'] ?? 'US'));
$currency = book_resolve_billing_currency($db, $country, (string)($_GET['currency'] ?? ($_SESSION['book_billing_currency'] ?? '')));
$_SESSION['book_billing_currency'] = $currency;
$currencies = book_active_plan_currencies($db, $country);
$planRows = $db->query('SELECT * FROM book_subscription_plans WHERE is_active=1 ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
$plans = [];
foreach ($planRows as $row) {
    $row['selected_price'] = book_find_plan_price($db, (int)$row['id'], $country, $currency);
    $plans[] = $row;
}
$current = book_subscription();
book_render_header('Subscription plans','subscriptions','Choose a flexible ReadVault subscription plan.');
?>
<main class="book-app" id="main-content"><div class="book-shell">
<?php include BOOK_MODULE_DIR . '/includes/sidebar.php'; ?>
<section class="book-content">
  <div class="book-topbar">
    <div class="book-title"><h1>Choose your reading plan</h1><p>Country-aware prices, multi-currency checkout, coupons, renewals, grace periods, upgrades and downgrades.</p></div>
    <span class="book-pill">Current: <?= book_e($current['name'] ?? 'Free') ?></span>
  </div>
  <?php if ($currencies): ?>
  <form method="get" class="book-card book-actions currency-picker" style="margin-bottom:18px">
    <label class="book-label" for="billingCurrency">Display and pay in</label>
    <select id="billingCurrency" class="book-select" name="currency" onchange="this.form.submit()">
      <?php foreach ($currencies as $availableCurrency): ?><option value="<?= book_e($availableCurrency) ?>" <?= $availableCurrency === $currency ? 'selected' : '' ?>><?= book_e($availableCurrency) ?></option><?php endforeach; ?>
    </select>
    <noscript><button class="book-btn small">Change</button></noscript>
    <small class="book-muted">The list comes from active prices configured in Admin → Subscription Plans.</small>
  </form>
  <?php endif; ?>
  <div class="pricing-grid">
  <?php foreach ($plans as $plan):
      $features = json_decode((string)($plan['features_json'] ?? '{}'), true) ?: [];
      $price = $plan['selected_price'];
      $isCurrent = (int)($current['plan_id'] ?? 0) === (int)$plan['id'];
  ?>
    <article class="pricing-card <?= $isCurrent ? 'current' : '' ?>">
      <span class="book-chip"><?= book_e($plan['duration_days'] ? $plan['duration_days'].' days' : ($plan['is_lifetime'] ? 'Lifetime' : 'No expiry')) ?></span>
      <h2><?= book_e($plan['name']) ?></h2>
      <p class="book-muted"><?= book_e($plan['description']) ?></p>
      <div class="price"><?= $price ? book_e(book_format_money((int)$price['amount_minor'], (string)$price['currency'])) : 'Unavailable' ?></div>
      <?php if (!$price): ?><div class="book-alert warn">No active <?= book_e($currency) ?> price is configured for this plan.</div><?php endif; ?>
      <ul>
        <li><?= (int)$plan['book_limit'] >= 1000 ? 'Large' : 'Up to '.(int)$plan['book_limit'] ?> personal library</li>
        <li><?= (int)$plan['offline_limit'] ?> offline books</li>
        <li><?= (int)$plan['family_profiles'] ?> family profile<?= (int)$plan['family_profiles'] === 1 ? '' : 's' ?></li>
        <?php foreach (array_keys(array_filter($features)) as $feature): ?><li><?= book_e(ucwords(str_replace('_',' ',$feature))) ?></li><?php endforeach; ?>
      </ul>
      <?php if ($isCurrent): ?>
        <button class="book-btn secondary" disabled>Current plan</button>
      <?php elseif ($price): ?>
        <a class="book-btn" href="<?= book_url('subscription/checkout.php?plan='.(int)$plan['id'].'&currency='.rawurlencode((string)$price['currency'])) ?>"><?= (int)$price['amount_minor'] > 0 ? 'Choose plan' : 'Activate' ?></a>
      <?php else: ?>
        <button class="book-btn secondary" disabled>Price unavailable</button>
      <?php endif; ?>
    </article>
  <?php endforeach; ?>
  </div>
</section></div></main>
<?php book_render_footer(); ?>
