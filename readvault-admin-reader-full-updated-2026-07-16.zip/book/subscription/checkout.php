<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$planId = (int)($_GET['plan'] ?? $_POST['plan_id'] ?? 0);
$error = '';
$razorpay = null;
$couponCode = strtoupper(trim((string)($_POST['coupon'] ?? '')));
$country = strtoupper((string)(book_current_user()['country_code'] ?? 'US'));
$requestedCurrency = (string)($_GET['currency'] ?? $_POST['currency'] ?? ($_SESSION['book_billing_currency'] ?? ''));
$currency = book_resolve_billing_currency($db, $country, $requestedCurrency);
$_SESSION['book_billing_currency'] = $currency;

$st = $db->prepare('SELECT * FROM book_subscription_plans WHERE id=? AND is_active=1 LIMIT 1');
$st->execute([$planId]);
$plan = $st->fetch(PDO::FETCH_ASSOC);
$price = $plan ? book_find_plan_price($db, $planId, $country, $currency) : null;
if (!$plan || !$price) {
    http_response_code(404);
    exit('Plan or price not found for the selected currency. Configure this price in Admin → Subscription Plans.');
}
$plan = array_merge($plan, ['amount_minor'=>(int)$price['amount_minor'],'currency'=>(string)$price['currency'],'price_id'=>(int)$price['id']]);
$currency = strtoupper((string)$plan['currency']);
if ((int)$plan['trial_days'] > 0 && !empty(book_current_user()['trial_used_at'])) {
    http_response_code(409);
    exit('The free trial has already been used on this account.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    book_verify_csrf();
    $provider = in_array($_POST['provider'] ?? '', ['stripe','razorpay'], true) ? (string)$_POST['provider'] : 'stripe';
    $amount = (int)$plan['amount_minor'];
    $couponQuote = (new \BookSaaS\Services\CouponService($db))->quote($couponCode, $uid, $planId, $amount, $currency, $country);
    if (!$couponQuote['success']) {
        $error = (string)$couponQuote['message'];
    } else {
        $discount = (int)$couponQuote['discount_minor'];
        $couponId = !empty($couponQuote['coupon']['id']) ? (int)$couponQuote['coupon']['id'] : null;
        $total = max(0, $amount - $discount);
        $orderNo = 'RV-' . date('YmdHis') . '-' . random_int(1000, 9999);
        $db->prepare('INSERT INTO book_orders (order_number,user_id,plan_id,coupon_id,status,currency,subtotal_minor,discount_minor,total_minor,country_code,metadata) VALUES (?,?,?,? ,"pending",?,?,?,?,?,?)')
            ->execute([$orderNo,$uid,$planId,$couponId,$currency,$amount,$discount,$total,$country,json_encode(['price_id'=>(int)$price['id'],'coupon_code'=>$couponCode ?: null],JSON_UNESCAPED_SLASHES)]);
        $orderId = (int)$db->lastInsertId();

        if ($total <= 0) {
            $fulfilled = (new \BookSaaS\Services\PaymentFulfillmentService($db))->fulfill($orderId, 'free', 'free-'.$orderId, ['coupon'=>$couponCode ?: null]);
            if ($fulfilled) {
                header('Location: ' . book_url('subscription/success.php?order=' . $orderId));
                exit;
            }
            $db->prepare('UPDATE book_orders SET status="failed" WHERE id=?')->execute([$orderId]);
            $error = 'The free plan could not be activated. The coupon may have reached its usage limit; please try another code.';
        } else {
            $order = [
                'order_id'=>$orderId,'order_number'=>$orderNo,'user_id'=>$uid,'plan_id'=>$planId,
                'amount_minor'=>$total,'currency'=>$currency,'description'=>'ReadVault '.$plan['name'],
                'customer_email'=>(string)book_current_user()['email'],
                'success_url'=>book_url('subscription/success.php?order='.$orderId),
                'cancel_url'=>book_url('subscription/checkout.php?plan='.$planId.'&currency='.rawurlencode($currency).'&cancelled=1'),
            ];
            if ($provider === 'stripe') {
                $result = (new \BookSaaS\Payments\StripeGateway(book_payment_config('stripe')))->createCheckout($order);
                if ($result['success'] && !empty($result['checkout_url'])) {
                    $db->prepare('INSERT INTO book_payments (order_id,user_id,provider,provider_order_id,status,amount_minor,currency,raw_response) VALUES (?,? ,"stripe",? ,"created",?,?,?)')
                        ->execute([$orderId,$uid,$result['provider_order_id'],$total,$currency,json_encode($result['response'],JSON_UNESCAPED_SLASHES)]);
                    header('Location: ' . $result['checkout_url']);
                    exit;
                }
                $error = $result['message'] ?? 'Stripe checkout failed.';
            } else {
                $result = (new \BookSaaS\Payments\RazorpayGateway(book_payment_config('razorpay')))->createCheckout($order);
                if ($result['success']) {
                    $db->prepare('INSERT INTO book_payments (order_id,user_id,provider,provider_order_id,status,amount_minor,currency,raw_response) VALUES (?,? ,"razorpay",? ,"created",?,?,?)')
                        ->execute([$orderId,$uid,$result['provider_order_id'],$total,$currency,json_encode($result['response'],JSON_UNESCAPED_SLASHES)]);
                    $razorpay = ['key'=>$result['key_id'],'provider_order_id'=>$result['provider_order_id'],'amount'=>$total,'currency'=>$currency,'name'=>'ReadVault','description'=>$order['description'],'email'=>$order['customer_email'],'order_id'=>$orderId];
                } else {
                    $error = $result['message'] ?? 'Razorpay checkout failed.';
                }
            }
            if ($error) $db->prepare('UPDATE book_orders SET status="failed" WHERE id=? AND status="pending"')->execute([$orderId]);
        }
    }
}

book_render_header('Checkout', 'subscription-checkout');
?>
<main class="auth-page"><section class="auth-card checkout-card">
  <h1><?= book_e($plan['name']) ?></h1>
  <div class="checkout-total"><?= book_e(book_format_money((int)$plan['amount_minor'], $currency)) ?></div>
  <p><?= book_e($plan['description']) ?></p>
  <p class="book-muted">Billing currency: <strong><?= book_e($currency) ?></strong>. Prices are configured by the administrator; ReadVault does not silently apply live exchange-rate conversions.</p>
  <?php if (isset($_GET['cancelled'])): ?><div class="alert alert-warning">Payment was cancelled. Your plan was not changed.</div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger"><?= book_e($error) ?></div><?php endif; ?>
  <form method="post" class="book-form">
    <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>">
    <input type="hidden" name="plan_id" value="<?= (int)$planId ?>">
    <input type="hidden" name="currency" value="<?= book_e($currency) ?>">
    <label class="book-label">Coupon</label>
    <input class="book-input" name="coupon" value="<?= book_e($couponCode) ?>" placeholder="Optional coupon code">
    <small class="book-form-help">A valid 100% coupon activates the plan immediately without opening a payment gateway.</small>
    <label class="book-label">Payment gateway</label>
    <select class="book-select" name="provider"><option value="stripe">Stripe — broad international currency support</option><option value="razorpay">Razorpay — subject to your Razorpay account's enabled currencies</option></select>
    <button class="book-btn">Continue to secure payment</button>
  </form>
  <?php if ($razorpay): ?>
    <button id="rzpPay" class="book-btn mt-3 w-100">Open Razorpay checkout</button>
    <form id="rzpVerify" method="post" action="<?= book_url('payments/verify-razorpay.php') ?>">
      <input type="hidden" name="_csrf" value="<?= book_e(book_csrf_token()) ?>"><input type="hidden" name="local_order_id" value="<?= (int)$razorpay['order_id'] ?>"><input type="hidden" name="razorpay_payment_id"><input type="hidden" name="razorpay_order_id"><input type="hidden" name="razorpay_signature">
    </form>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
    const options=<?= json_encode(['key'=>$razorpay['key'],'amount'=>$razorpay['amount'],'currency'=>$razorpay['currency'],'name'=>$razorpay['name'],'description'=>$razorpay['description'],'order_id'=>$razorpay['provider_order_id'],'prefill'=>['email'=>$razorpay['email']]],JSON_UNESCAPED_SLASHES) ?>;
    options.handler=function(r){const f=document.getElementById('rzpVerify');f.razorpay_payment_id.value=r.razorpay_payment_id;f.razorpay_order_id.value=r.razorpay_order_id;f.razorpay_signature.value=r.razorpay_signature;f.submit()};
    document.getElementById('rzpPay').onclick=()=>new Razorpay(options).open();
    </script>
  <?php endif; ?>
</section></main>
<?php book_render_footer(); ?>
