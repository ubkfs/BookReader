<?php
require_once __DIR__.'/includes/bootstrap.php'; book_require_login();
$db=book_db(); $uid=book_user_id(); $q=trim((string)($_GET['q']??'')); $type=(string)($_GET['type']??'all'); $results=[];
if($q!==''){
  book_rate_limit('search',40,60);
  $like='%'.$q.'%';
  $where='b.is_published=1 AND (b.access_type="catalog" OR b.user_id=?) AND (b.title LIKE ? OR b.subtitle LIKE ? OR b.author LIKE ? OR b.description LIKE ? OR b.isbn10 LIKE ? OR b.isbn13 LIKE ? OR b.tags_json LIKE ?)';
  $params=[$uid,$like,$like,$like,$like,$like,$like,$like];
  if($type==='pdf'||$type==='epub'){ $where.=' AND b.file_type=?'; $params[]=$type; }
  $st=$db->prepare("SELECT b.*,p.name publisher_name,a.name primary_author_name FROM book_books b LEFT JOIN book_publishers p ON p.id=b.publisher_id LEFT JOIN book_author_profiles a ON a.id=b.primary_author_id WHERE $where ORDER BY (b.title LIKE ?) DESC,b.last_opened_at DESC,b.uploaded_at DESC LIMIT 80");
  $params[]=$q.'%'; $st->execute($params); $results=$st->fetchAll();
  $db->prepare('INSERT INTO book_search_history(user_id,query,results_count,country_code) VALUES(?,?,?,?)')->execute([$uid,mb_substr($q,0,255),count($results),book_current_user()['country_code']??null]);
}
$recent=$db->prepare('SELECT query,MAX(created_at) created_at FROM book_search_history WHERE user_id=? GROUP BY query ORDER BY created_at DESC LIMIT 8');$recent->execute([$uid]);
$trending=$db->query('SELECT query,COUNT(*) searches FROM book_search_history WHERE created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY query ORDER BY searches DESC LIMIT 8')->fetchAll();
book_render_header('Search books','book-search','Search books by title, author, publisher, genre, ISBN, keyword, tag, or content metadata.');
?>
<main class="book-app" id="main-content"><div class="book-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>Discover books</h1><p>Search your private library and the published catalog by title, author, ISBN, publisher, or keyword.</p></div></div>
<div class="book-card"><form method="get" class="book-form"><div class="book-actions"><input class="book-input" style="flex:1;min-width:220px" name="q" value="<?= book_e($q) ?>" placeholder="Search books, authors, ISBN, tags…" autofocus><select class="book-select" style="max-width:150px" name="type"><option value="all">All formats</option><option value="pdf" <?= $type==='pdf'?'selected':'' ?>>PDF</option><option value="epub" <?= $type==='epub'?'selected':'' ?>>EPUB</option></select><button class="book-btn">Search</button></div></form>
<?php if($recent->rowCount()): ?><div class="book-inline-actions"><span class="book-muted">Recent:</span><?php foreach($recent as $r): ?><a class="book-chip" href="?q=<?= rawurlencode($r['query']) ?>"><?= book_e($r['query']) ?></a><?php endforeach; ?></div><?php endif; ?></div>
<?php if($q!==''): ?><div class="book-topbar" style="margin-top:22px"><div><strong><?= count($results) ?></strong> results for “<?= book_e($q) ?>”</div></div><div class="book-grid"><?php foreach($results as $b): ?>
<article class="book-card book-span-4"><span class="book-chip"><?= book_e(strtoupper($b['file_type'])) ?></span><?php if($b['requires_subscription']): ?><span class="book-chip warn">Premium</span><?php endif; ?><h3><?= book_e($b['title']) ?></h3><p class="book-muted"><?= book_e($b['primary_author_name']?:$b['author']?:'Unknown author') ?><?= $b['publisher_name']?' · '.book_e($b['publisher_name']):'' ?></p><p><?= book_e(mb_substr(strip_tags((string)$b['description']),0,150)) ?><?= mb_strlen((string)$b['description'])>150?'…':'' ?></p><div class="book-actions"><a class="book-btn small" href="<?= book_url('reader.php?id='.(int)$b['id']) ?>">Open reader</a><?php if($b['access_type']==='catalog'): ?><button class="book-btn small secondary" type="button" onclick="wishlist(<?= (int)$b['id'] ?>)">Wishlist</button><?php endif; ?></div></article>
<?php endforeach; if(!$results): ?><div class="book-card book-span-12 book-empty"><div class="book-empty-icon">⌕</div><h3>No matching books</h3><p class="book-muted">Try a shorter keyword, ISBN fragment, author name, or another format.</p></div><?php endif; ?></div>
<?php else: ?><div class="book-grid" style="margin-top:18px"><div class="book-card book-span-8"><h3>Trending searches</h3><div class="book-inline-actions"><?php foreach($trending as $r): ?><a class="book-chip" href="?q=<?= rawurlencode($r['query']) ?>"><?= book_e($r['query']) ?> · <?= (int)$r['searches'] ?></a><?php endforeach; if(!$trending): ?><p class="book-muted">Search activity will appear here as readers explore the catalog.</p><?php endif; ?></div></div><div class="book-card book-span-4"><h3>Search tips</h3><p class="book-muted">Use an ISBN for an exact edition, a publisher name to browse a catalog, or a topic keyword to find relevant descriptions and tags.</p></div></div><?php endif; ?>
</section></div></main><script>async function wishlist(book_id){const r=await bookApi('api/wishlist.php',{book_id,action:'add'});alert(r.message||'Saved');}</script><?php book_render_footer(); ?>
