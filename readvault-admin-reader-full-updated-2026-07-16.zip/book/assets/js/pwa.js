(()=>{
  if(!('serviceWorker' in navigator))return;
  const path=(window.BOOK_BASE_PATH||new URL(window.BOOK_BASE_URL||location.origin,location.origin).pathname).replace(/\/$/,'');
  let deferredInstall=null;
  let banner=null;

  const installed=()=>window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true;
  const installButton=()=>document.getElementById('readvaultInstallBtn');
  function ensureBanner(){
    if(banner)return banner;
    banner=document.createElement('div');
    banner.className='readvault-install-banner';
    banner.hidden=true;
    banner.innerHTML='<div><strong>Install ReadVault</strong><p>Read in a full-screen app and keep your library one tap away.</p></div><div class="readvault-install-actions"><button type="button" class="book-btn small" data-install>Install app</button><button type="button" class="book-btn small secondary" data-dismiss>Later</button></div>';
    document.body.appendChild(banner);
    banner.querySelector('[data-install]')?.addEventListener('click',promptInstall);
    banner.querySelector('[data-dismiss]')?.addEventListener('click',()=>{banner.hidden=true;sessionStorage.setItem('readvault_install_dismissed','1');});
    return banner;
  }
  function showInstall(){
    if(installed()||!deferredInstall)return;
    const button=installButton();if(button)button.hidden=false;
    if(sessionStorage.getItem('readvault_install_dismissed')!=='1')ensureBanner().hidden=false;
  }
  function hideInstall(){
    const button=installButton();if(button)button.hidden=true;
    if(banner)banner.hidden=true;
  }
  async function promptInstall(){
    if(!deferredInstall)return;
    deferredInstall.prompt();
    try{await deferredInstall.userChoice;}catch(e){}
    deferredInstall=null;
    hideInstall();
  }

  window.addEventListener('beforeinstallprompt',event=>{
    event.preventDefault();
    deferredInstall=event;
    showInstall();
  });
  window.addEventListener('appinstalled',()=>{deferredInstall=null;hideInstall();});
  document.addEventListener('click',event=>{if(event.target?.id==='readvaultInstallBtn')promptInstall();});

  window.addEventListener('load',async()=>{
    try{
      const registration=await navigator.serviceWorker.register(`${path}/service-worker.js`,{scope:`${path}/`});
      registration.addEventListener('updatefound',()=>{
        const worker=registration.installing;
        worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller){window.dispatchEvent(new CustomEvent('readvault:update-ready',{detail:{registration}}));}});
      });
    }catch(error){console.warn('ReadVault service worker registration failed',error);}
  });
})();
