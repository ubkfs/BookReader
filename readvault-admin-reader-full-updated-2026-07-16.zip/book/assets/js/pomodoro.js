window.BookPomodoro = function(display, onDone){
  let timer=null, remaining=0;
  function render(){ const m=String(Math.floor(remaining/60)).padStart(2,'0'); const s=String(remaining%60).padStart(2,'0'); display.textContent=m+':'+s; }
  return {
    start(minutes){ remaining=minutes*60; render(); clearInterval(timer); timer=setInterval(()=>{ remaining--; render(); if(remaining<=0){ clearInterval(timer); if(onDone) onDone(); } },1000); },
    stop(){ clearInterval(timer); remaining=0; render(); },
    pause(){ clearInterval(timer); },
    resume(){ clearInterval(timer); timer=setInterval(()=>{ remaining--; render(); if(remaining<=0){ clearInterval(timer); if(onDone) onDone(); } },1000); }
  };
};
