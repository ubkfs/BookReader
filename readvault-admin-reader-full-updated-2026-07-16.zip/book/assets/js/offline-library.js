(function(){
  const DB='readvault-offline-v2', STORE='books';
  function open(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'bookId'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
  async function tx(mode,fn){const db=await open();return new Promise((resolve,reject)=>{const t=db.transaction(STORE,mode),s=t.objectStore(STORE);let result;try{result=fn(s);}catch(e){reject(e);return;}t.oncomplete=()=>resolve(result);t.onerror=()=>reject(t.error);});}
  window.ReadVaultOffline={
    async save(bookId,blob,meta={}){await tx('readwrite',s=>s.put({bookId:Number(bookId),blob,meta,savedAt:Date.now()}));return true;},
    async get(bookId){const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).get(Number(bookId));r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error);});},
    async remove(bookId){await tx('readwrite',s=>s.delete(Number(bookId)));},
    async list(){const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
  };
})();
