window.BookSpeech = {
  chunks: [],
  chunkOffsets: [],
  totalChars: 0,
  chunkIndex: 0,
  chunkCharIndex: 0,
  utterance: null,
  state: 'idle',
  rate: 1,
  pitch: 1,
  voiceName: '__auto_male__',
  lastTextKey: '',
  token: 0,
  manualPaused: false,
  onStatus: null,
  onProgress: null,
  onComplete: null,
  onChunkStart: null,

  _isAndroid(){ return /Android/i.test(navigator.userAgent || ''); },

  _status(msg){
    this.state = msg;
    if (typeof this.onStatus === 'function') this.onStatus(msg);
    const el = document.getElementById('speechStatus');
    if (el) el.textContent = msg.charAt(0).toUpperCase() + msg.slice(1);
  },

  _splitText(text){
    const clean = String(text || '').replace(/\s+/g, ' ').trim();
    if (!clean) return [];
    const limit = this._isAndroid() ? 220 : 650;
    const sentences = clean.match(/[^.!?।]+[.!?।]*/g) || [clean];
    const chunks = [];
    let buffer = '';
    const flushLong = value => {
      let remaining = value.trim();
      while (remaining.length > limit) {
        let cut = remaining.lastIndexOf(' ', limit);
        if (cut < Math.floor(limit * 0.55)) cut = limit;
        chunks.push(remaining.slice(0, cut).trim());
        remaining = remaining.slice(cut).trim();
      }
      buffer = remaining;
    };
    for (const sentence of sentences) {
      const candidate = (buffer ? buffer + ' ' : '') + sentence.trim();
      if (candidate.length <= limit) buffer = candidate;
      else {
        if (buffer) chunks.push(buffer.trim());
        buffer = '';
        flushLong(sentence);
      }
    }
    if (buffer.trim()) chunks.push(buffer.trim());
    return chunks.filter(Boolean);
  },

  _startIndexFromPhrase(text, phrase){
    text = String(text || '');
    phrase = String(phrase || '').replace(/\s+/g, ' ').trim();
    if (!phrase) return 0;
    const idx = text.toLowerCase().indexOf(phrase.slice(0, 160).toLowerCase());
    return idx >= 0 ? idx : 0;
  },

  _resolveVoice(requested){
    const voices = speechSynthesis.getVoices() || [];
    if (!voices.length) return null;
    if (requested && requested !== '__auto_male__') return voices.find(v => v.name === requested) || null;

    const pageLang = (document.documentElement.lang || navigator.language || 'en-US').toLowerCase();
    const preferredBase = pageLang.split('-')[0];
    const male = /(male|david|mark|george|james|daniel|alex|tom|guy|andrew|christopher|matthew|ryan|brian|justin|joey|arthur|fred|ralph|reed|rocko|oliver|thomas|michael|paul)/i;
    const female = /(female|zira|samantha|victoria|karen|moira|tessa|fiona|susan|hazel|ava|allison|serena|veena|kathy|linda|heera)/i;
    const scored = voices.map((voice, index) => {
      const name = String(voice.name || '');
      const lang = String(voice.lang || '').toLowerCase();
      let score = 0;
      if (male.test(name)) score += 120;
      if (female.test(name)) score -= 100;
      if (lang === pageLang) score += 45;
      else if (lang.startsWith(preferredBase)) score += 30;
      if (lang.startsWith('en-us')) score += 18;
      else if (lang.startsWith('en-gb')) score += 15;
      if (voice.localService) score += 8;
      if (voice.default) score += 5;
      return {voice, score, index};
    }).sort((a,b) => b.score - a.score || a.index - b.index);
    return scored[0]?.voice || voices[0];
  },

  _emitProgress(){
    const base = this.chunkOffsets[this.chunkIndex] || 0;
    const current = Math.min(this.totalChars, base + this.chunkCharIndex);
    if (typeof this.onProgress === 'function') this.onProgress({current,total:this.totalChars,ratio:this.totalChars ? current / this.totalChars : 0,chunkIndex:this.chunkIndex,chunkCount:this.chunks.length});
  },

  speak(text, rate = 1, startPhrase = '', pitch = 1, voiceName = '__auto_male__'){
    if (!('speechSynthesis' in window)) { alert('Read aloud is not supported in this browser.'); return; }
    const source = String(text || '');
    const textKey = source.slice(0, 200) + '::' + source.length;
    if (this.state === 'paused' && this.lastTextKey === textKey && !String(startPhrase || '').trim()) { this.resume(); return; }

    this.stop(false);
    const start = this._startIndexFromPhrase(source, startPhrase);
    this.chunks = this._splitText(source.slice(start));
    this.chunkOffsets = [];
    let offset = 0;
    for (const chunk of this.chunks) { this.chunkOffsets.push(offset); offset += chunk.length; }
    this.totalChars = offset;
    this.chunkIndex = 0;
    this.chunkCharIndex = 0;
    this.rate = Math.min(2.5, Math.max(0.5, parseFloat(rate || 1)));
    this.pitch = Math.min(2, Math.max(0.5, parseFloat(pitch || 1)));
    this.voiceName = String(voiceName || '__auto_male__');
    this.lastTextKey = textKey;
    this.manualPaused = false;
    if (!this.chunks.length) { this._status('nothing to read'); return; }
    this._status('playing');
    this._speakCurrent(0);
  },

  _speakCurrent(offset = 0){
    const fullChunk = this.chunks[this.chunkIndex];
    if (!fullChunk) {
      this.chunkCharIndex = 0;
      this._emitProgress();
      this._status('finished');
      if (typeof this.onComplete === 'function') setTimeout(() => this.onComplete(), 0);
      return;
    }
    offset = Math.max(0, Math.min(offset, fullChunk.length));
    const remaining = fullChunk.slice(offset).trimStart();
    if (!remaining) { this.chunkIndex++; this.chunkCharIndex = 0; this._speakCurrent(0); return; }

    const leadingTrim = fullChunk.slice(offset).length - remaining.length;
    const baseOffset = offset + leadingTrim;
    const runToken = ++this.token;
    const utterance = new SpeechSynthesisUtterance(remaining);
    const voice = this._resolveVoice(this.voiceName);
    utterance.rate = this.rate;
    utterance.pitch = (this.voiceName === '__auto_male__' && voice && !/(male|david|mark|george|james|daniel|alex|tom|guy|andrew|matthew|michael|paul)/i.test(voice.name || '')) ? Math.min(this.pitch, 0.9) : this.pitch;
    if (voice) { utterance.voice = voice; utterance.lang = voice.lang; }
    this.chunkCharIndex = baseOffset;
    this._emitProgress();
    if (typeof this.onChunkStart === 'function') this.onChunkStart({chunkIndex:this.chunkIndex,chunkCount:this.chunks.length,text:remaining});
    utterance.onboundary = event => {
      if (runToken !== this.token) return;
      if (typeof event.charIndex === 'number') {
        this.chunkCharIndex = baseOffset + event.charIndex;
        this._emitProgress();
      }
    };
    utterance.onend = () => {
      if (runToken !== this.token || this.state !== 'playing') return;
      this.chunkCharIndex = fullChunk.length;
      this._emitProgress();
      this.chunkIndex++;
      this.chunkCharIndex = 0;
      if (this.chunkIndex < this.chunks.length) this._speakCurrent(0);
      else {
        this._status('finished');
        if (typeof this.onComplete === 'function') setTimeout(() => this.onComplete(), 0);
      }
    };
    utterance.onerror = event => {
      if (runToken !== this.token || this.state === 'paused' || this.state === 'stopped') return;
      if (['interrupted','canceled'].includes(event.error)) return;
      this._status('speech error');
    };
    this.utterance = utterance;
    this._status('playing');
    speechSynthesis.speak(utterance);
  },

  pause(){
    if (!('speechSynthesis' in window) || this.state !== 'playing') return;
    if (this._isAndroid()) {
      this.manualPaused = true;
      this._status('paused');
      this.token++;
      speechSynthesis.cancel();
      return;
    }
    if (speechSynthesis.speaking && !speechSynthesis.paused) { speechSynthesis.pause(); this._status('paused'); }
  },

  resume(){
    if (!('speechSynthesis' in window) || this.state !== 'paused') return;
    if (this._isAndroid() || this.manualPaused) {
      this.manualPaused = false;
      this._status('playing');
      this._speakCurrent(this.chunkCharIndex);
      return;
    }
    if (speechSynthesis.paused) { speechSynthesis.resume(); this._status('playing'); }
    else { this._status('playing'); this._speakCurrent(this.chunkCharIndex); }
  },

  stop(updateStatus = true){
    this.token++;
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    this.utterance = null;
    this.manualPaused = false;
    this.chunkCharIndex = 0;
    if (updateStatus) this._status('stopped'); else this.state = 'stopped';
  }
};

(function populateReadVaultVoices(){
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  function fill(){
    const select = document.getElementById('speechVoice');
    if (!select || !('speechSynthesis' in window)) return;
    const saved = localStorage.getItem('readvault_voice') || select.value || '__auto_male__';
    const voices = speechSynthesis.getVoices() || [];
    select.innerHTML = '<option value="__auto_male__">Auto-select male voice</option>' + voices.map(v => `<option value="${escape(v.name)}">${escape(v.name)} · ${escape(v.lang)}</option>`).join('');
    select.value = Array.from(select.options).some(o => o.value === saved) ? saved : '__auto_male__';
  }
  if ('speechSynthesis' in window) {
    const oldHandler = speechSynthesis.onvoiceschanged;
    speechSynthesis.onvoiceschanged = event => { if (typeof oldHandler === 'function') oldHandler.call(speechSynthesis,event); fill(); };
    setTimeout(fill, 50); setTimeout(fill, 500); setTimeout(fill, 1500);
    document.addEventListener('change', event => { if (event.target?.id === 'speechVoice') localStorage.setItem('readvault_voice', event.target.value || '__auto_male__'); });
  }
})();
