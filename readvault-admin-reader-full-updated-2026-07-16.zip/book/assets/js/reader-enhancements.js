(function(){
  if(!window.BOOK_READER) return;
  const cfg=window.BOOK_READER;
  const area=document.getElementById('bookPdfArea');
  let wakeLock=null, readingStarted=Date.now(), autoScrollTimer=null, focusInterval=null, audioCtx=null, ambientNode=null;
  const $=id=>document.getElementById(id);
  const status=(id,text)=>{const el=$(id);if(el)el.textContent=text;};

  async function requestWakeLock(){
    const enabled=$('keepAwakeToggle')?.checked!==false;
    if(!enabled){await releaseWakeLock();status('wakeLockStatus','Off');return;}
    if(!('wakeLock' in navigator)){status('wakeLockStatus','Not supported');return;}
    try{wakeLock=await navigator.wakeLock.request('screen');status('wakeLockStatus','Active');wakeLock.addEventListener('release',()=>status('wakeLockStatus','Released'));}
    catch(e){status('wakeLockStatus','Tap to enable');}
  }
  async function releaseWakeLock(){try{await wakeLock?.release();}catch(e){}wakeLock=null;}
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')requestWakeLock();});
  $('keepAwakeToggle')?.addEventListener('change',requestWakeLock);
  document.addEventListener('pointerdown',()=>{if($('keepAwakeToggle')?.checked&&!wakeLock)requestWakeLock();},{once:true});
  requestWakeLock();

  // Android browsers cannot enable system DND themselves, so ask the reader
  // once per week and provide the exact quick-settings steps.
  const isAndroid=/Android/i.test(navigator.userAgent||'');
  const dndPrompt=$('readerDndPrompt');
  const dndDisabled=localStorage.getItem('readvault_dnd_never')==='1';
  const lastDndPrompt=parseInt(localStorage.getItem('readvault_dnd_last')||'0',10);
  if(isAndroid&&dndPrompt&&!dndDisabled&&Date.now()-lastDndPrompt>7*24*60*60*1000){
    setTimeout(()=>{dndPrompt.hidden=false;},900);
  }
  const closeDnd=(remember=false)=>{if(dndPrompt)dndPrompt.hidden=true;if(remember)localStorage.setItem('readvault_dnd_last',String(Date.now()));};
  $('readerDndDone')?.addEventListener('click',()=>closeDnd(true));
  $('readerDndLater')?.addEventListener('click',()=>closeDnd(false));
  $('readerDndNever')?.addEventListener('click',()=>{localStorage.setItem('readvault_dnd_never','1');closeDnd(false);});

  setInterval(()=>{
    const seconds=Math.floor((Date.now()-readingStarted)/1000),h=String(Math.floor(seconds/3600)).padStart(2,'0'),m=String(Math.floor(seconds%3600/60)).padStart(2,'0'),s=String(seconds%60).padStart(2,'0');
    status('readingTimer',`${h}:${m}:${s}`);
  },1000);

  $('readerSettingsBtn')?.addEventListener('click',()=>{const p=$('readerSettings');if(p)p.hidden=!p.hidden;});
  $('fullscreenBtn')?.addEventListener('click',async()=>{try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();else await document.exitFullscreen();}catch(e){}});
  $('orientationMode')?.addEventListener('change',async e=>{try{if(e.target.value==='auto')screen.orientation?.unlock();else{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();await screen.orientation?.lock(e.target.value);}}catch(err){status('wakeLockStatus','Orientation lock unavailable');}});
  $('brightnessRange')?.addEventListener('input',e=>{document.documentElement.style.setProperty('--reader-brightness',Number(e.target.value)/100);});
  $('dyslexiaToggle')?.addEventListener('change',e=>document.body.classList.toggle('dyslexia-mode',e.target.checked));
  document.querySelector('[data-book-mode="contrast"]')?.addEventListener('click',()=>{document.body.classList.remove('book-night','book-sepia');document.body.classList.add('book-contrast');localStorage.setItem('book_mode','contrast');});

  $('autoScrollToggle')?.addEventListener('change',e=>{
    clearInterval(autoScrollTimer);autoScrollTimer=null;
    localStorage.setItem('readvault_auto_scroll',e.target.checked?'1':'0');
    if(e.target.checked)autoScrollTimer=setInterval(()=>{
      if(!area||window.BookSpeech?.state==='playing'||window.BookSpeech?.state==='paused')return;
      const bottom=Math.max(0,area.scrollHeight-area.clientHeight);
      if(bottom<=2||area.scrollTop>=bottom-3){$('nextPage')?.click();area.scrollTop=0;return;}
      area.scrollTop=Math.min(bottom,area.scrollTop+1);
    },35);
  });
  if($('autoScrollToggle')){$('autoScrollToggle').checked=localStorage.getItem('readvault_auto_scroll')==='1';if($('autoScrollToggle').checked)$('autoScrollToggle').dispatchEvent(new Event('change'));}

  $('offlineBtn')?.addEventListener('click',async()=>{
    const btn=$('offlineBtn');if(!window.ReadVaultOffline){alert('Offline storage is unavailable in this browser.');return;}
    const existing=await ReadVaultOffline.get(cfg.bookId).catch(()=>null);
    if(existing){if(confirm('This book is already saved offline. Remove the offline copy?')){await ReadVaultOffline.remove(cfg.bookId);await bookApi('api/offline.php?action=remove',{book_id:cfg.bookId});btn.textContent='Save offline';}return;}
    btn.disabled=true;btn.textContent='Authorizing…';
    try{
      const auth=await bookApi('api/offline.php?action=authorize',{book_id:cfg.bookId});if(!auth.success)throw new Error(auth.message||'Offline limit reached.');
      btn.textContent='Downloading…';const res=await fetch(cfg.streamUrl,{credentials:'same-origin'});if(!res.ok)throw new Error('Secure download failed.');const blob=await res.blob();
      await ReadVaultOffline.save(cfg.bookId,blob,{title:cfg.title,fileType:cfg.fileType,fileSize:cfg.fileSize});btn.textContent='Saved offline';
    }catch(e){alert(e.message||'Offline save failed.');btn.textContent='Save offline';}finally{btn.disabled=false;}
  });
  window.ReadVaultOffline?.get(cfg.bookId).then(v=>{if(v&&$('offlineBtn'))$('offlineBtn').textContent='Saved offline';}).catch(()=>{});

  function stopAmbient(){try{ambientNode?.stop?.();}catch(e){}try{ambientNode?.disconnect?.();}catch(e){}ambientNode=null;}
  function startAmbient(type){stopAmbient();if(type==='off')return;audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();const duration=2,buffer=audioCtx.createBuffer(1,audioCtx.sampleRate*duration,audioCtx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++){let n=Math.random()*2-1;if(type==='rain')n*=Math.random()>.96?1:.18;if(type==='ocean')n*=.35+Math.sin(i/7000)*.25;if(type==='forest')n*=.12;data[i]=n;}const source=audioCtx.createBufferSource();source.buffer=buffer;source.loop=true;const gain=audioCtx.createGain();gain.gain.value=type==='white'?.08:.16;source.connect(gain).connect(audioCtx.destination);source.start();ambientNode=source;}
  $('ambientSound')?.addEventListener('change',e=>startAmbient(e.target.value));
  $('focusTimerBtn')?.addEventListener('click',()=>{
    clearInterval(focusInterval);let remain=parseInt($('focusMinutes')?.value||25,10)*60;document.body.classList.add('book-focus-mode');
    const draw=()=>{const m=String(Math.floor(remain/60)).padStart(2,'0'),s=String(remain%60).padStart(2,'0');status('focusCountdown',`${m}:${s}`);if(remain--<=0){clearInterval(focusInterval);status('focusCountdown','Session complete');if('Notification'in window&&Notification.permission==='granted')new Notification('ReadVault focus session complete');}};draw();focusInterval=setInterval(draw,1000);
  });

  document.addEventListener('keydown',e=>{
    if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    if(e.key==='ArrowRight'||e.key==='PageDown')$('nextPage')?.click();
    if(e.key==='ArrowLeft'||e.key==='PageUp')$('prevPage')?.click();
    if(e.key.toLowerCase()==='f')$('fullscreenBtn')?.click();
    if(e.key==='Escape')document.body.classList.remove('book-focus-mode');
  });
  window.addEventListener('beforeunload',()=>{releaseWakeLock();stopAmbient();});
})();
