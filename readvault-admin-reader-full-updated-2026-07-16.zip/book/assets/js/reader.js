(function(){
  if(!window.BOOK_READER) return;
  const cfg = window.BOOK_READER;
  const isAndroid = /Android/i.test(navigator.userAgent || '');
  let pdfDoc = null;
  const savedScale = localStorage.getItem('book_zoom_'+cfg.bookId);
  let scale = savedScale ? parseFloat(savedScale) : 1.25;
  let currentPage = parseInt(cfg.currentPage || 1);
  let layout = localStorage.getItem('book_layout_'+cfg.bookId) || 'single';
  let viewMode = localStorage.getItem('book_pdf_view_'+cfg.bookId) || (isAndroid ? 'reflow' : 'original');
  let sessionId = null;
  let speechChainActive = false;
  const pageTextCache = new Map();
  const area = document.getElementById('bookPdfArea');
  const pageInput = document.getElementById('pageInput');
  const zoomLabel = document.getElementById('zoomLabel');
  const popup = document.getElementById('selectionPopup');
  const selectedTextBox = document.getElementById('selectedTextPreview');
  const viewModeSelect = document.getElementById('readerViewMode');
  let lastSelectionText = '';

  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

  async function api(path, data){ return await window.bookApi(path, data); }
  function setStatus(msg){ const s=document.getElementById('readerStatus'); if(s) s.textContent=msg; }
  function updateZoomLabel(){ if(zoomLabel) zoomLabel.textContent=viewMode==='reflow' ? String(document.getElementById('fontSizeRange')?.value || 100)+'%' : Math.round(scale*100)+'%'; }
  function escapeHtml(s){return String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
  function getToolText(){ return (selectedTextBox?.value || lastSelectionText || '').trim(); }
  function setToolResult(html){ const el=document.getElementById('toolResult'); if(el) el.innerHTML=html; }
  function normalizeSingleWord(text){
    let word = String(text || '').trim().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,'');
    if(!word || /\s/u.test(word)) return '';
    if(!/^[\p{L}\p{N}][\p{L}\p{N}\-'’]*$/u.test(word)) return '';
    return word.length <= 120 ? word : '';
  }

  async function startSession(){
    const res = await api('api/book-progress.php?action=start_session',{book_id:cfg.bookId,start_page:currentPage,device_type:window.matchMedia('(max-width: 700px)').matches?'mobile':'desktop'}).catch(()=>null);
    if(res && res.success) sessionId = res.session_id;
  }
  async function saveProgress(){
    if(!pdfDoc) return;
    const pct=Math.max(0,Math.min(100,Math.round(currentPage/pdfDoc.numPages*100)));
    await api('api/book-progress.php?action=update_progress',{book_id:cfg.bookId,page:currentPage,total_pages:pdfDoc.numPages,progress_percent:pct}).catch(()=>{});
    const bar=document.getElementById('readerProgressBar'); if(bar) bar.style.width=pct+'%';
    const eta=document.getElementById('estimatedTime'); if(eta) eta.textContent=Math.max(1,Math.round((pdfDoc.numPages-currentPage)*1.2))+' min';
  }
  window.addEventListener('beforeunload',()=>{
    const data = new FormData();
    data.append('_csrf',window.BOOK_CSRF||''); data.append('book_id',cfg.bookId); data.append('session_id',sessionId||''); data.append('end_page',currentPage);
    navigator.sendBeacon((window.BOOK_BASE_URL||'/book')+'/api/book-progress.php?action=end_session',data);
  });

  function textFromContent(textContent){
    const lines=[];
    let buffer='';
    let lastY=null;
    for(const item of (textContent?.items || [])){
      const value=String(item.str || '').replace(/\s+/g,' ').trim();
      if(!value) continue;
      const y=Number(item.transform?.[5]);
      const changedLine=Number.isFinite(y)&&Number.isFinite(lastY)&&Math.abs(y-lastY)>3;
      if(changedLine && buffer.trim()){lines.push(buffer.trim());buffer='';}
      buffer+=(buffer?' ':'')+value;
      if(item.hasEOL && buffer.trim()){lines.push(buffer.trim());buffer='';}
      if(Number.isFinite(y)) lastY=y;
    }
    if(buffer.trim()) lines.push(buffer.trim());
    return {lines,plain:lines.join('\n').replace(/\n{3,}/g,'\n\n').trim()};
  }

  async function pageText(pageNum){
    if(pageTextCache.has(pageNum)) return pageTextCache.get(pageNum);
    const cached=await fetch((window.BOOK_BASE_URL||'/book')+'/api/pages.php?action=get&book_id='+cfg.bookId+'&page_number='+pageNum).then(r=>r.json()).catch(()=>null);
    if(cached?.text_content){pageTextCache.set(pageNum,cached.text_content);return cached.text_content;}
    if(!pdfDoc) return '';
    const page=await pdfDoc.getPage(pageNum),content=await page.getTextContent(),parsed=textFromContent(content);
    pageTextCache.set(pageNum,parsed.plain);
    if(parsed.plain) api('api/pages.php?action=save_text',{book_id:cfg.bookId,page_number:pageNum,text_content:parsed.plain,total_pages:pdfDoc.numPages}).catch(()=>{});
    return parsed.plain;
  }

  async function renderPage(num){
    currentPage = Math.max(1, Math.min(num, pdfDoc.numPages));
    if(pageInput) pageInput.value = currentPage;
    localStorage.setItem('book_zoom_'+cfg.bookId, scale);
    localStorage.setItem('book_layout_'+cfg.bookId, layout);
    localStorage.setItem('book_pdf_view_'+cfg.bookId, viewMode);
    area.classList.toggle('is-reflow',viewMode==='reflow');
    area.innerHTML = '';
    const nums = layout === 'two' && viewMode==='original' && currentPage < pdfDoc.numPages ? [currentPage,currentPage+1] : [currentPage];
    if(layout === 'continuous'){
      const start = Math.max(1,currentPage-2), end = Math.min(pdfDoc.numPages,currentPage+2);
      nums.length = 0; for(let i=start;i<=end;i++) nums.push(i);
    }
    for(const pageNum of nums){ await renderOne(pageNum); }
    await saveProgress();
    setStatus('Page '+currentPage+' of '+pdfDoc.numPages+(viewMode==='reflow'?' · Reflow text':''));
    loadSideData();
    updateZoomLabel();
  }

  async function renderOne(pageNum){
    const page = await pdfDoc.getPage(pageNum);
    const textContent = await page.getTextContent();
    const parsed=textFromContent(textContent);
    pageTextCache.set(pageNum,parsed.plain);
    if(parsed.plain) api('api/pages.php?action=save_text',{book_id:cfg.bookId,page_number:pageNum,text_content:parsed.plain,total_pages:pdfDoc.numPages}).catch(()=>{});

    if(viewMode==='reflow'){
      const wrap=document.createElement('article');
      wrap.className='book-page book-reflow-page';
      wrap.dataset.page=pageNum;
      wrap.setAttribute('aria-label','Page '+pageNum);
      const heading=document.createElement('div');
      heading.className='book-reflow-page-number';
      heading.textContent='Page '+pageNum;
      const content=document.createElement('div');
      content.className='book-reflow-content';
      if(parsed.lines.length){
        for(const line of parsed.lines){const p=document.createElement('p');p.textContent=line;content.appendChild(p);}
      }else{
        const empty=document.createElement('p');empty.className='book-muted';empty.textContent='No selectable text was found on this page. Switch to Original page mode or configure OCR for scanned PDFs.';content.appendChild(empty);
      }
      wrap.append(heading,content);area.appendChild(wrap);return;
    }

    const viewport = page.getViewport({scale});
    const wrap = document.createElement('div');
    wrap.className = 'book-page';
    wrap.dataset.page = pageNum;
    wrap.style.width = viewport.width+'px';
    wrap.style.height = viewport.height+'px';

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', {alpha:false});
    const outputScale = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(viewport.width * outputScale);
    canvas.height = Math.floor(viewport.height * outputScale);
    canvas.style.width = viewport.width+'px';
    canvas.style.height = viewport.height+'px';
    wrap.appendChild(canvas);
    area.appendChild(wrap);
    await page.render({canvasContext:ctx,viewport,transform:outputScale===1?null:[outputScale,0,0,outputScale,0,0]}).promise;

    const textLayer = document.createElement('div');
    textLayer.className = 'book-text-layer textLayer';
    textLayer.style.setProperty('--scale-factor', String(viewport.scale));
    wrap.appendChild(textLayer);
    if (typeof pdfjsLib.renderTextLayer === 'function') {
      const task = pdfjsLib.renderTextLayer({textContentSource:textContent,container:textLayer,viewport,textDivs:[]});
      if (task?.promise) await task.promise; else if (task?.then) await task;
    } else {
      for (const item of textContent.items) {
        if (!item.str) continue;
        const span = document.createElement('span');
        span.textContent = item.str;
        const tx = pdfjsLib.Util.transform(viewport.transform,item.transform);
        const angle = Math.atan2(tx[1],tx[0]);
        const fontHeight = Math.hypot(tx[2],tx[3]);
        span.style.left = tx[4]+'px';
        span.style.top = (tx[5]-fontHeight)+'px';
        span.style.fontSize = fontHeight+'px';
        span.style.fontFamily = 'sans-serif';
        span.style.transform = `rotate(${angle}rad)`;
        textLayer.appendChild(span);
        const measured = span.getBoundingClientRect().width;
        const targetWidth = Math.abs((item.width || 0) * viewport.scale);
        if (measured > 0 && targetWidth > 0) span.style.transform += ` scaleX(${targetWidth/measured})`;
      }
    }
  }

  async function loadPdf(){
    setStatus('Loading book...');
    let source = cfg.streamUrl;
    try { const cached = await window.ReadVaultOffline?.get(cfg.bookId); if(cached?.blob) source = {data: await cached.blob.arrayBuffer()}; } catch(e) {}
    const task = pdfjsLib.getDocument(source);
    pdfDoc = await task.promise;
    if(!savedScale && window.matchMedia('(max-width: 700px)').matches && viewMode==='original'){
      const firstPage = await pdfDoc.getPage(currentPage);
      const baseViewport = firstPage.getViewport({scale:1});
      const availableWidth = Math.max(260, area.clientWidth - 14);
      scale = Math.max(.5, Math.min(2.5, availableWidth / baseViewport.width));
    }
    if(pageInput){ pageInput.max = pdfDoc.numPages; pageInput.value = currentPage; }
    document.getElementById('totalPages').textContent = pdfDoc.numPages;
    const layoutSelect=document.getElementById('layoutMode');if(layoutSelect)layoutSelect.value=layout;
    if(viewModeSelect)viewModeSelect.value=viewMode;
    await api('api/book-progress.php?action=update_progress',{book_id:cfg.bookId,page:currentPage,total_pages:pdfDoc.numPages});
    await renderPage(currentPage);
    startSession();
    setTimeout(detectScanned,1600);
  }

  async function detectScanned(){
    const res = await api('api/pages.php?action=detect_scanned',{book_id:cfg.bookId});
    if(res && res.scanned){ document.getElementById('scannedWarning').style.display='block'; }
  }

  function stopSpeechForNavigation(){
    speechChainActive=false;
    if(window.BookSpeech && ['playing','paused'].includes(BookSpeech.state)) BookSpeech.stop();
  }
  function manualNavigate(num){stopSpeechForNavigation();area.scrollTop=0;return renderPage(num);}
  document.getElementById('nextPage')?.addEventListener('click',()=>manualNavigate(currentPage+(layout==='two'&&viewMode==='original'?2:1)));
  document.getElementById('prevPage')?.addEventListener('click',()=>manualNavigate(currentPage-(layout==='two'&&viewMode==='original'?2:1)));
  pageInput?.addEventListener('change',()=>manualNavigate(parseInt(pageInput.value||1)));
  document.getElementById('zoomIn')?.addEventListener('click',()=>{
    if(viewMode==='reflow'){const control=document.getElementById('fontSizeRange');if(control){control.value=String(Math.min(180,Number(control.value)+10));control.dispatchEvent(new Event('input'));}return;}
    scale+=.15; updateZoomLabel(); renderPage(currentPage);
  });
  document.getElementById('zoomOut')?.addEventListener('click',()=>{
    if(viewMode==='reflow'){const control=document.getElementById('fontSizeRange');if(control){control.value=String(Math.max(80,Number(control.value)-10));control.dispatchEvent(new Event('input'));}return;}
    scale=Math.max(.5,scale-.15); updateZoomLabel(); renderPage(currentPage);
  });
  document.getElementById('fitWidth')?.addEventListener('click',()=>{
    if(viewMode==='reflow'){const control=document.getElementById('fontSizeRange');if(control){control.value='100';control.dispatchEvent(new Event('input'));}return;}
    if(pdfDoc){ scale=Math.max(.7,(area.clientWidth-50)/650); updateZoomLabel(); renderPage(currentPage);}
  });
  document.getElementById('layoutMode')?.addEventListener('change',e=>{layout=e.target.value;manualNavigate(currentPage);});
  viewModeSelect?.addEventListener('change',e=>{viewMode=e.target.value==='reflow'?'reflow':'original';localStorage.setItem('book_pdf_view_'+cfg.bookId,viewMode);stopSpeechForNavigation();area.scrollTop=0;renderPage(currentPage);});
  document.getElementById('focusMode')?.addEventListener('click',()=>document.body.classList.toggle('book-focus-mode'));

  const typographyControls=['fontSizeRange','lineHeightRange','letterSpacingRange','marginRange'];
  const typographyDefaults={fontSizeRange:'100',lineHeightRange:'160',letterSpacingRange:'0',marginRange:'24'};
  function applyReflowTypography(){
    const font=Number(document.getElementById('fontSizeRange')?.value||100);
    const line=Number(document.getElementById('lineHeightRange')?.value||160)/100;
    const spacing=Number(document.getElementById('letterSpacingRange')?.value||0)/10;
    const margin=Number(document.getElementById('marginRange')?.value||24);
    area.style.setProperty('--reflow-font-scale',font/100);
    area.style.setProperty('--reflow-line-height',line);
    area.style.setProperty('--reflow-letter-spacing',spacing+'px');
    area.style.setProperty('--reflow-margin',margin+'px');
    for(const id of typographyControls)localStorage.setItem('book_'+id,document.getElementById(id)?.value||typographyDefaults[id]);
    updateZoomLabel();
  }
  for(const id of typographyControls){const el=document.getElementById(id);if(el){el.value=localStorage.getItem('book_'+id)||typographyDefaults[id];el.addEventListener('input',applyReflowTypography);}}
  const dyslexia=document.getElementById('dyslexiaToggle');if(dyslexia){dyslexia.checked=localStorage.getItem('book_dyslexia')==='1';document.body.classList.toggle('dyslexia-mode',dyslexia.checked);dyslexia.addEventListener('change',()=>localStorage.setItem('book_dyslexia',dyslexia.checked?'1':'0'));}
  applyReflowTypography();

  let selectionFrame = 0;
  document.addEventListener('selectionchange',()=>{
    cancelAnimationFrame(selectionFrame);
    selectionFrame = requestAnimationFrame(()=>{
      const sel = window.getSelection();
      if(!sel || sel.rangeCount === 0 || sel.isCollapsed){ if(popup) popup.style.display='none'; return; }
      const range = sel.getRangeAt(0);
      const common = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
      const page = common?.closest?.('.book-page');
      if(!page || !area.contains(page)){ if(popup) popup.style.display='none'; return; }
      const text = sel.toString().replace(/\s+/g,' ').trim();
      if(text.length < 2){ if(popup) popup.style.display='none'; return; }
      lastSelectionText = text;
      if(selectedTextBox && document.activeElement !== selectedTextBox) selectedTextBox.value = text;
      const rects = Array.from(range.getClientRects()).filter(r=>r.width>0&&r.height>0);
      const rect = rects[rects.length-1] || range.getBoundingClientRect();
      if(popup && rect){
        const popupWidth = Math.min(320, window.innerWidth-16);
        popup.style.left=Math.max(8,Math.min(rect.left,window.innerWidth-popupWidth-8))+'px';
        popup.style.top=Math.max(8,rect.top-58)+'px';
        popup.style.display='flex';
      }
    });
  });


  document.querySelectorAll('[data-highlight]').forEach(btn=>btn.addEventListener('click',async()=>{
    const text = getToolText();
    if(!text) return;
    const color = btn.dataset.highlight;
    const map = {yellow:'important',green:'definition',blue:'example',red:'revision',purple:'quote',orange:'exam_question'};
    const res = await api('api/highlights.php?action=create',{book_id:cfg.bookId,page_number:currentPage,selected_text:text,color,category:map[color]||'important'});
    if(res.success){ popup.style.display='none'; window.getSelection().removeAllRanges(); loadSideData(); }
    else alert(res.message||'Could not save highlight');
  }));

  document.getElementById('saveNoteBtn')?.addEventListener('click',async()=>{
    const content = document.getElementById('quickNote').value.trim();
    if(!content) return;
    const res = await api('api/notes.php?action=create',{book_id:cfg.bookId,page_number:currentPage,note_type:'page',title:'Page '+currentPage+' Note',content});
    if(res.success){ document.getElementById('quickNote').value=''; loadSideData(); }
  });

  document.getElementById('bookmarkBtn')?.addEventListener('click',async()=>{
    const name = prompt('Bookmark name', 'Page '+currentPage);
    if(name === null) return;
    const res = await api('api/bookmarks.php?action=create',{book_id:cfg.bookId,page_number:currentPage,name,type:'page'});
    if(res.success) loadSideData();
  });

  document.getElementById('copyToolText')?.addEventListener('click',async()=>{
    const text = getToolText();
    if(!text) return;
    await navigator.clipboard?.writeText(text).catch(()=>{});
  });

  document.getElementById('dictionaryBtn')?.addEventListener('click', async()=>{
    const text = getToolText();
    const word = normalizeSingleWord(text.split(/\s+/)[0] || text);
    if(!word){ setToolResult('<div class="book-alert warn">Select or type one single word first. Phrases are not added to Quiz Words.</div>'); return; }
    setToolResult('<div class="book-alert">Looking up dictionary and adding the word to Quiz Words...</div>');
    let data = await fetch((window.BOOK_BASE_URL||'/book')+'/api/dictionary.php?word='+encodeURIComponent(word)+'&book_id='+encodeURIComponent(cfg.bookId)+'&page_number='+encodeURIComponent(currentPage)).then(r=>r.json()).catch(()=>null);
    let savedToQuiz = !!(data && data.saved_to_quiz);

    // Browser fallback if hosting blocks outgoing PHP requests.
    if(!data || !data.success){
      try{
        const direct = await fetch('https://api.dictionaryapi.dev/api/v2/entries/en/'+encodeURIComponent(word)).then(r=>r.json());
        if(Array.isArray(direct) && direct[0]?.meanings?.length){
          const m = direct[0].meanings[0]; const d = m.definitions[0] || {};
          data = {success:true, word:direct[0].word || word, meaning:d.definition || '', simple_meaning:d.definition || '', example:d.example || '', part_of_speech:m.partOfSpeech || '', synonyms:(m.synonyms||[]).slice(0,8).join(', '), antonyms:(m.antonyms||[]).slice(0,8).join(', '), pronunciation:direct[0].phonetic || ''};
          savedToQuiz = await saveWordSilently(word, data);
        }
      }catch(e){}
    }

    if(!data || !data.success){
      const savedLine = data?.saved_to_quiz ? '<p class="book-success-text">✓ Single word added to Quiz Words. Edit it later from Vocabulary.</p>' : '';
      setToolResult('<div class="book-alert warn">'+escapeHtml(data?.message || 'Dictionary unavailable. You can still save the word manually.')+'</div>'+savedLine+'<div class="book-tool-box"><button class="book-btn small" id="saveWordManual">Edit / Save Word Manually</button></div>');
      document.getElementById('saveWordManual')?.addEventListener('click',()=>saveWordPrompt(word, data || {}));
      return;
    }

    const definitions = (data.definitions||[]).map(d=>'<li><b>'+escapeHtml(d.part_of_speech||'')+'</b> '+escapeHtml(d.definition||'')+(d.example?'<br><small>Example: '+escapeHtml(d.example)+'</small>':'')+'</li>').join('');
    const quizBadge = (savedToQuiz || data.saved_to_quiz) ? '<p class="book-success-text">✓ Added to Quiz Words automatically.</p>' : '<p class="book-muted">Use Save Word to add this to Quiz Words.</p>';
    setToolResult('<div class="book-tool-box"><h4>'+escapeHtml(data.word || word)+' '+(data.pronunciation?'<small>'+escapeHtml(data.pronunciation)+'</small>':'')+'</h4>'+quizBadge+'<p><b>Meaning:</b> '+escapeHtml(data.meaning||'')+'</p>'+(data.part_of_speech?'<p><b>Part of speech:</b> '+escapeHtml(data.part_of_speech)+'</p>':'')+(data.example?'<p><b>Example:</b> '+escapeHtml(data.example)+'</p>':'')+(data.synonyms?'<p><b>Synonyms:</b> '+escapeHtml(data.synonyms)+'</p>':'')+(data.antonyms?'<p><b>Antonyms:</b> '+escapeHtml(data.antonyms)+'</p>':'')+(definitions?'<ol>'+definitions+'</ol>':'')+'<div class="book-inline-actions"><button class="book-btn small" id="saveWordNow">Save / Update Word</button><button class="book-btn small secondary" id="editWordBeforeSave">Edit & Save</button></div></div>');
    document.getElementById('saveWordNow')?.addEventListener('click',()=>saveWord(word, data));
    document.getElementById('editWordBeforeSave')?.addEventListener('click',()=>saveWordPrompt(word, data));
  });

  async function saveWord(word, data){
    const r = await api('api/vocabulary.php?action=save',{word,book_id:cfg.bookId,source_page:currentPage,meaning:data.meaning||'',simple_meaning:data.simple_meaning||data.meaning||'',hindi_meaning:data.hindi_meaning||'',bengali_meaning:data.bengali_meaning||'',synonyms:data.synonyms||'',antonyms:data.antonyms||'',pronunciation:data.pronunciation||'',part_of_speech:data.part_of_speech||'',example_sentence:data.example||data.example_sentence||''});
    alert(r.message || 'Saved to Quiz Words');
    return !!r.success;
  }
  async function saveWordSilently(word, data){
    try{
      const r = await api('api/vocabulary.php?action=save',{word,book_id:cfg.bookId,source_page:currentPage,meaning:data.meaning||'',simple_meaning:data.simple_meaning||data.meaning||'',hindi_meaning:data.hindi_meaning||'',bengali_meaning:data.bengali_meaning||'',synonyms:data.synonyms||'',antonyms:data.antonyms||'',pronunciation:data.pronunciation||'',part_of_speech:data.part_of_speech||'',example_sentence:data.example||data.example_sentence||''});
      return !!r.success;
    }catch(e){ return false; }
  }
  async function saveWordPrompt(word, data){
    const meaning = prompt('Meaning for '+word, data.meaning || '');
    if(meaning === null) return;
    const simple = prompt('Simple meaning, optional', data.simple_meaning || meaning || '');
    const r = await api('api/vocabulary.php?action=save',{word,book_id:cfg.bookId,source_page:currentPage,meaning,simple_meaning:simple||meaning,part_of_speech:data.part_of_speech||'',pronunciation:data.pronunciation||'',synonyms:data.synonyms||'',antonyms:data.antonyms||'',example_sentence:data.example||data.example_sentence||''});
    alert(r.message || 'Saved to Quiz Words');
  }

  document.getElementById('translateBtn')?.addEventListener('click', async()=>{
    const text = getToolText();
    if(!text){ setToolResult('<div class="book-alert warn">Select or type text first.</div>'); return; }
    const target = document.getElementById('translationTarget')?.value || 'hi';
    setToolResult('<div class="book-alert">Translating...</div>');
    const res = await api('api/translate.php',{book_id:cfg.bookId,page_number:currentPage,text,target_language:target}).catch(e=>({success:false,message:'Translation request failed.'}));
    const quizNote = res.saved_to_quiz ? '<p class="book-success-text">✓ Single translated word saved to Quiz Words: '+escapeHtml(res.quiz_word||'')+'</p>' : '<p class="book-muted">'+escapeHtml(res.quiz_save_reason || 'Phrase/sentence translations are not added to Quiz Words.')+'</p>';
    setToolResult('<div class="book-tool-box"><h4>Translation '+(res.provider?' <small>via '+escapeHtml(res.provider)+'</small>':'')+'</h4>'+quizNote+'<p><b>Original:</b> '+escapeHtml(text)+'</p><p><b>Result:</b> '+escapeHtml(res.translated_text||res.message||'Unavailable')+'</p><div class="book-inline-actions"><button class="book-btn small secondary" id="copyTranslation">Copy Result</button></div></div>');
    document.getElementById('copyTranslation')?.addEventListener('click',()=>navigator.clipboard?.writeText(res.translated_text||''));
  });

  async function getCurrentPageText(){return await pageText(currentPage);}

  const speechFollow=document.getElementById('speechFollowToggle');
  const speechAutoNext=document.getElementById('speechAutoNextToggle');
  if(speechFollow){speechFollow.checked=localStorage.getItem('book_speech_follow')!=='0';speechFollow.addEventListener('change',()=>localStorage.setItem('book_speech_follow',speechFollow.checked?'1':'0'));}
  if(speechAutoNext){speechAutoNext.checked=localStorage.getItem('book_speech_auto_next')!=='0';speechAutoNext.addEventListener('change',()=>localStorage.setItem('book_speech_auto_next',speechAutoNext.checked?'1':'0'));}

  async function startSpeechForPage(useStartPhrase=false){
    const text=await getCurrentPageText();
    if(!text){speechChainActive=false;alert('No selectable text was found on this page. Try Reflow text mode or configure OCR for a scanned PDF.');return;}
    speechChainActive=true;
    const startPhrase=useStartPhrase?(document.getElementById('speechStartText')?.value||''):'';
    BookSpeech.speak(text,document.getElementById('speechRate')?.value||1,startPhrase,document.getElementById('speechPitch')?.value||1,document.getElementById('speechVoice')?.value||'');
  }
  BookSpeech.onProgress=progress=>{
    const bar=document.getElementById('speechPageProgress');if(bar)bar.style.width=Math.round((progress.ratio||0)*100)+'%';
    if(!speechFollow?.checked)return;
    const pageEl=area.querySelector('.book-page[data-page="'+currentPage+'"]');if(!pageEl)return;
    const usable=Math.max(0,pageEl.offsetHeight-area.clientHeight*.55);
    const target=Math.max(0,pageEl.offsetTop-18+usable*(progress.ratio||0));
    area.scrollTop=Math.min(Math.max(0,area.scrollHeight-area.clientHeight),target);
  };
  BookSpeech.onComplete=async()=>{
    if(!speechChainActive)return;
    const shouldAdvance=speechAutoNext?.checked!==false;
    if(shouldAdvance&&pdfDoc&&currentPage<pdfDoc.numPages){
      await renderPage(currentPage+1);area.scrollTop=0;
      setTimeout(()=>startSpeechForPage(false),180);
    }else speechChainActive=false;
  };

  document.getElementById('useSelectionStart')?.addEventListener('click',()=>{const text=getToolText();if(text)document.getElementById('speechStartText').value=text.slice(0,120);});
  document.getElementById('readAloudBtn')?.addEventListener('click',()=>startSpeechForPage(true));
  document.getElementById('pauseSpeechBtn')?.addEventListener('click',()=>BookSpeech.pause());
  document.getElementById('resumeSpeechBtn')?.addEventListener('click',()=>BookSpeech.resume());
  document.getElementById('stopSpeechBtn')?.addEventListener('click',()=>{speechChainActive=false;BookSpeech.stop();const bar=document.getElementById('speechPageProgress');if(bar)bar.style.width='0%';});

  async function loadSideData(){
    const [h,n,b,u] = await Promise.all([
      fetch((window.BOOK_BASE_URL||'/book')+'/api/highlights.php?action=list&book_id='+cfg.bookId).then(r=>r.json()).catch(()=>({items:[]})),
      fetch((window.BOOK_BASE_URL||'/book')+'/api/notes.php?action=list&book_id='+cfg.bookId).then(r=>r.json()).catch(()=>({items:[]})),
      fetch((window.BOOK_BASE_URL||'/book')+'/api/bookmarks.php?action=list&book_id='+cfg.bookId).then(r=>r.json()).catch(()=>({items:[]})),
      fetch((window.BOOK_BASE_URL||'/book')+'/api/underlines.php?action=list&book_id='+cfg.bookId).then(r=>r.json()).catch(()=>({items:[]}))
    ]);
    const box = document.getElementById('readerSideData');
    if(!box) return;
    box.innerHTML = '<h3>Highlights</h3>'+renderSmall(h.items,'selected_text','highlight')+'<h3>Notes</h3>'+renderSmall(n.items,'content','note')+'<h3>Bookmarks</h3>'+renderSmall(b.items,'name','bookmark')+'<h3>Underlines</h3>'+renderSmall(u.items,'selected_text','underline');
    bindSideActions();
  }

  function renderSmall(items,key,type){
    if(!items || !items.length) return '<p class="book-muted">No items yet.</p>';
    return items.slice(0,8).map(x=>'<div class="book-kv-item" data-type="'+type+'" data-id="'+x.id+'"><small class="book-muted">Page '+(x.page_number||'')+'</small><p>'+escapeHtml((x[key]||'').slice(0,120))+'</p><div class="book-inline-actions"><button class="book-icon-btn" data-jump="'+(x.page_number||currentPage)+'">Open</button>'+(type==='note'?'<button class="book-icon-btn" data-edit-note="'+x.id+'">Edit</button>':'')+(type==='highlight'?'<button class="book-icon-btn" data-edit-highlight="'+x.id+'">Edit</button>':'')+(type==='bookmark'?'<button class="book-icon-btn" data-edit-bookmark="'+x.id+'">Edit</button>':'')+'<button class="book-icon-btn danger" data-delete-'+type+'="'+x.id+'">Delete</button></div></div>').join('');
  }

  function bindSideActions(){
    document.querySelectorAll('[data-jump]').forEach(btn=>btn.onclick=()=>manualNavigate(parseInt(btn.dataset.jump||currentPage)));
    document.querySelectorAll('[data-delete-note]').forEach(btn=>btn.onclick=()=>deleteThing('notes',btn.dataset.deleteNote));
    document.querySelectorAll('[data-delete-highlight]').forEach(btn=>btn.onclick=()=>deleteThing('highlights',btn.dataset.deleteHighlight));
    document.querySelectorAll('[data-delete-bookmark]').forEach(btn=>btn.onclick=()=>deleteThing('bookmarks',btn.dataset.deleteBookmark));
    document.querySelectorAll('[data-delete-underline]').forEach(btn=>btn.onclick=()=>deleteThing('underlines',btn.dataset.deleteUnderline));
    document.querySelectorAll('[data-edit-note]').forEach(btn=>btn.onclick=async()=>{
      const current = btn.closest('.book-kv-item')?.querySelector('p')?.textContent || '';
      const content = prompt('Edit note', current);
      if(content === null) return;
      await api('api/notes.php?action=update',{id:btn.dataset.editNote,title:'Page '+currentPage+' Note',content}); loadSideData();
    });
    document.querySelectorAll('[data-edit-highlight]').forEach(btn=>btn.onclick=async()=>{
      const note = prompt('Highlight note, optional', '');
      if(note === null) return;
      const color = prompt('Color: yellow, green, blue, red, purple, orange', 'yellow') || 'yellow';
      await api('api/highlights.php?action=update',{id:btn.dataset.editHighlight,note,color,category:'important'}); loadSideData();
    });
    document.querySelectorAll('[data-edit-bookmark]').forEach(btn=>btn.onclick=async()=>{
      const name = prompt('Bookmark name', btn.closest('.book-kv-item')?.querySelector('p')?.textContent || 'Bookmark');
      if(name === null) return;
      const page = prompt('Page number', currentPage) || currentPage;
      await api('api/bookmarks.php?action=update',{id:btn.dataset.editBookmark,name,page_number:page,type:'page'}); loadSideData();
    });
  }
  async function deleteThing(endpoint,id){
    if(!confirm('Delete this item?')) return;
    await api('api/'+endpoint+'.php?action=delete',{id});
    loadSideData();
  }

  updateZoomLabel();
  loadPdf().catch(err=>{console.error(err); setStatus('Could not load PDF. Check file path and PDF.js.');});
})();
