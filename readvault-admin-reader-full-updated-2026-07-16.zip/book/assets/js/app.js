(function(){
  window.bookApi = async function(path, data = {}, method = 'POST') {
    const opts = { method, headers: {'X-CSRF-Token': window.BOOK_CSRF || ''} };
    if (data instanceof FormData) { data.append('_csrf', window.BOOK_CSRF || ''); opts.body = data; }
    else if (method.toUpperCase() === 'GET') { }
    else { opts.headers['Content-Type'] = 'application/x-www-form-urlencoded'; opts.body = new URLSearchParams({...data, _csrf: window.BOOK_CSRF || ''}); }
    const res = await fetch((window.BOOK_BASE_URL || '/book') + '/' + path.replace(/^\//,''), opts);
    return await res.json();
  };
  document.addEventListener('click', function(e){
    const modeBtn=e.target.closest('[data-book-mode]');
    if(modeBtn){
      const m=modeBtn.dataset.bookMode;
      document.body.classList.remove('book-night','book-sepia','book-contrast');
      if(m==='night') document.body.classList.add('book-night');
      if(m==='sepia') document.body.classList.add('book-sepia');
      localStorage.setItem('book_mode',m);
    }
  });
  const saved=localStorage.getItem('book_mode');
  if(saved==='night') document.body.classList.add('book-night');
  if(saved==='sepia') document.body.classList.add('book-sepia');
  if(saved==='contrast') document.body.classList.add('book-contrast');
})();
