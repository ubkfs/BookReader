<?php
require_once __DIR__ . '/includes/bootstrap.php';
function readvault_run_sql(PDO $db,string $sql): void {
  $sql=preg_replace('/^\s*--.*$/m','',$sql)??$sql;
  foreach(preg_split('/;\s*(?:\r?\n|$)/',$sql)?:[] as $statement){$statement=trim($statement);if($statement!=='')$db->exec($statement);}
}
$db = book_db();
if (!$db) { http_response_code(500); exit('Database connection failed. Copy .env.example to .env and enter the new ReadVault database credentials.'); }
$hasUsers = book_table_exists($db, 'users');
$existingUserCount = $hasUsers ? (int)$db->query('SELECT COUNT(*) FROM book_users')->fetchColumn() : 0;
if ($hasUsers && $existingUserCount > 0 && !book_is_admin()) { book_require_admin(); }
$message='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  book_verify_csrf();
  $adminName=trim((string)($_POST['admin_name']??''));$adminEmail=mb_strtolower(trim((string)($_POST['admin_email']??'')));$adminPassword=(string)($_POST['admin_password']??'');
  try{
    $schema=file_get_contents(__DIR__.'/database/schema.sql');$seed=file_get_contents(__DIR__.'/database/seeders/001_core.sql');
    if($schema===false||$seed===false)throw new RuntimeException('Schema or seeder file is missing.');
    readvault_run_sql($db,$schema);readvault_run_sql($db,$seed);$db->prepare("INSERT IGNORE INTO book_schema_migrations(migration) VALUES(?)")->execute(["001_baseline.sql"]);
    foreach(BOOK_CONFIG['paths'] as $key=>$dir){if(in_array($key,['root'],true))continue;if(!is_dir($dir))mkdir($dir,0750,true);}
    if(!book_table_exists($db,'users'))throw new RuntimeException('The users table was not created.');
    $count=(int)$db->query('SELECT COUNT(*) FROM book_users')->fetchColumn();
    if($count===0){
      if($adminName===''||!filter_var($adminEmail,FILTER_VALIDATE_EMAIL)||strlen($adminPassword)<12)throw new RuntimeException('Enter an admin name, valid email, and password of at least 12 characters.');
      $db->prepare('INSERT INTO book_users (name,email,password_hash,role,status,email_verified_at,locale,timezone) VALUES (?,?,?,"super_admin","active",NOW(),?,?)')->execute([$adminName,$adminEmail,password_hash($adminPassword,PASSWORD_DEFAULT),BOOK_CONFIG['app']['locale'],BOOK_CONFIG['app']['timezone']]);
      $adminId=(int)$db->lastInsertId();$planId=(int)$db->query("SELECT id FROM book_subscription_plans WHERE code='annual' LIMIT 1")->fetchColumn();
      if($planId)$db->prepare('INSERT INTO book_subscriptions (user_id,plan_id,status,starts_at,ends_at,auto_renew) VALUES (?, ?, "active", NOW(), DATE_ADD(NOW(),INTERVAL 10 YEAR),0)')->execute([$adminId,$planId]);
      $db->prepare('INSERT INTO book_reading_streaks (user_id) VALUES (?)')->execute([$adminId]);
    }
    $message='ReadVault SaaS database, seed data, private storage, and administrator account are ready.';
  }catch(Throwable $e){$error=BOOK_CONFIG['app']['debug']?$e->getMessage():'Installation failed. Check database privileges and the error log.';}
}
book_render_header('Install ReadVault SaaS','install','Install the independent ReadVault SaaS database and administrator account.');
?>
<main class="auth-page install-page"><section class="auth-card install-card"><h1>Independent SaaS installer</h1><p class="book-muted">This installer uses only <code>/book/config/config.php</code> and the dedicated database from <code>/book/.env</code>.</p>
<div class="system-check-grid"><div><strong>PHP</strong><span><?=book_e(PHP_VERSION)?> <?=version_compare(PHP_VERSION,'8.3.0','>=')?'✓':'✕'?></span></div><div><strong>PDO MySQL</strong><span><?=extension_loaded('pdo_mysql')?'Available ✓':'Missing ✕'?></span></div><div><strong>OpenSSL</strong><span><?=extension_loaded('openssl')?'Available ✓':'Missing ✕'?></span></div><div><strong>Fileinfo</strong><span><?=extension_loaded('fileinfo')?'Available ✓':'Missing ✕'?></span></div><div><strong>Base URL</strong><span><?=book_e(BOOK_BASE_URL)?></span></div><div><strong>Database</strong><span><?=book_e(BOOK_CONFIG['database']['name'])?></span></div></div>
<?php if($message):?><div class="alert alert-success"><?=book_e($message)?></div><a class="book-btn" href="<?=book_url('auth/login.php')?>">Log in</a><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=book_e($error)?></div><?php endif;?>
<form method="post" class="book-form"><input type="hidden" name="_csrf" value="<?=book_e(book_csrf_token())?>"><?php if($existingUserCount===0):?><h3>First administrator</h3><label class="book-label">Name</label><input class="book-input" name="admin_name" required><label class="book-label">Email</label><input class="book-input" type="email" name="admin_email" required><label class="book-label">Password</label><input class="book-input" type="password" name="admin_password" minlength="12" required><small class="book-muted">Use at least 12 characters and store it securely.</small><?php endif;?><button class="book-btn"><?= $existingUserCount>0?'Run idempotent schema update':'Install platform' ?></button></form>
<p class="book-muted mt-3"><strong>Production:</strong> delete or deny web access to <code>install.php</code> after setup.</p></section></main><?php book_render_footer(); ?>
