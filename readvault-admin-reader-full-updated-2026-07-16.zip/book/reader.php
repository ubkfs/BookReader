<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
book_require_login();
$db=book_db();$userId=book_user_id();$bookId=(int)($_GET['id']??0);$book=$db?book_fetch_user_book($db,$bookId,$userId):null;
if(!$book){http_response_code(404);exit('Book not found or subscription expired.');}
$progressStmt=$db->prepare('SELECT page_number,location_value FROM book_progress WHERE user_id=? AND book_id=? LIMIT 1');$progressStmt->execute([$userId,$bookId]);$synced=$progressStmt->fetch()?:[];
$startPage=max(1,(int)($_GET['page']??$synced['page_number']??$book['current_page']??1));$startLocation=(string)($synced['location_value']??$book['current_location']??'');
$db->prepare('UPDATE book_books SET last_opened_at=NOW(),reading_status=IF(reading_status="not_started","reading",reading_status) WHERE id=?')->execute([$bookId]);
$token=book_signed_token(['book_id'=>$bookId,'user_id'=>$userId,'scope'=>'read']);$streamUrl=book_url('view-pdf.php?id='.$bookId.'&token='.rawurlencode($token));
book_render_header('Reader · '.$book['title'],'book-reader','Read '.$book['title'].' online with notes, highlights, offline access, focus mode and synchronized progress.');
?>
<?php if(($book['file_type']??'pdf')==='pdf'):?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js" crossorigin="anonymous"></script>
<?php else:?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/epubjs@0.3.93/dist/epub.min.js" crossorigin="anonymous"></script>
<?php endif;?>
<script src="<?=book_asset('js/offline-library.js')?>?v=2.3.0"></script>
<script src="<?=book_asset('js/speech.js')?>?v=2.3.0"></script>
<main class="book-app reader-app">
  <div class="book-reader-wrap">
    <aside class="book-reader-side">
      <div class="reader-book-meta"><span class="book-chip"><?=book_e(strtoupper($book['file_type']??'PDF'))?></span><h3><?=book_e($book['title'])?></h3><p class="book-muted"><?=book_e($book['author']?:'Unknown author')?></p></div>
      <div class="book-progress"><span id="readerProgressBar" style="width:0"></span></div><p id="readerStatus" class="book-muted">Loading secure reader…</p>
      <div id="scannedWarning" class="book-alert warn" hidden>Scanned PDF detected. Text selection and voice reading may be limited until OCR is configured.</div>
      <?php if(BOOK_CONFIG['security']['watermark_reader']):?><div class="reader-watermark-note">Protected session: <?=book_e(book_current_user()['email'])?></div><?php endif;?>
      <hr><h4>Reading session</h4><div class="reader-stat-row"><span>Timer</span><strong id="readingTimer">00:00:00</strong></div><div class="reader-stat-row"><span>Estimated left</span><strong id="estimatedTime">Calculating</strong></div><div class="reader-stat-row"><span>Wake lock</span><strong id="wakeLockStatus">Starting…</strong></div>
      <div id="readerSideData"></div>
    </aside>

    <section class="book-reader-main">
      <div class="book-reader-toolbar" role="toolbar" aria-label="Reader controls">
        <a class="book-btn small secondary" href="<?=book_url('books.php')?>">← Library</a>
        <button id="prevPage" class="book-btn small secondary" type="button" aria-label="Previous page">Prev</button>
        <input id="pageInput" class="book-input page-number-input" type="number" min="1" value="<?=$startPage?>" aria-label="Page number"><span class="book-muted">/ <span id="totalPages"><?=(int)$book['total_pages']?></span></span>
        <button id="nextPage" class="book-btn small secondary" type="button" aria-label="Next page">Next</button>
        <button id="zoomOut" class="book-btn small secondary" type="button">−</button><span id="zoomLabel" class="book-pill">125%</span><button id="zoomIn" class="book-btn small secondary" type="button">+</button>
        <button id="fitWidth" class="book-btn small secondary" type="button">Fit</button>
        <select id="layoutMode" class="book-select toolbar-select" aria-label="Reading layout"><option value="single">Single page</option><option value="continuous">Scroll</option><option value="two">Double page</option></select>
        <button id="bookmarkBtn" class="book-btn small secondary" type="button">Bookmark</button>
        <button id="focusMode" class="book-btn small secondary" type="button">Focus</button>
        <button id="fullscreenBtn" class="book-btn small secondary" type="button">Fullscreen</button>
        <button id="offlineBtn" class="book-btn small secondary" type="button">Save offline</button>
        <button id="readerSettingsBtn" class="book-btn small secondary" type="button">Aa Settings</button>
      </div>
      <div id="readerSettings" class="reader-settings" hidden>
        <div><label>Theme</label><div class="book-actions"><button class="book-btn small secondary" data-book-mode="light">Light</button><button class="book-btn small secondary" data-book-mode="sepia">Sepia</button><button class="book-btn small secondary" data-book-mode="night">Night</button><button class="book-btn small secondary" data-book-mode="contrast">High contrast</button></div></div>
        <label class="toggle-row"><input id="keepAwakeToggle" type="checkbox" checked> Keep screen awake while reading</label>
        <label>Brightness <input id="brightnessRange" type="range" min="55" max="120" value="100"></label>
        <label>Orientation <select id="orientationMode" class="book-select"><option value="auto">Auto rotate</option><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></label>
        <?php if(($book['file_type']??'pdf')==='pdf'):?>
        <label>PDF display <select id="readerViewMode" class="book-select"><option value="original">Original page</option><option value="reflow">Reflow text (best for mobile)</option></select></label>
        <small id="readerTypographyHelp" class="book-form-help">Font and spacing controls apply in Reflow text mode. Original page mode uses zoom.</small>
        <?php endif;?>
        <label>Font size <input id="fontSizeRange" type="range" min="80" max="180" value="100"></label>
        <label>Line height <input id="lineHeightRange" type="range" min="120" max="240" value="160"></label>
        <label>Letter spacing <input id="letterSpacingRange" type="range" min="0" max="12" value="0"></label>
        <label>Margins <input id="marginRange" type="range" min="0" max="80" value="24"></label>
        <label class="toggle-row"><input id="dyslexiaToggle" type="checkbox"> Dyslexia-friendly font</label>
        <label class="toggle-row"><input id="autoScrollToggle" type="checkbox"> Auto scroll and advance pages</label>
      </div>
      <div id="bookPdfArea" class="book-pdf-area" tabindex="0" aria-label="Book content"></div>
    </section>

    <aside class="book-reader-tools">
      <h3>Reader tools</h3><p class="book-muted">Select text in the book, or type text below.</p>
      <label class="book-label">Selected text</label><textarea id="selectedTextPreview" class="book-textarea" placeholder="Select text or type here"></textarea>
      <div class="book-mini-grid"><button id="dictionaryBtn" class="book-btn small secondary">Dictionary</button><button id="translateBtn" class="book-btn small secondary">Translate</button></div>
      <div class="book-mini-grid"><select id="translationTarget" class="book-select"><option value="en">English</option><option value="es">Spanish</option><option value="fr">French</option><option value="de">German</option><option value="it">Italian</option><option value="pt">Portuguese</option><option value="ar">Arabic</option><option value="hi">Hindi</option><option value="bn">Bengali</option><option value="zh">Chinese</option><option value="ja">Japanese</option><option value="ko">Korean</option><option value="tr">Turkish</option><option value="ru">Russian</option></select><button id="copyToolText" class="book-btn small secondary">Copy</button></div>
      <hr><label class="book-label">Quick page note</label><textarea id="quickNote" class="book-textarea" placeholder="Write a private note…"></textarea><button id="saveNoteBtn" class="book-btn small">Save note</button>
      <hr><label class="book-label">Voice reading</label><select id="speechVoice" class="book-select"><option value="__auto_male__">Auto-select male voice</option></select><div class="book-mini-grid"><label>Speed<input id="speechRate" class="book-input" type="number" step="0.1" min="0.5" max="2.5" value="1"></label><label>Pitch<input id="speechPitch" class="book-input" type="number" step="0.1" min="0.5" max="2" value="1"></label></div><input id="speechStartText" class="book-input" placeholder="Optional phrase to start from"><label class="toggle-row"><input id="speechFollowToggle" type="checkbox" checked> Follow spoken text automatically</label><label class="toggle-row"><input id="speechAutoNextToggle" type="checkbox" checked> Continue on the next page</label><div class="book-actions"><button id="useSelectionStart" class="book-btn small secondary">Use selection</button><button id="readAloudBtn" class="book-btn small secondary">Play</button><button id="pauseSpeechBtn" class="book-btn small secondary">Pause</button><button id="resumeSpeechBtn" class="book-btn small secondary">Resume</button><button id="stopSpeechBtn" class="book-btn small secondary">Stop</button></div><div class="speech-page-progress" aria-hidden="true"><span id="speechPageProgress"></span></div><small id="speechStatus" class="book-muted">Voice availability depends on the device.</small>
      <hr><h4>Premium focus</h4><div class="book-mini-grid"><select id="focusMinutes" class="book-select"><option value="25">25 min Pomodoro</option><option value="45">45 min focus</option><option value="60">60 min deep read</option></select><button id="focusTimerBtn" class="book-btn small secondary">Start timer</button></div><select id="ambientSound" class="book-select"><option value="off">Ambient sound off</option><option value="white">White noise</option><option value="rain">Rain</option><option value="forest">Forest</option><option value="ocean">Ocean</option></select><div id="focusCountdown" class="focus-countdown"></div>
      <div id="toolResult" class="book-tool-result"></div>
    </aside>
  </div>
</main>
<div id="readerWatermark" class="reader-watermark" aria-hidden="true"><?=book_e(book_current_user()['email'])?> · <?=date('Y-m-d')?></div>
<div id="selectionPopup" class="book-selection-popup"><button data-highlight="yellow" title="Important">🟨</button><button data-highlight="green" title="Definition">🟩</button><button data-highlight="blue" title="Example">🟦</button><button data-highlight="red" title="Revision">🟥</button><button data-highlight="purple" title="Quote">🟪</button><button data-highlight="orange" title="Exam question">🟧</button></div>
<div id="readerDndPrompt" class="reader-dnd-prompt" hidden role="dialog" aria-modal="true" aria-labelledby="readerDndTitle">
  <div class="reader-dnd-card">
    <h3 id="readerDndTitle">Turn on Do Not Disturb for uninterrupted reading</h3>
    <p>Websites cannot switch Android Do Not Disturb on by themselves. Enable it from your phone before you continue.</p>
    <ol class="reader-dnd-steps"><li>Swipe down from the top of the screen.</li><li>Tap <strong>Do Not Disturb</strong> or <strong>Focus mode</strong>.</li><li>Return to ReadVault and continue reading.</li></ol>
    <div class="book-actions"><button id="readerDndDone" class="book-btn">I enabled DND</button><button id="readerDndLater" class="book-btn secondary">Not now</button><button id="readerDndNever" class="book-btn secondary">Do not remind me</button></div>
  </div>
</div>
<script>window.BOOK_READER=<?=json_encode(['bookId'=>$bookId,'currentPage'=>$startPage,'startLocation'=>$startLocation,'fileType'=>$book['file_type']??'pdf','streamUrl'=>$streamUrl,'title'=>$book['title'],'fileSize'=>(int)$book['file_size'],'totalPages'=>(int)$book['total_pages'],'premium'=>book_is_premium()],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)?>;</script>
<?php if(($book['file_type']??'pdf')==='pdf'):?><script src="<?=book_asset('js/reader.js')?>?v=2.3.0"></script><?php else:?><script src="<?=book_asset('js/epub-reader.js')?>?v=2.3.0"></script><?php endif;?>
<script src="<?=book_asset('js/reader-enhancements.js')?>?v=2.3.0"></script>
<?php book_render_footer(false); ?>
