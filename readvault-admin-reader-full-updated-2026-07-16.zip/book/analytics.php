<?php
require_once __DIR__ . '/includes/bootstrap.php'; book_require_login();
$db=book_db();$uid=book_user_id();
$queries=[
 'Books Uploaded'=>'SELECT COUNT(*) FROM book_books WHERE user_id=?',
 'Books Completed'=>'SELECT COUNT(*) FROM book_books WHERE user_id=? AND reading_status="completed"',
 'Pages Read'=>'SELECT COALESCE(SUM(pages_read),0) FROM book_reading_sessions WHERE user_id=?',
 'Hours Read'=>'SELECT ROUND(COALESCE(SUM(duration_seconds),0)/3600,1) FROM book_reading_sessions WHERE user_id=?',
 'Reading Sessions'=>'SELECT COUNT(*) FROM book_reading_sessions WHERE user_id=?',
 'Vocabulary Learned'=>'SELECT COUNT(*) FROM book_vocabulary WHERE user_id=?',
 'Highlights'=>'SELECT COUNT(*) FROM book_highlights WHERE user_id=?',
 'Notes'=>'SELECT COUNT(*) FROM book_notes WHERE user_id=?'
];$stats=[];foreach($queries as $label=>$sql){$st=$db->prepare($sql);$st->execute([$uid]);$stats[$label]=$st->fetchColumn();}
$stmt=$db->prepare('SELECT b.title, COUNT(h.id) total FROM book_highlights h JOIN book_books b ON h.book_id=b.id WHERE h.user_id=? GROUP BY b.id ORDER BY total DESC LIMIT 5');$stmt->execute([$uid]);$top=$stmt->fetchAll(PDO::FETCH_ASSOC);
book_render_header('Reading Analytics','book-analytics');
?>
<main class="book-app"><div class="book-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><section class="book-content"><div class="book-topbar"><div class="book-title"><h1>Reading Analytics</h1><p>Track reading speed, sessions, completion, and learning progress.</p></div></div><div class="book-grid"><?php foreach($stats as $k=>$v): ?><div class="book-card book-stat"><span class="book-muted"><?= book_e($k) ?></span><strong><?= book_e($v) ?></strong></div><?php endforeach; ?><div class="book-card book-span-12"><h3>Most Highlighted Books</h3><?php foreach($top as $r): ?><div class="book-kv-item"><strong><?= book_e($r['title']) ?></strong><span class="book-chip"><?= (int)$r['total'] ?> highlights</span></div><?php endforeach; if(!$top): ?><p class="book-muted">No highlights yet.</p><?php endif; ?></div></div></section></div></main><?php book_render_footer(); ?>
