<?php
require_once __DIR__ . '/includes/bootstrap.php'; book_require_login();
$db = book_db();
$userId = book_user_id();
$q = trim($_GET['q'] ?? '');
$sql = 'SELECT * FROM book_books WHERE user_id=?';
$params = [$userId];
if($q !== '') { $sql .= ' AND (title LIKE ? OR author LIKE ? OR category LIKE ?)'; $params[]="%$q%"; $params[]="%$q%"; $params[]="%$q%"; }
$sql .= ' ORDER BY uploaded_at DESC';
$stmt = $db->prepare($sql); $stmt->execute($params); $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
book_render_header('My Library','book-library');
?>
<main class="book-app"><div class="book-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><section class="book-content">
<div class="book-topbar"><div class="book-title"><h1>My Library</h1><p>All your uploaded PDF books.</p></div><a class="book-btn" href="<?= book_url('upload.php') ?>">Upload Book</a></div>
<div class="book-card"><form method="get" class="book-actions"><input class="book-input" style="max-width:420px" name="q" value="<?= book_e($q) ?>" placeholder="Search title, author, category"><button class="book-btn secondary">Search</button></form></div>
<div class="book-grid" style="margin-top:18px">
<?php foreach($books as $b): $pct=$b['total_pages']?min(100,round($b['current_page']/$b['total_pages']*100)):0; ?>
<div class="book-card book-span-4" data-book='<?= book_e(json_encode($b, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>'><span class="book-chip"><?= book_e($b['reading_status']) ?></span><h3><?= book_e($b['title']) ?></h3><p class="book-muted"><?= book_e($b['author'] ?: 'Unknown author') ?><?= $b['category']?' · '.book_e($b['category']):'' ?></p><div class="book-progress"><span style="width:<?= $pct ?>%"></span></div><p class="book-muted">Page <?= (int)$b['current_page'] ?> / <?= (int)$b['total_pages'] ?></p><div class="book-actions"><a class="book-btn small" href="<?= book_url('reader.php?id='.(int)$b['id']) ?>">Read</a><button class="book-btn small secondary edit-book">Edit</button><button class="book-btn small secondary" onclick="deleteBook(<?= (int)$b['id'] ?>)">Delete</button></div></div>
<?php endforeach; if(!$books): ?><div class="book-card book-span-12"><p class="book-muted">No books found.</p></div><?php endif; ?>
</div></section></div></main>
<script>
async function deleteBook(id){if(!confirm('Delete this book and all related notes/highlights?'))return;const r=await bookApi('api/books.php?action=delete',{id});if(r.success)location.reload();else alert(r.message||'Failed');}
document.querySelectorAll('.edit-book').forEach(btn=>btn.onclick=async()=>{const card=btn.closest('[data-book]');const b=JSON.parse(card.dataset.book);const title=prompt('Book title',b.title||'');if(title===null)return;const author=prompt('Author',b.author||'');if(author===null)return;const category=prompt('Category',b.category||'');if(category===null)return;const reading_status=prompt('Status: not_started, reading, completed, archived',b.reading_status||'reading')||b.reading_status;const r=await bookApi('api/books.php?action=update',{id:b.id,title,author,category,reading_status});if(r.success)location.reload();else alert(r.message||'Failed');});
</script>
<?php book_render_footer(); ?>
