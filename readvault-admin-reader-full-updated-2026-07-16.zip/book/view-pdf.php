<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
book_require_login();
$db = book_db();
$bookId = (int)($_GET['id'] ?? 0);
$token = (string)($_GET['token'] ?? '');
$claims = book_verify_signed_token($token);
if (!$claims || (int)($claims['book_id'] ?? 0) !== $bookId || (int)($claims['user_id'] ?? 0) !== book_user_id() || ($claims['scope'] ?? '') !== 'read') {
    http_response_code(403); exit('Invalid or expired reading token.');
}
$book = book_fetch_user_book($db, $bookId, book_user_id());
if (!$book) { http_response_code(404); exit('Book not found.'); }
try { $path = book_absolute_storage_path((string)$book['file_path']); } catch (Throwable) { http_response_code(404); exit('File missing.'); }
if (!is_file($path)) { http_response_code(404); exit('File missing.'); }
$size = filesize($path);$start=0;$end=$size-1;$status=200;
if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
    $start = $m[1] === '' ? 0 : (int)$m[1];
    $end = $m[2] === '' ? $size - 1 : min((int)$m[2], $size - 1);
    if ($start > $end || $start >= $size) { header('Content-Range: bytes */'.$size); http_response_code(416); exit; }
    $status = 206;
}
http_response_code($status);
header('Content-Type: '.(($book['file_type'] ?? 'pdf') === 'epub' ? 'application/epub+zip' : 'application/pdf'));
header('Content-Disposition: inline; filename="'.rawurlencode((string)($book['original_filename'] ?: 'book.'.($book['file_type'] ?? 'pdf'))).'"');
header('Accept-Ranges: bytes');
header('Content-Length: '.($end-$start+1));
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
if ($status===206) header("Content-Range: bytes $start-$end/$size");
$fp=fopen($path,'rb');fseek($fp,$start);$remaining=$end-$start+1;
while($remaining>0&&!feof($fp)){ $chunk=fread($fp,min(1024*1024,$remaining)); if($chunk===false)break; echo $chunk; $remaining-=strlen($chunk); if(connection_aborted())break; }
fclose($fp);exit;
