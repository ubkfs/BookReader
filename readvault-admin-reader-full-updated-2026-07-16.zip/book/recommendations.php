<?php
require_once __DIR__ . '/includes/bootstrap.php';
book_require_login();
$db = book_db();
$uid = book_user_id();
$st = $db->prepare('SELECT b.*,r.score,r.reason FROM book_recommendations r JOIN book_books b ON b.id=r.book_id WHERE r.user_id=? AND (r.expires_at IS NULL OR r.expires_at>NOW()) ORDER BY r.score DESC LIMIT 30');
$st->execute([$uid]);
$recommendations = $st->fetchAll(PDO::FETCH_ASSOC);
if (!$recommendations) {
    $st = $db->prepare("SELECT b.*,0.5 AS score,'Popular in the catalog' AS reason FROM book_books b WHERE b.access_type='catalog' AND b.is_published=1 AND b.id NOT IN(SELECT book_id FROM book_progress WHERE user_id=?) ORDER BY b.last_opened_at DESC,b.uploaded_at DESC LIMIT 18");
    $st->execute([$uid]);
    $recommendations = $st->fetchAll(PDO::FETCH_ASSOC);
}
book_render_header('Recommendations','recommendations');
?>
<main class="book-app" id="main-content"><div class="book-shell">
<?php include __DIR__ . '/includes/sidebar.php'; ?>
<section class="book-content">
  <div class="book-topbar"><div class="book-title"><h1>For you</h1><p>Personalized suggestions can combine reading history, categories, authors, highlights, and completion behavior.</p></div></div>
  <div class="book-grid">
  <?php foreach ($recommendations as $book): ?>
    <article class="book-card book-span-4"><span class="book-chip">Match <?= (int)round(((float)($book['score'] ?? 0.5))*100) ?>%</span><h3><?= book_e($book['title'] ?? 'Untitled') ?></h3><p class="book-muted"><?= book_e(($book['author'] ?? '') ?: 'Unknown author') ?></p><p><?= book_e(($book['reason'] ?? '') ?: 'Recommended from your reading activity') ?></p><a class="book-btn small" href="<?= book_url('reader.php?id='.(int)($book['id'] ?? 0)) ?>">Read now</a></article>
  <?php endforeach; if (!$recommendations): ?>
    <div class="book-card book-span-12 book-empty"><div class="book-empty-icon">★</div><h3>Recommendations will improve as you read</h3><p class="book-muted">Add catalog titles and record reading sessions to create a personalized feed.</p></div>
  <?php endif; ?>
  </div>
</section></div></main>
<?php book_render_footer(); ?>
