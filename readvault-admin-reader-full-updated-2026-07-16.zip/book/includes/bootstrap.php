<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';

$vendorAutoload = BOOK_MODULE_DIR . '/vendor/autoload.php';
if (is_file($vendorAutoload)) {
    require_once $vendorAutoload;
} else {
    spl_autoload_register(static function (string $class): void {
        $prefix = 'BookSaaS\\';
        if (!str_starts_with($class, $prefix)) return;
        $file = BOOK_MODULE_DIR . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (is_file($file)) require_once $file;
    });
}

\BookSaaS\Core\Session::start($config['session']);

if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(self), fullscreen=(self), screen-wake-lock=(self)');
    header('Cross-Origin-Resource-Policy: same-origin');
    if ($config['security']['csp']) {
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://checkout.razorpay.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: blob: https:; font-src 'self' data: https://cdn.jsdelivr.net; connect-src 'self' https://api.dictionaryapi.dev https://api.mymemory.translated.net https://api.stripe.com https://api.razorpay.com; media-src 'self' blob:; worker-src 'self' blob:; frame-src https://api.razorpay.com https://checkout.razorpay.com; frame-ancestors 'self'; base-uri 'self'; form-action 'self' https://checkout.stripe.com https://api.razorpay.com");
    }
}

function book_config(?string $key = null, mixed $default = null): mixed {
    $value = BOOK_CONFIG;
    if ($key === null) return $value;
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) return $default;
        $value = $value[$segment];
    }
    return $value;
}

function book_db(): ?PDO {
    static $db = false;
    if ($db instanceof PDO) return $db;
    try { $db = \BookSaaS\Core\Database::connection(BOOK_CONFIG['database']); return $db; }
    catch (Throwable $e) {
        if (BOOK_CONFIG['app']['debug']) throw $e;
        error_log($e->getMessage());
        return null;
    }
}

function book_auth(): ?\BookSaaS\Core\Auth {
    static $auth = null;
    $db = book_db();
    if (!$db) return null;
    return $auth ??= new \BookSaaS\Core\Auth($db, BOOK_CONFIG);
}

book_auth()?->restoreRememberedLogin();

function book_is_logged_in(): bool { return book_auth()?->check() ?? false; }
function book_current_user(): ?array { return book_auth()?->user(); }
function book_user_id(): int { return (int)(book_current_user()['id'] ?? 0); }

function book_subscription(): ?array {
    static $cache = [];
    $uid = book_user_id();
    if (!$uid || !book_db()) return null;
    if (!array_key_exists($uid, $cache)) $cache[$uid] = (new \BookSaaS\Services\SubscriptionService(book_db()))->current($uid);
    return $cache[$uid];
}
function book_user_plan(): string { return (string)(book_subscription()['code'] ?? 'free'); }
function book_is_premium(): bool { return book_user_id() > 0 && (new \BookSaaS\Services\SubscriptionService(book_db()))->isPremium(book_user_id()); }

function book_admin_permissions(): array {
    static $cache = [];
    $uid=book_user_id();
    if(!$uid) return [];
    if(isset($cache[$uid])) return $cache[$uid];
    $role=(string)(book_current_user()['role']??'');
    if($role==='super_admin') return $cache[$uid]=['*'];
    $db=book_db();if(!$db)return $cache[$uid]=[];
    try{
        $st=$db->prepare('SELECT role_id FROM book_users WHERE id=? LIMIT 1');$st->execute([$uid]);$roleId=(int)$st->fetchColumn();
        if(!$roleId){$st=$db->prepare('SELECT id FROM book_roles WHERE code=? LIMIT 1');$st->execute([$role]);$roleId=(int)$st->fetchColumn();}
        $permissions=[];
        if($roleId){$st=$db->prepare('SELECT p.code FROM book_role_permissions rp JOIN book_permissions p ON p.id=rp.permission_id WHERE rp.role_id=?');$st->execute([$roleId]);$permissions=array_values(array_unique(array_map('strval',$st->fetchAll(PDO::FETCH_COLUMN))));}
        // Legacy administrator accounts remain usable until the permission migration is applied.
        if(!$permissions&&$role==='admin')$permissions=['*'];
        return $cache[$uid]=$permissions;
    }catch(Throwable){return $cache[$uid]=in_array($role,['admin','super_admin'],true)?['*']:[];}
}
function book_can(string $permission): bool {
    $permissions=book_admin_permissions();
    if(in_array('*',$permissions,true)||in_array($permission,$permissions,true))return true;
    if(str_ends_with($permission,'.view')){
        $module=substr($permission,0,-5);
        return in_array($module.'.manage',$permissions,true)||in_array($module.'.delete',$permissions,true);
    }
    return false;
}
function book_is_admin(): bool { return book_user_id()>0 && (in_array((string)(book_current_user()['role']??''),['admin','super_admin'],true)||book_admin_permissions()!==[]); }

function book_require_login(): void {
    if (book_is_logged_in()) return;
    $redirect = $_SERVER['REQUEST_URI'] ?? book_url('index.php');
    header('Location: ' . book_url('auth/login.php?redirect=' . rawurlencode($redirect)));
    exit;
}
function book_require_admin(?string $permission = null): void {
    book_require_login();
    if (!book_is_admin() || ($permission!==null&&!book_can($permission))) { http_response_code(403); exit('Access denied.'); }
}

function book_e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function book_json(array $payload, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
function book_csrf_token(): string {
    if (empty($_SESSION['book_csrf_token'])) $_SESSION['book_csrf_token'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['book_csrf_token'];
}
function book_verify_csrf(): void {
    $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || empty($_SESSION['book_csrf_token']) || !hash_equals((string)$_SESSION['book_csrf_token'], (string)$token)) {
        if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') || str_contains($_SERVER['REQUEST_URI'] ?? '', '/api/')) book_json(['success'=>false,'message'=>'Invalid security token.'], 419);
        http_response_code(419); exit('Invalid security token.');
    }
}
function book_asset(string $path): string { return rtrim(BOOK_BASE_URL, '/') . '/assets/' . ltrim($path, '/'); }
function book_url(string $path = ''): string { return rtrim(BOOK_BASE_URL, '/') . ($path !== '' ? '/' . ltrim($path, '/') : ''); }
function book_safe_redirect(string $candidate, string $fallback = 'index.php'): string {
    $candidate = trim(str_replace(["\r", "\n"], '', $candidate));
    if ($candidate === '' || str_starts_with($candidate, '//') || str_starts_with($candidate, '\\')) return book_url($fallback);
    $base = parse_url(BOOK_BASE_URL) ?: [];
    $parts = parse_url($candidate);
    if ($parts === false) return book_url($fallback);
    if (isset($parts['scheme']) || isset($parts['host'])) {
        $sameScheme = strtolower((string)($parts['scheme'] ?? '')) === strtolower((string)($base['scheme'] ?? ''));
        $sameHost = strtolower((string)($parts['host'] ?? '')) === strtolower((string)($base['host'] ?? ''));
        $samePort = (int)($parts['port'] ?? 0) === (int)($base['port'] ?? 0);
        if (!$sameScheme || !$sameHost || !$samePort) return book_url($fallback);
    }
    $path = (string)($parts['path'] ?? '');
    $basePath = rtrim((string)($base['path'] ?? ''), '/');
    if ($path === '' || !str_starts_with($path, '/') || ($basePath !== '' && $path !== $basePath && !str_starts_with($path, $basePath . '/'))) return book_url($fallback);
    return $candidate;
}

function book_render_header(string $title = 'Book Reader', string $activePage = 'book', string $description = ''): void {
    $GLOBALS['pageTitle'] = $title; $GLOBALS['activePage'] = $activePage;
    if ($description !== '') $GLOBALS['pageDescription'] = $description;
    include BOOK_MODULE_DIR . '/includes/header.php';
}
function book_render_footer(bool $unused = false): void { include BOOK_MODULE_DIR . '/includes/footer.php'; }

function book_plan_book_limit(): int {
    $limit = (int)(book_subscription()['book_limit'] ?? 10);
    return $limit <= 0 ? 999999 : $limit;
}
function book_storage_user_dir(int $userId): string {
    $dir = BOOK_STORAGE_DIR . '/user_' . $userId;
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Unable to create book storage directory.');
    return $dir;
}
function book_public_storage_path(string $absolutePath): string { return ltrim(str_replace(BOOK_MODULE_DIR, '', $absolutePath), '/'); }
function book_absolute_storage_path(string $storedPath): string {
    $candidate = realpath(BOOK_MODULE_DIR . '/' . ltrim($storedPath, '/'));
    $root = realpath(BOOK_MODULE_DIR . '/storage');
    if (!$candidate || !$root || !str_starts_with($candidate, $root)) throw new RuntimeException('Invalid storage path.');
    return $candidate;
}
function book_format_seconds(int $seconds): string { $h=intdiv($seconds,3600);$m=intdiv($seconds%3600,60);return $h>0?$h.'h '.$m.'m':$m.'m'; }

/** Return the ISO-4217 minor-unit exponent used by payment gateways. */
function book_currency_exponent(string $currency): int {
    $currency = strtoupper(trim($currency));
    $zeroDecimal = ['BIF','CLP','DJF','GNF','JPY','KMF','KRW','MGA','PYG','RWF','UGX','VND','VUV','XAF','XOF','XPF'];
    $threeDecimal = ['BHD','IQD','JOD','KWD','LYD','OMR','TND'];
    if (in_array($currency, $zeroDecimal, true)) return 0;
    if (in_array($currency, $threeDecimal, true)) return 3;
    return 2;
}
function book_money_to_minor(int|float|string $amount, string $currency): int {
    $factor = 10 ** book_currency_exponent($currency);
    return (int)round(max(0, (float)$amount) * $factor);
}
function book_money_from_minor(int $minor, string $currency): float {
    return $minor / (10 ** book_currency_exponent($currency));
}
function book_currency_step(string $currency): string {
    return match (book_currency_exponent($currency)) { 0 => '1', 3 => '0.001', default => '0.01' };
}
function book_format_money(int $minor, string $currency, bool $withCode = true): string {
    $currency = strtoupper(trim($currency ?: 'USD'));
    $number = number_format(book_money_from_minor($minor, $currency), book_currency_exponent($currency), '.', ',');
    return $withCode ? $currency . ' ' . $number : $number;
}

/** Preferred billing currency based on the account country. Prices remain admin-configured; no unsafe live FX conversion is attempted. */
function book_country_currency(string $countryCode): string {
    $countryCode = strtoupper(trim($countryCode));
    $map = [
        'US'=>'USD','JP'=>'JPY','IN'=>'INR','GB'=>'GBP','BD'=>'BDT','PK'=>'PKR','LK'=>'LKR','NP'=>'NPR',
        'CA'=>'CAD','AU'=>'AUD','NZ'=>'NZD','SG'=>'SGD','MY'=>'MYR','ID'=>'IDR','PH'=>'PHP','TH'=>'THB','VN'=>'VND',
        'CN'=>'CNY','HK'=>'HKD','TW'=>'TWD','KR'=>'KRW','AE'=>'AED','SA'=>'SAR','QA'=>'QAR','KW'=>'KWD','BH'=>'BHD','OM'=>'OMR',
        'ZA'=>'ZAR','NG'=>'NGN','KE'=>'KES','GH'=>'GHS','EG'=>'EGP','TR'=>'TRY','IL'=>'ILS','BR'=>'BRL','MX'=>'MXN','AR'=>'ARS',
        'CL'=>'CLP','CO'=>'COP','PE'=>'PEN','CH'=>'CHF','NO'=>'NOK','SE'=>'SEK','DK'=>'DKK','PL'=>'PLN','CZ'=>'CZK','HU'=>'HUF',
        'RO'=>'RON','RU'=>'RUB','UA'=>'UAH','IS'=>'ISK','RS'=>'RSD','BG'=>'BGN','HR'=>'EUR',
        'AT'=>'EUR','BE'=>'EUR','CY'=>'EUR','EE'=>'EUR','FI'=>'EUR','FR'=>'EUR','DE'=>'EUR','GR'=>'EUR','IE'=>'EUR','IT'=>'EUR',
        'LV'=>'EUR','LT'=>'EUR','LU'=>'EUR','MT'=>'EUR','NL'=>'EUR','PT'=>'EUR','SK'=>'EUR','SI'=>'EUR','ES'=>'EUR',
    ];
    return $map[$countryCode] ?? strtoupper((string)book_config('payments.currency', 'USD'));
}
function book_active_plan_currencies(PDO $db, ?string $countryCode = null): array {
    try {
        if ($countryCode !== null && trim($countryCode) !== '') {
            $st = $db->prepare('SELECT DISTINCT currency FROM book_plan_prices WHERE is_active=1 AND (country_code=? OR country_code IS NULL) ORDER BY currency');
            $st->execute([strtoupper(trim($countryCode))]);
            $rows = $st->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $rows = $db->query('SELECT DISTINCT currency FROM book_plan_prices WHERE is_active=1 ORDER BY currency')->fetchAll(PDO::FETCH_COLUMN);
        }
        return array_values(array_filter(array_map(static fn($c)=>strtoupper((string)$c), $rows ?: []), static fn($c)=>(bool)preg_match('/^[A-Z]{3}$/',$c)));
    } catch (Throwable) { return []; }
}
function book_resolve_billing_currency(PDO $db, string $countryCode, ?string $requested = null): string {
    $available = book_active_plan_currencies($db, $countryCode);
    $requested = strtoupper(trim((string)$requested));
    if ($requested !== '' && in_array($requested, $available, true)) return $requested;
    $preferred = book_country_currency($countryCode);
    if (in_array($preferred, $available, true)) return $preferred;
    $default = strtoupper((string)book_config('payments.currency', 'USD'));
    if (in_array($default, $available, true)) return $default;
    return $available[0] ?? $preferred;
}
function book_find_plan_price(PDO $db, int $planId, string $countryCode, string $currency): ?array {
    $countryCode = strtoupper(trim($countryCode));
    $currency = strtoupper(trim($currency));
    $sql = 'SELECT * FROM book_plan_prices WHERE plan_id=? AND is_active=1 AND currency=? AND (country_code=? OR country_code IS NULL)
            ORDER BY CASE WHEN country_code=? THEN 0 ELSE 1 END, id LIMIT 1';
    $st = $db->prepare($sql); $st->execute([$planId,$currency,$countryCode,$countryCode]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}
function book_rate_limit(string $key, int $limit = 20, int $seconds = 60): void {
    $key = hash('sha256', $key . '|' . book_user_id() . '|' . ($_SERVER['REMOTE_ADDR'] ?? ''));
    $now=time(); $_SESSION['book_rate'][$key]=array_values(array_filter($_SESSION['book_rate'][$key]??[],fn($t)=>$t>$now-$seconds));
    if(count($_SESSION['book_rate'][$key]) >= $limit) book_json(['success'=>false,'message'=>'Too many requests. Please try again later.'],429);
    $_SESSION['book_rate'][$key][]=$now;
}

function book_normalize_quiz_word(string $text): ?string {
    $word=trim($text);$word=preg_replace('/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/u','',$word);$word=trim((string)$word);
    if($word===''||preg_match('/\s/u',$word)||!preg_match('/^[\p{L}\p{N}][\p{L}\p{N}\-\'’]*$/u',$word)||mb_strlen($word)>120)return null;
    return $word;
}
function book_is_single_quiz_word(string $text): bool { return book_normalize_quiz_word($text)!==null; }

function book_upsert_vocabulary_word(PDO $db,int $userId,string $word,array $fields=[]): int {
    $word=book_normalize_quiz_word($word)?:trim($word);$bookId=(int)($fields['book_id']??0)?:null;$chapterId=(int)($fields['chapter_id']??0)?:null;$sourcePage=(int)($fields['source_page']??0)?:null;
    $stmt=$db->prepare('SELECT id FROM book_vocabulary WHERE user_id=? AND LOWER(word)=LOWER(?) AND ((book_id IS NULL AND ? IS NULL) OR book_id=?) LIMIT 1');$stmt->execute([$userId,$word,$bookId,$bookId]);$id=(int)$stmt->fetchColumn();
    $allowed=['meaning','simple_meaning','bengali_meaning','hindi_meaning','synonyms','antonyms','pronunciation','example_sentence','part_of_speech'];
    if($id){$sets=[];$params=[];foreach($allowed as $key){if(array_key_exists($key,$fields)&&trim((string)$fields[$key])!==''){$sets[]="$key=?";$params[]=$fields[$key];}}if($chapterId){$sets[]='chapter_id=?';$params[]=$chapterId;}if($sourcePage){$sets[]='source_page=?';$params[]=$sourcePage;}$sets[]='next_review_at=COALESCE(next_review_at,DATE_ADD(NOW(),INTERVAL 1 DAY))';$sets[]='updated_at=NOW()';$params[]=$id;$params[]=$userId;$db->prepare('UPDATE book_vocabulary SET '.implode(',',$sets).' WHERE id=? AND user_id=?')->execute($params);return $id;}
    $columns=['user_id','book_id','chapter_id','word','source_page','next_review_at'];$holders=['?','?','?','?','?','DATE_ADD(NOW(),INTERVAL 1 DAY)'];$params=[$userId,$bookId,$chapterId,$word,$sourcePage];foreach($allowed as $key){$columns[]=$key;$holders[]='?';$params[]=trim((string)($fields[$key]??''))!==''?$fields[$key]:null;}$db->prepare('INSERT INTO book_vocabulary ('.implode(',',$columns).') VALUES ('.implode(',',$holders).')')->execute($params);return (int)$db->lastInsertId();
}

function book_log(string $action,?string $entityType=null,?int $entityId=null,array $metadata=[]): void {
    $db=book_db();if(!$db)return;try{$db->prepare('INSERT INTO book_activity_logs (user_id,action,entity_type,entity_id,ip_address,user_agent,metadata) VALUES (?,?,?,?,?,?,?)')->execute([book_user_id()?:null,$action,$entityType,$entityId,$_SERVER['REMOTE_ADDR']??null,$_SERVER['HTTP_USER_AGENT']??null,$metadata?json_encode($metadata,JSON_UNESCAPED_UNICODE):null]);}catch(Throwable){}
}
function book_encrypt(string $plain): string { $key=hash('sha256',BOOK_SECRET,true);$iv=random_bytes(12);$tag='';$cipher=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return base64_encode($iv.$tag.$cipher); }
function book_decrypt(string $encoded): ?string { $raw=base64_decode($encoded,true);if(!$raw||strlen($raw)<29)return null;$key=hash('sha256',BOOK_SECRET,true);$iv=substr($raw,0,12);$tag=substr($raw,12,16);$cipher=substr($raw,28);$plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return $plain===false?null:$plain; }
function book_fetch_user_book(PDO $db,int $bookId,int $userId): ?array { $st=$db->prepare('SELECT * FROM book_books WHERE id=? AND (user_id=? OR access_type="catalog") LIMIT 1');$st->execute([$bookId,$userId]);$b=$st->fetch();if(!$b)return null;if(($b['access_type']??'personal')==='catalog'&&!book_is_premium()&&!empty($b['requires_subscription']))return null;return $b; }
function book_table_name(string $table): string {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) throw new InvalidArgumentException('Invalid table name.');
    $aliases = [
        'authors' => 'book_author_profiles',
        'genres' => 'book_genre_catalog',
        'notifications' => 'book_user_notifications',
        'translations' => 'book_ui_translations',
    ];
    if (isset($aliases[$table])) return $aliases[$table];
    $prefix = (string)(BOOK_CONFIG['database']['table_prefix'] ?? 'book_');
    return $prefix === '' || str_starts_with($table, $prefix) ? $table : $prefix . $table;
}
function book_table_exists(PDO $db,string $table): bool { try{$st=$db->query('SHOW TABLES LIKE '.$db->quote(book_table_name($table)));return(bool)$st->fetchColumn();}catch(Throwable){return false;} }
function book_signed_token(array $claims,int $ttl=null): string { return (new \BookSaaS\Services\SignedUrlService(BOOK_CONFIG['app']['signed_url_secret']))->sign($claims,$ttl??BOOK_CONFIG['security']['signed_url_ttl']); }
function book_verify_signed_token(string $token): ?array { return (new \BookSaaS\Services\SignedUrlService(BOOK_CONFIG['app']['signed_url_secret']))->verify($token); }
function book_feature(string $key,bool $fallback=false): bool { $db=book_db();return $db?(new \BookSaaS\Services\FeatureFlagService($db,BOOK_CONFIG['features'],book_user_id()))->enabled($key,$fallback):(bool)(BOOK_CONFIG['features'][$key]??$fallback); }

function book_secure_setting(string $key, string $default = ''): string {
    static $cache = [];
    if (array_key_exists($key, $cache)) return $cache[$key];
    $db = book_db();
    if (!$db || !book_table_exists($db, 'app_settings')) return $cache[$key] = $default;
    try {
        $st = $db->prepare('SELECT setting_value,value_type FROM book_app_settings WHERE setting_key=? LIMIT 1');
        $st->execute([$key]);
        $row = $st->fetch();
        if (!$row) return $cache[$key] = $default;
        $value = (string)($row['setting_value'] ?? '');
        return $cache[$key] = (($row['value_type'] ?? '') === 'encrypted' ? (book_decrypt($value) ?? $default) : $value);
    } catch (Throwable) { return $cache[$key] = $default; }
}

function book_render_email_template_row(array $row, array $variables = []): array {
    $replace=[];
    foreach($variables as $key=>$value)$replace['{{'.$key.'}}']=(string)$value;
    $subject=strtr((string)($row['subject']??''),$replace);
    $html=strtr((string)($row['html_body']??''),$replace);
    $text=strtr((string)($row['text_body']??''),$replace);
    if($text==='')$text=trim(strip_tags(str_replace(['<br>','<br/>','<br />','</p>'],["\n","\n","\n","\n"],$html)));
    return ['subject'=>$subject,'html'=>$html,'text'=>$text];
}
function book_email_template(string $key, array $variables = [], ?string $locale = null, array $fallback = []): array {
    $locale=$locale?:((string)(book_current_user()['locale']??BOOK_CONFIG['app']['locale']??'en'));
    $db=book_db();
    if($db&&book_table_exists($db,'email_templates')){
        try{
            $st=$db->prepare('SELECT * FROM book_email_templates WHERE template_key=? AND is_active=1 AND locale IN (?,"en") ORDER BY (locale=? ) DESC LIMIT 1');
            $st->execute([$key,$locale,$locale]);
            if($row=$st->fetch(PDO::FETCH_ASSOC))return book_render_email_template_row($row,$variables);
        }catch(Throwable){}
    }
    $row=['subject'=>$fallback['subject']??$key,'html_body'=>$fallback['html']??'','text_body'=>$fallback['text']??''];
    return book_render_email_template_row($row,$variables);
}
function book_send_template(string $to,string $key,array $variables=[],?string $locale=null,array $fallback=[]): bool {
    $render=book_email_template($key,$variables,$locale,$fallback);
    return book_mail($to,$render['subject'],$render['html'],$render['text']);
}
function book_mail(string $to, string $subject, string $html, string $text = ''): bool {
    return (new \BookSaaS\Services\MailService(BOOK_CONFIG['mail'], BOOK_CONFIG['app']['debug']))->send($to,$subject,$html,$text);
}

function book_payment_config(string $provider): array {
    $base = BOOK_CONFIG['payments'][$provider] ?? [];
    foreach (array_keys($base) as $field) {
        if (!is_scalar($base[$field])) continue;
        $stored = book_secure_setting('payments.'.$provider.'.'.$field, '');
        if ($stored !== '') $base[$field] = $stored;
    }
    return $base;
}

function book_flash(string $key,?string $value=null): ?string { if($value!==null){$_SESSION['_flash'][$key]=$value;return null;}$v=$_SESSION['_flash'][$key]??null;unset($_SESSION['_flash'][$key]);return $v; }
