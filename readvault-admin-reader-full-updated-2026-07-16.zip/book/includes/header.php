<?php
$title = $pageTitle ?? BOOK_CONFIG['app']['name'];
$description = $pageDescription ?? 'Read, highlight, annotate, and track books anywhere with ReadVault.';
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/book/', PHP_URL_PATH) ?: '/book/';
$basePath = parse_url(BOOK_BASE_URL, PHP_URL_PATH) ?: '/book';
$relativePath = ltrim(str_starts_with($requestPath, $basePath) ? substr($requestPath, strlen($basePath)) : $requestPath, '/');
$canonical = $canonical ?? book_url($relativePath);
$user = book_current_user();
?>
<!doctype html>
<html lang="<?= book_e($user['locale'] ?? BOOK_CONFIG['app']['locale']) ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#5b3df5">
  <meta name="color-scheme" content="light dark">
  <meta name="description" content="<?= book_e($description) ?>">
  <meta name="robots" content="index,follow,max-image-preview:large">
  <link rel="canonical" href="<?= book_e($canonical) ?>">
  <meta property="og:type" content="website">
  <meta property="og:title" content="<?= book_e($title) ?>">
  <meta property="og:description" content="<?= book_e($description) ?>">
  <meta property="og:url" content="<?= book_e($canonical) ?>">
  <meta property="og:site_name" content="<?= book_e(BOOK_CONFIG['app']['name']) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <title><?= book_e($title) ?> · <?= book_e(BOOK_CONFIG['app']['name']) ?></title>
  <link rel="manifest" href="<?= book_url('manifest.json') ?>">
  <link rel="icon" href="<?= book_asset('icons/icon-192.png') ?>">
  <link rel="apple-touch-icon" href="<?= book_asset('icons/icon-192.png') ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <link rel="stylesheet" href="<?= book_asset('css/book.css') ?>?v=2.3.0">
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.8/dist/cdn.min.js"></script>
  <script type="application/ld+json"><?= json_encode([
      '@context'=>'https://schema.org','@type'=>'WebApplication','name'=>BOOK_CONFIG['app']['name'],
      'applicationCategory'=>'EducationalApplication','operatingSystem'=>'Web, Android, Desktop',
      'url'=>BOOK_BASE_URL,'description'=>$description,
      'offers'=>['@type'=>'Offer','category'=>'Subscription']
  ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?></script>
</head>
<body class="readvault-body">
<a class="skip-link" href="#main-content">Skip to content</a>
<header class="saas-header">
  <div class="container-fluid d-flex align-items-center justify-content-between gap-3">
    <a class="saas-brand" href="<?= book_url('index.php') ?>" aria-label="ReadVault home"><span class="brand-mark">R</span><span><strong>ReadVault</strong><small>Independent Book SaaS</small></span></a>
    <nav class="saas-header-actions" aria-label="Account navigation">
      <?php if ($user): ?>
        <button id="readvaultInstallBtn" type="button" class="btn btn-sm btn-primary" hidden>Install app</button>
        <a href="<?= book_url('search.php') ?>" class="btn btn-sm btn-light d-none d-sm-inline-flex">Search</a>
        <a href="<?= book_url('subscription/plans.php') ?>" class="btn btn-sm btn-outline-primary"><?= book_e(ucfirst(book_user_plan())) ?> plan</a>
        <a href="<?= book_url('account/devices.php') ?>" class="btn btn-sm btn-light d-none d-md-inline-flex">Devices</a>
        <span class="user-greeting d-none d-lg-inline">Hi, <?= book_e(explode(' ', $user['name'])[0]) ?></span>
        <a href="<?= book_url('auth/logout.php') ?>" class="btn btn-sm btn-dark">Log out</a>
      <?php else: ?>
        <a href="<?= book_url('auth/login.php') ?>" class="btn btn-sm btn-outline-primary">Log in</a>
        <a href="<?= book_url('auth/register.php') ?>" class="btn btn-sm btn-primary">Create account</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<script>
window.BOOK_BASE_URL=<?= json_encode(BOOK_BASE_URL) ?>;
window.BOOK_BASE_PATH=<?= json_encode(rtrim((string)(parse_url(BOOK_BASE_URL, PHP_URL_PATH) ?: '/book'), '/')) ?>;
window.BOOK_CSRF=<?= json_encode(book_csrf_token()) ?>;
window.READVAULT_USER=<?= json_encode($user ? ['id'=>(int)$user['id'],'name'=>$user['name'],'email'=>$user['email']] : null, JSON_UNESCAPED_UNICODE) ?>;
</script>
