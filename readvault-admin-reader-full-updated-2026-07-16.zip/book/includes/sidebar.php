<?php
$navGroups = [
  'Reading' => [
    ['Dashboard','index.php','⌂'],['My Library','books.php','▤'],['Discover & Search','search.php','⌕'],['Upload Book','upload.php','↑'],
  ],
  'Knowledge' => [
    ['Notes & Highlights','vault.php','✦'],['Vocabulary','vocabulary.php','Aa'],['Revision','revision.php','↻'],['Goals','goals.php','◎'],['Analytics','analytics.php','▥'],
  ],
  'Community' => [
    ['Recommendations','recommendations.php','★'],['Challenges','challenges.php','⚑'],['Wishlist','wishlist.php','♡'],['Family Profiles','family.php','♟'],
  ],
  'Account' => [
    ['Account Center','account/index.php','●'],['Subscription','subscription/plans.php','$'],['Devices','account/devices.php','◫'],['Settings','settings.php','⚙'],['Support','support.php','?'],
  ],
];
$navCurrentPath = trim(str_replace('\\','/', $_SERVER['SCRIPT_NAME'] ?? ''), '/');
?>
<aside class="book-sidebar" id="bookSidebar" aria-label="Primary navigation">
  <div class="book-sidebar-brand"><span class="book-logo-mark">R</span><div><strong>ReadVault</strong><small><?= book_e(ucfirst(book_user_plan())) ?> account</small></div></div>
  <nav>
    <?php foreach ($navGroups as $navGroup => $navItems): ?>
      <div class="book-nav-group"><?= book_e($navGroup) ?></div>
      <?php foreach ($navItems as [$navLabel,$navHref,$navIcon]): $navActive = str_ends_with($navCurrentPath, $navHref); ?>
        <a class="book-nav-link <?= $navActive ? 'active' : '' ?>" href="<?= book_url($navHref) ?>"><span aria-hidden="true"><?= $navIcon ?></span><span><?= book_e($navLabel) ?></span></a>
      <?php endforeach; ?>
    <?php endforeach; ?>
    <?php if (book_is_admin()): ?>
      <div class="book-nav-group">Administration</div>
      <a class="book-nav-link <?= str_contains($navCurrentPath,'admin/') ? 'active' : '' ?>" href="<?= book_url('admin/index.php') ?>"><span>◆</span><span>Admin Console</span></a>
    <?php endif; ?>
  </nav>
</aside>
<?php unset($navGroups,$navCurrentPath,$navGroup,$navItems,$navLabel,$navHref,$navIcon,$navActive); ?>
