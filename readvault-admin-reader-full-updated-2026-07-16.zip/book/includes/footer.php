<footer class="saas-footer">
  <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center gap-3">
    <span>© <?= date('Y') ?> ReadVault</span>
    <span><a href="<?= book_url('privacy.php') ?>">Privacy</a> · <a href="<?= book_url('terms.php') ?>">Terms</a> · <a href="<?= book_url('support.php') ?>">Support</a></span>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
<script src="<?= book_asset('js/app.js') ?>?v=2.3.0"></script>
<script src="<?= book_asset('js/pwa.js') ?>?v=2.3.0"></script>
</body>
</html>
